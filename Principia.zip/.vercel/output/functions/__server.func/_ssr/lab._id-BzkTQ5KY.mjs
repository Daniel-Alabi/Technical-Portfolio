import { i as __toESM } from "../_runtime.mjs";
import { o as require_jsx_runtime, s as require_react } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { _ as Link, v as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as RotateCcw, d as EyeOff, f as BookOpen, m as ArrowLeft, n as Volume2, o as Play, s as Pause, t as VolumeX, u as Eye } from "../_libs/lucide-react.mjs";
import { n as Route } from "./router-CsdINpJk.mjs";
import { C as stepWorld, D as unlockAudio, O as useProgress, S as renderWorld, T as toWorld, _ as playLaunch, a as cn, b as predictTrajectory, c as getLab, d as makeBody, f as momentum, g as playCollide, h as playClick, i as clamp, l as isUnlocked, m as playBell, o as fitView, p as nextLabId, r as StarRow, s as formatNum, t as Button, u as kinetic, v as playSuccess, w as toScreen, y as potential } from "./store-CfcFqHlv.mjs";
import { i as SliderTrack, n as SliderRange, r as SliderThumb, t as Slider$1 } from "../_libs/@radix-ui/react-slider+[...].mjs";
import { n as SwitchThumb, t as Switch$1 } from "../_libs/radix-ui__react-switch.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/lab._id-BzkTQ5KY.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Slider = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Slider$1, {
	ref,
	className: cn("relative flex w-full touch-none select-none items-center py-2", className),
	...props,
	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderTrack, {
		className: "relative h-1.5 w-full grow overflow-hidden rounded-full bg-elevated",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderRange, { className: "absolute h-full bg-accent" })
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderThumb, { className: "block size-4 rounded-full border border-border bg-primary shadow-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/50" })]
}));
Slider.displayName = Slider$1.displayName;
var Switch = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch$1, {
	className: cn("peer inline-flex h-6 w-11 shrink-0 cursor-pointer items-center rounded-full border border-border transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/50 data-[state=checked]:bg-accent data-[state=unchecked]:bg-elevated", className),
	...props,
	ref,
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SwitchThumb, { className: "pointer-events-none block size-5 rounded-full bg-primary-fg data-[state=unchecked]:bg-muted ring-0 transition-transform data-[state=checked]:translate-x-[22px] data-[state=unchecked]:translate-x-[1px] data-[state=checked]:bg-accent-fg" })
}));
Switch.displayName = Switch$1.displayName;
var STEP = 1 / 120;
var emptyTel = {
	t: 0,
	mass: 0,
	vx: 0,
	vy: 0,
	speed: 0,
	ax: 0,
	ay: 0,
	ke: 0,
	pe: 0,
	e: 0,
	px: 0,
	py: 0
};
var LabRuntime = class {
	lab;
	world;
	view = null;
	paused = false;
	selected = null;
	grab = null;
	velDrag = false;
	acc = 0;
	trauma = 0;
	predict = null;
	complete = false;
	stars = 0;
	detail = "";
	vectors = true;
	shake = true;
	reduced = false;
	spawnCount = 0;
	lastEval = 0;
	constructor(lab) {
		this.lab = lab;
		this.world = lab.build();
		this.selected = this.world.bodies.find((b) => b.role === "player" || b.role === "craft")?.id ?? this.world.bodies[0]?.id ?? null;
		if (typeof window !== "undefined") this.reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
	}
	reset() {
		this.world = this.lab.build();
		this.acc = 0;
		this.complete = false;
		this.stars = 0;
		this.detail = "";
		this.paused = false;
		this.grab = null;
		this.velDrag = false;
		this.trauma = 0;
		this.selected = this.world.bodies.find((b) => b.role === "player" || b.role === "craft")?.id ?? this.world.bodies[0]?.id ?? null;
	}
	setControl(key, value) {
		this.lab.applyControl?.(this.world, key, value);
		this.world.meta[key] = value;
	}
	doAction(key) {
		this.lab.action?.(this.world, key);
		if (key === "fire" || key === "launch" || key === "release" || key === "drop" || key === "engage") playLaunch();
	}
	frame(dt) {
		const cap = Math.min(dt, .1);
		if (!this.paused && !this.complete) {
			this.acc += cap;
			this.acc = Math.min(this.acc, .25);
			while (this.acc >= STEP) {
				this.lab.tick?.(this.world, STEP);
				stepWorld(this.world, STEP);
				this.consumeEvents();
				this.acc -= STEP;
				this.lastEval += STEP;
				if (this.lastEval > .08) {
					this.lastEval = 0;
					this.check();
				}
			}
		} else this.lab.tick?.(this.world, 0);
		this.trauma = Math.max(0, this.trauma - cap * 2.4);
		this.updatePredict();
	}
	check() {
		if (this.complete || this.lab.sandbox) return;
		const ev = this.lab.evaluate(this.world);
		if (ev.complete && ev.stars > 0) {
			this.complete = true;
			this.stars = ev.stars;
			this.detail = ev.detail;
			this.paused = true;
			playSuccess();
			this.trauma = Math.min(1, this.trauma + .45);
		}
	}
	consumeEvents() {
		for (const e of this.world.events) {
			if (e.type === "collide") {
				playCollide(e.mag);
				if (this.shake && !this.reduced) this.trauma = Math.min(1, this.trauma + Math.min(.4, e.mag * .05));
			}
			if (e.type === "bell") playBell();
		}
	}
	updatePredict() {
		if (this.lab.id !== "projectile" && this.lab.id !== "orbit") {
			this.predict = null;
			return;
		}
		if (this.lab.id === "projectile") {
			const th = (this.world.meta.angle ?? 45) * Math.PI / 180;
			const v = this.world.meta.speed ?? 12;
			if (this.world.meta.flying === 1 && !this.world.bodies[0]?.fixed) {
				this.predict = null;
				return;
			}
			this.predict = predictTrajectory(this.world, 1.6, .95, Math.cos(th) * v, Math.sin(th) * v, 2.6);
			return;
		}
		const craft = this.world.bodies.find((b) => b.role === "craft");
		if (!craft) return;
		if (this.world.meta.setup === 1) this.predict = predictTrajectory(this.world, craft.x, craft.y, this.world.meta.vx0 ?? 0, this.world.meta.vy0 ?? 0, 6, 1 / 45);
		else this.predict = predictTrajectory(this.world, craft.x, craft.y, craft.vx, craft.vy, 4, 1 / 45);
	}
	pointerDown(sx, sy) {
		if (!this.view) return;
		const p = toWorld(this.view, this.world, sx, sy);
		if (this.lab.id === "orbit" && this.world.meta.setup === 1 && this.selected) {
			const craft = this.world.bodies.find((b) => b.id === this.selected);
			if (craft) {
				const handle = toScreen(this.view, this.world, craft.x + (this.world.meta.vx0 ?? 0) * .45, craft.y + (this.world.meta.vy0 ?? 0) * .45);
				if ((handle.x - sx) ** 2 + (handle.y - sy) ** 2 < 324) {
					this.velDrag = true;
					return;
				}
			}
		}
		const hit = this.hitScreen(sx, sy);
		if (hit && (!hit.fixed || hit.role === "craft" && this.world.meta.setup === 1)) {
			this.selected = hit.id;
			hit.grabbed = true;
			hit.vx = 0;
			hit.vy = 0;
			this.grab = {
				id: hit.id,
				lastX: p.x,
				lastY: p.y,
				lastT: performance.now()
			};
			return;
		}
		if (this.lab.id === "sandbox") {
			this.spawnCount += 1;
			const colors = [
				"#d4c4b0",
				"#8eb4d3",
				"#c5cdd8",
				"#d08a7a"
			];
			const mass = .6 + Math.random() * 2.2;
			this.world.bodies.push(makeBody({
				id: `s${this.spawnCount}`,
				x: clamp(p.x, .4, this.world.width - .4),
				y: clamp(p.y, .4, this.world.height - .4),
				mass,
				radius: .22 + mass * .12,
				color: colors[this.spawnCount % colors.length],
				label: mass.toFixed(1)
			}));
		}
	}
	hitScreen(sx, sy) {
		if (!this.view) return null;
		let best = null;
		let bestD = Infinity;
		for (const b of this.world.bodies) {
			if (b.role === "planet") continue;
			const p = toScreen(this.view, this.world, b.x, b.y);
			const r = Math.max(28, b.radius * this.view.ppm * 1.25);
			const d2 = (p.x - sx) ** 2 + (p.y - sy) ** 2;
			if (d2 <= r * r && d2 < bestD) {
				best = b;
				bestD = d2;
			}
		}
		return best;
	}
	pointerMove(sx, sy) {
		if (!this.view) return;
		const p = toWorld(this.view, this.world, sx, sy);
		if (this.velDrag) {
			const craft = this.world.bodies.find((b) => b.id === this.selected);
			if (craft) {
				this.world.meta.vx0 = clamp((p.x - craft.x) / .45, -12, 12);
				this.world.meta.vy0 = clamp((p.y - craft.y) / .45, -12, 12);
			}
			return;
		}
		if (!this.grab) return;
		const b = this.world.bodies.find((x) => x.id === this.grab?.id);
		if (!b) return;
		const now = performance.now();
		const dt = Math.max(.008, (now - this.grab.lastT) / 1e3);
		const nx = clamp(p.x, b.radius, this.world.width - b.radius);
		const ny = clamp(p.y, b.radius, this.world.height - b.radius);
		b.vx = (nx - this.grab.lastX) / dt;
		b.vy = (ny - this.grab.lastY) / dt;
		b.x = nx;
		b.y = ny;
		b.px = nx;
		b.py = ny;
		this.grab.lastX = nx;
		this.grab.lastY = ny;
		this.grab.lastT = now;
	}
	pointerUp() {
		if (this.velDrag) {
			this.velDrag = false;
			return;
		}
		if (!this.grab) return;
		const b = this.world.bodies.find((x) => x.id === this.grab?.id);
		if (b) {
			b.grabbed = false;
			const sp = Math.hypot(b.vx, b.vy);
			const max = 18;
			if (sp > max) {
				b.vx = b.vx / sp * max;
				b.vy = b.vy / sp * max;
			}
			if (this.lab.id === "orbit" && this.world.meta.setup === 1) {
				b.vx = 0;
				b.vy = 0;
				b.fixed = true;
			}
		}
		this.grab = null;
	}
	render(ctx, cssW, cssH) {
		this.view = fitView(this.world, cssW, cssH);
		const alpha = this.paused || this.complete ? 1 : this.acc / STEP;
		const shake = this.shake && !this.reduced ? this.trauma * this.trauma : 0;
		const craft = this.world.bodies.find((b) => b.role === "craft");
		const velHandle = this.lab.id === "orbit" && this.world.meta.setup === 1 && craft ? {
			x: craft.x + (this.world.meta.vx0 ?? 0) * .45,
			y: craft.y + (this.world.meta.vy0 ?? 0) * .45
		} : null;
		renderWorld(ctx, this.world, this.view, {
			alpha,
			vectors: this.vectors,
			selectedId: this.selected,
			predict: this.predict,
			shakeX: (Math.random() * 2 - 1) * shake * 10,
			shakeY: (Math.random() * 2 - 1) * shake * 10,
			velHandle
		});
	}
	snapshot() {
		const b = this.selectedBody();
		const ke = this.world.bodies.reduce((n, x) => n + kinetic(x), 0);
		const pe = this.world.bodies.reduce((n, x) => n + (x.fixed ? 0 : potential(x, this.world)), 0);
		const p = momentum(this.world.bodies);
		return {
			telemetry: b ? {
				t: this.world.time,
				mass: b.mass,
				vx: b.vx,
				vy: b.vy,
				speed: Math.hypot(b.vx, b.vy),
				ax: b.ax,
				ay: b.ay,
				ke,
				pe,
				e: ke + pe,
				px: p.px,
				py: p.py
			} : {
				...emptyTel,
				t: this.world.time,
				ke,
				pe,
				e: ke + pe,
				px: p.px,
				py: p.py
			},
			paused: this.paused,
			complete: this.complete,
			stars: this.stars,
			detail: this.detail,
			meta: this.world.meta
		};
	}
	selectedBody() {
		return this.world.bodies.find((b) => b.id === this.selected) ?? this.world.bodies[0] ?? null;
	}
};
var emptySnap = {
	telemetry: {
		t: 0,
		mass: 0,
		vx: 0,
		vy: 0,
		speed: 0,
		ax: 0,
		ay: 0,
		ke: 0,
		pe: 0,
		e: 0,
		px: 0,
		py: 0
	},
	paused: false,
	complete: false,
	stars: 0,
	detail: "",
	meta: {}
};
function LabStage({ id }) {
	const lab = getLab(id);
	const navigate = useNavigate();
	const hydrate = useProgress((s) => s.hydrate);
	const recordStars = useProgress((s) => s.recordStars);
	const settings = useProgress((s) => s.settings);
	const patchSettings = useProgress((s) => s.patchSettings);
	const completed = useProgress((s) => s.completed);
	const canvasRef = (0, import_react.useRef)(null);
	const runtimeRef = (0, import_react.useRef)(null);
	const introRef = (0, import_react.useRef)(true);
	const uiAt = (0, import_react.useRef)(0);
	const [snap, setSnap] = (0, import_react.useState)(emptySnap);
	const [showTheory, setShowTheory] = (0, import_react.useState)(true);
	const [resetKey, setResetKey] = (0, import_react.useState)(0);
	const [controls, setControls] = (0, import_react.useState)({});
	(0, import_react.useEffect)(() => {
		hydrate();
	}, [hydrate]);
	const allowed = lab ? isUnlocked(lab.id, completed) : false;
	const defaults = (0, import_react.useMemo)(() => {
		if (!lab) return {};
		const d = {};
		for (const c of lab.controls) {
			if (c.kind === "slider") d[c.key] = (c.min ?? 0) + ((c.max ?? 1) - (c.min ?? 0)) * .45;
			if (c.kind === "toggle") d[c.key] = 0;
		}
		if (lab.id === "force") d.force = 0;
		if (lab.id === "projectile") {
			d.angle = 48;
			d.speed = 12;
		}
		if (lab.id === "energy") d.height = 6.2;
		if (lab.id === "spring") {
			d.k = 48;
			d.comp = 1.4;
		}
		if (lab.id === "sandbox") d.g = 9.81;
		if (lab.id === "gravity") d.air = 0;
		if (lab.id === "inertia") d.friction = 0;
		return d;
	}, [lab]);
	(0, import_react.useEffect)(() => {
		setControls(defaults);
		setShowTheory(true);
		introRef.current = true;
		setSnap(emptySnap);
	}, [defaults, id]);
	(0, import_react.useEffect)(() => {
		if (!lab || !allowed) return;
		const rt = new LabRuntime(lab);
		runtimeRef.current = rt;
		rt.paused = introRef.current;
		for (const [k, v] of Object.entries(defaults)) rt.setControl(k, v);
		const canvas = canvasRef.current;
		if (!canvas) return;
		const ctx = canvas.getContext("2d");
		if (!ctx) return;
		let raf = 0;
		let last = performance.now();
		let live = true;
		let reported = false;
		const loop = (now) => {
			if (!live) return;
			const dt = (now - last) / 1e3;
			last = now;
			const parent = canvas.parentElement;
			const cssW = parent?.clientWidth ?? 800;
			const cssH = parent?.clientHeight ?? 480;
			const dpr = Math.min(2, window.devicePixelRatio || 1);
			const bw = Math.floor(cssW * dpr);
			const bh = Math.floor(cssH * dpr);
			if (canvas.width !== bw || canvas.height !== bh) {
				canvas.width = bw;
				canvas.height = bh;
				canvas.style.width = `${cssW}px`;
				canvas.style.height = `${cssH}px`;
			}
			ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
			const st = useProgress.getState().settings;
			rt.vectors = st.vectors;
			rt.shake = st.shake;
			if (introRef.current) rt.paused = true;
			rt.frame(dt);
			rt.render(ctx, cssW, cssH);
			if (now - uiAt.current > 80 || rt.complete) {
				uiAt.current = now;
				const s = rt.snapshot();
				setSnap(s);
				if (s.complete && !reported) {
					reported = true;
					recordStars(lab.id, s.stars);
				}
			}
			raf = requestAnimationFrame(loop);
		};
		raf = requestAnimationFrame(loop);
		const onKey = (e) => {
			if (e.key === " " || e.code === "Space") {
				e.preventDefault();
				rt.paused = !rt.paused;
			} else if (e.key === "r" || e.key === "R") {
				rt.reset();
				for (const [k, v] of Object.entries(defaults)) rt.setControl(k, v);
				reported = false;
			} else if (e.key === "Escape") navigate({ to: "/" });
		};
		window.addEventListener("keydown", onKey);
		return () => {
			live = false;
			cancelAnimationFrame(raf);
			window.removeEventListener("keydown", onKey);
			runtimeRef.current = null;
		};
	}, [
		lab,
		allowed,
		defaults,
		recordStars,
		navigate,
		resetKey
	]);
	const toLocal = (e) => {
		const rect = e.currentTarget.getBoundingClientRect();
		return {
			x: e.clientX - rect.left,
			y: e.clientY - rect.top
		};
	};
	const onDown = (e) => {
		unlockAudio();
		e.currentTarget.setPointerCapture(e.pointerId);
		const p = toLocal(e);
		runtimeRef.current?.pointerDown(p.x, p.y);
	};
	const onMove = (e) => {
		const p = toLocal(e);
		runtimeRef.current?.pointerMove(p.x, p.y);
	};
	const onUp = () => runtimeRef.current?.pointerUp();
	const setCtrl = (0, import_react.useCallback)((key, value) => {
		setControls((c) => ({
			...c,
			[key]: value
		}));
		runtimeRef.current?.setControl(key, value);
	}, []);
	const fire = (key) => {
		unlockAudio();
		playClick();
		runtimeRef.current?.doAction(key);
	};
	if (!lab) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-dvh flex-col items-center justify-center gap-4 bg-bg px-6 text-fg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-3xl",
			children: "No such experiment"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			asChild: true,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/",
				children: "Back to the laboratory"
			})
		})]
	});
	if (!allowed) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-dvh flex-col items-center justify-center gap-4 bg-bg px-6 text-center text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-3xl",
				children: "Still locked"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-sm text-sm text-muted",
				children: "Finish the previous experiment to open this station."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				asChild: true,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					children: "Back to the laboratory"
				})
			})
		]
	});
	const next = nextLabId(lab.id);
	const t = snap.telemetry;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative flex h-dvh flex-col bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "grain pointer-events-none absolute inset-0 opacity-50" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "relative z-10 flex shrink-0 items-center gap-2 border-b border-border px-3 py-2 sm:px-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						variant: "ghost",
						size: "icon-sm",
						"aria-label": "Back to laboratory",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-4" })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-mono text-[10px] uppercase tracking-[0.16em] text-subtle",
							children: lab.sandbox ? "Free play" : `Experiment ${String(lab.index).padStart(2, "0")}`
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "truncate font-display text-lg leading-tight sm:text-xl",
							children: lab.title
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								size: "icon-sm",
								"aria-label": settings.sound ? "Mute" : "Unmute",
								onClick: () => patchSettings({ sound: !settings.sound }),
								children: settings.sound ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Volume2, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VolumeX, { className: "size-4" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								size: "icon-sm",
								"aria-label": settings.vectors ? "Hide vectors" : "Show vectors",
								onClick: () => patchSettings({ vectors: !settings.vectors }),
								children: settings.vectors ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EyeOff, { className: "size-4" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								size: "icon-sm",
								"aria-label": "Theory",
								onClick: () => {
									introRef.current = true;
									setShowTheory(true);
								},
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BookOpen, { className: "size-4" })
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative z-10 flex min-h-0 flex-1 flex-col lg:flex-row",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex min-h-0 min-w-0 flex-1 flex-col",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "shrink-0 px-4 py-2 text-center text-xs leading-relaxed text-muted sm:text-sm",
						children: lab.objective
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "relative min-h-[220px] flex-1 sm:min-h-[280px] px-2 pb-2 sm:px-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "relative h-full overflow-hidden rounded-[20px] border border-border bg-[#101114] touch-none",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
								ref: canvasRef,
								className: "absolute inset-0 size-full cursor-grab active:cursor-grabbing",
								style: { touchAction: "none" },
								onPointerDown: onDown,
								onPointerMove: onMove,
								onPointerUp: onUp,
								onPointerCancel: onUp
							})
						})
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
					className: "flex max-h-[46vh] shrink-0 flex-col gap-3 overflow-y-auto border-t border-border bg-surface px-4 py-3 lg:max-h-none lg:w-[300px] lg:gap-4 lg:overflow-visible lg:border-l lg:border-t-0 lg:py-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "hidden font-mono text-[11px] text-accent lg:block",
							children: lab.formula
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-3 gap-2 font-mono text-[11px] tabular-nums",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meter, {
									label: "v",
									value: `${formatNum(t.speed, 2)}`,
									unit: "m/s"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meter, {
									label: "a",
									value: `${formatNum(Math.hypot(t.ax, t.ay), 2)}`,
									unit: "m/s²"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meter, {
									label: "t",
									value: `${formatNum(t.t, 1)}`,
									unit: "s"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meter, {
									label: "KE",
									value: `${formatNum(t.ke, 1)}`,
									unit: "J"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meter, {
									label: "PE",
									value: `${formatNum(t.pe, 1)}`,
									unit: "J"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Meter, {
									label: "Σp",
									value: `${formatNum(Math.hypot(t.px, t.py), 1)}`,
									unit: "kg·m/s"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "space-y-3",
							children: lab.controls.map((c) => {
								if (c.kind === "slider") {
									const v = controls[c.key] ?? c.min ?? 0;
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "block",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "flex items-baseline justify-between text-xs text-muted",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: c.label }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "font-mono tabular-nums text-fg",
												children: [formatNum(v, c.step && c.step < .1 ? 2 : 1), c.unit ? ` ${c.unit}` : ""]
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
											min: c.min,
											max: c.max,
											step: c.step,
											value: [v],
											onValueChange: (val) => setCtrl(c.key, val[0] ?? 0)
										})]
									}, c.key);
								}
								if (c.kind === "toggle") {
									const v = controls[c.key] ?? 0;
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "flex items-center justify-between gap-3 text-sm",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-muted",
											children: c.label
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
											checked: v > .5,
											onCheckedChange: (on) => setCtrl(c.key, on ? 1 : 0)
										})]
									}, c.key);
								}
								return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									className: "w-full",
									onClick: () => fire(c.key),
									children: c.actionLabel ?? c.label
								}, c.key);
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-auto flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "secondary",
								className: "flex-1",
								onClick: () => {
									runtimeRef.current && (runtimeRef.current.paused = !runtimeRef.current.paused);
								},
								children: [snap.paused ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "size-4" }), snap.paused ? "Resume" : "Pause"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "outline",
								className: "flex-1",
								onClick: () => {
									setResetKey((n) => n + 1);
									setControls(defaults);
								},
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-4" }), "Reset"]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "hidden text-[11px] leading-relaxed text-subtle lg:block",
							children: lab.interact
						})
					]
				})]
			}),
			showTheory && !snap.complete && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute inset-0 z-20 flex items-end justify-center bg-bg/70 p-4 sm:items-center",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "max-h-[85dvh] w-full max-w-lg overflow-auto rounded-[28px] border border-border bg-surface p-6 shadow-[var(--shadow-panel)] sm:p-8",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-mono text-[11px] uppercase tracking-[0.18em] text-subtle",
							children: lab.sandbox ? "Notebook" : `Experiment ${String(lab.index).padStart(2, "0")}`
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display mt-2 text-3xl tracking-tight",
							children: lab.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 font-mono text-sm text-accent",
							children: lab.formula
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-5 space-y-3 text-[15px] leading-relaxed text-muted",
							children: lab.theory.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: p }, p))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-5 text-sm text-fg",
							children: lab.objective
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-xs text-subtle",
							children: lab.interact
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							className: "mt-6 w-full",
							size: "lg",
							onClick: () => {
								unlockAudio();
								introRef.current = false;
								const rt = runtimeRef.current;
								if (rt) rt.paused = false;
								setShowTheory(false);
							},
							children: "Begin"
						})
					]
				})
			}),
			snap.complete && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute inset-0 z-20 flex items-end justify-center bg-bg/70 p-4 sm:items-center",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "w-full max-w-md rounded-[28px] border border-border bg-surface p-6 text-center shadow-[var(--shadow-panel)] sm:p-8",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StarRow, {
							n: snap.stars,
							size: 22,
							className: "justify-center"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display mt-4 text-3xl tracking-tight",
							children: "Confirmed"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-[15px] leading-relaxed text-muted",
							children: snap.detail
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 font-mono text-xs text-accent",
							children: lab.formula
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-6 flex flex-col gap-2 sm:flex-row",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "secondary",
								className: "flex-1",
								onClick: () => {
									setResetKey((n) => n + 1);
									setControls(defaults);
								},
								children: "Replay"
							}), next ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								asChild: true,
								className: "flex-1",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/lab/$id",
									params: { id: next },
									children: "Next experiment"
								})
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								asChild: true,
								className: "flex-1",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/",
									children: "Laboratory"
								})
							})]
						})
					]
				})
			})
		]
	});
}
function Meter({ label, value, unit }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-[12px] bg-elevated px-2 py-1.5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-[10px] uppercase tracking-wider text-subtle",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "text-fg",
			children: [value, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "ml-0.5 text-[9px] text-subtle",
				children: unit
			})]
		})]
	});
}
function LabPage() {
	const { id } = Route.useParams();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LabStage, { id });
}
//#endregion
export { LabPage as component };
