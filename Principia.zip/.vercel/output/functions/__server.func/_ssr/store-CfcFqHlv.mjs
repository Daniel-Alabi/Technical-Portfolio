import { i as __toESM } from "../_runtime.mjs";
import { o as require_jsx_runtime, r as Slot, s as require_react } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { i as Star } from "../_libs/lucide-react.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { t as create } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/store-CfcFqHlv.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
Math.PI * 2;
function clamp(v, a, b) {
	return Math.max(a, Math.min(b, v));
}
function lerp(a, b, t) {
	return a + (b - a) * t;
}
function len(x, y) {
	return Math.hypot(x, y);
}
function closestOnSegment(px, py, x1, y1, x2, y2) {
	const dx = x2 - x1;
	const dy = y2 - y1;
	const d2 = dx * dx + dy * dy;
	if (d2 < 1e-8) return {
		x: x1,
		y: y1,
		t: 0
	};
	const t = clamp(((px - x1) * dx + (py - y1) * dy) / d2, 0, 1);
	return {
		x: x1 + dx * t,
		y: y1 + dy * t,
		t
	};
}
function formatNum(n, digits = 2) {
	if (!Number.isFinite(n)) return "—";
	const abs = Math.abs(n);
	if (abs !== 0 && abs < .005) return "0.00";
	return n.toFixed(digits);
}
function fitView(world, cssW, cssH, pad = 20) {
	const sx = (cssW - pad * 2) / world.width;
	const sy = (cssH - pad * 2) / world.height;
	const ppm = Math.max(8, Math.min(sx, sy));
	return {
		ppm,
		ox: (cssW - world.width * ppm) / 2,
		oy: (cssH - world.height * ppm) / 2,
		cssW,
		cssH
	};
}
function toScreen(view, world, x, y) {
	return {
		x: view.ox + x * view.ppm,
		y: view.oy + (world.height - y) * view.ppm
	};
}
function toWorld(view, world, sx, sy) {
	return {
		x: (sx - view.ox) / view.ppm,
		y: world.height - (sy - view.oy) / view.ppm
	};
}
function bodyPos(b, alpha) {
	return {
		x: lerp(b.px, b.x, alpha),
		y: lerp(b.py, b.y, alpha)
	};
}
function arrow(ctx, x0, y0, x1, y1, color, width) {
	const dx = x1 - x0;
	const dy = y1 - y0;
	if (Math.hypot(dx, dy) < 4) return;
	const ang = Math.atan2(dy, dx);
	const head = Math.min(12, 6 + width * 2);
	ctx.strokeStyle = color;
	ctx.fillStyle = color;
	ctx.lineWidth = width;
	ctx.lineCap = "round";
	ctx.beginPath();
	ctx.moveTo(x0, y0);
	ctx.lineTo(x1 - Math.cos(ang) * head * .65, y1 - Math.sin(ang) * head * .65);
	ctx.stroke();
	ctx.beginPath();
	ctx.moveTo(x1, y1);
	ctx.lineTo(x1 - Math.cos(ang - .4) * head, y1 - Math.sin(ang - .4) * head);
	ctx.lineTo(x1 - Math.cos(ang + .4) * head, y1 - Math.sin(ang + .4) * head);
	ctx.closePath();
	ctx.fill();
}
function coil(ctx, x0, y0, x1, y1, turns, amp, color) {
	const dx = x1 - x0;
	const dy = y1 - y0;
	const L = Math.hypot(dx, dy) || 1;
	const ux = dx / L;
	const uy = dy / L;
	const px = -uy;
	const py = ux;
	ctx.beginPath();
	ctx.moveTo(x0, y0);
	const n = Math.max(12, turns * 8);
	for (let i = 1; i <= n; i++) {
		const t = i / n;
		const w = Math.sin(t * turns * Math.PI * 2) * amp;
		ctx.lineTo(x0 + ux * L * t + px * w, y0 + uy * L * t + py * w);
	}
	ctx.strokeStyle = color;
	ctx.lineWidth = 1.6;
	ctx.stroke();
}
function renderWorld(ctx, world, view, opts) {
	const { cssW, cssH, ppm } = view;
	ctx.save();
	ctx.translate(opts.shakeX, opts.shakeY);
	ctx.fillStyle = "#101114";
	ctx.fillRect(0, 0, cssW, cssH);
	const origin = toScreen(view, world, 0, 0);
	const far = toScreen(view, world, world.width, world.height);
	const left = origin.x;
	const bottom = origin.y;
	const right = far.x;
	const top = far.y;
	const bw = right - left;
	const bh = bottom - top;
	ctx.fillStyle = "#0d0e11";
	ctx.fillRect(left, top, bw, bh);
	ctx.save();
	ctx.beginPath();
	ctx.rect(left, top, bw, bh);
	ctx.clip();
	const step = ppm >= 36 ? 1 : 2;
	ctx.lineWidth = 1;
	for (let x = 0; x <= world.width + .01; x += step) {
		const p = toScreen(view, world, x, 0);
		ctx.strokeStyle = x % 5 === 0 ? "rgba(240,238,234,0.10)" : "rgba(240,238,234,0.045)";
		ctx.beginPath();
		ctx.moveTo(p.x, top);
		ctx.lineTo(p.x, bottom);
		ctx.stroke();
	}
	for (let y = 0; y <= world.height + .01; y += step) {
		const p = toScreen(view, world, 0, y);
		ctx.strokeStyle = y % 5 === 0 ? "rgba(240,238,234,0.10)" : "rgba(240,238,234,0.045)";
		ctx.beginPath();
		ctx.moveTo(left, p.y);
		ctx.lineTo(right, p.y);
		ctx.stroke();
	}
	ctx.font = "500 10px 'IBM Plex Mono', monospace";
	ctx.fillStyle = "rgba(156,154,148,0.7)";
	ctx.textAlign = "center";
	ctx.textBaseline = "top";
	for (let x = 0; x <= world.width; x += 5) {
		const p = toScreen(view, world, x, 0);
		ctx.fillText(`${x} m`, p.x, bottom + 4);
	}
	ctx.textAlign = "right";
	ctx.textBaseline = "middle";
	for (let y = 0; y <= world.height; y += 5) {
		if (y === 0) continue;
		const p = toScreen(view, world, 0, y);
		ctx.fillText(`${y}`, left - 6, p.y);
	}
	if (world.groundY !== null) {
		const g0 = toScreen(view, world, 0, world.groundY);
		const g1 = toScreen(view, world, world.width, world.groundY);
		ctx.fillStyle = "#16171b";
		ctx.fillRect(left, g0.y, bw, bottom - g0.y);
		ctx.strokeStyle = "rgba(197,205,216,0.35)";
		ctx.lineWidth = 2;
		ctx.beginPath();
		ctx.moveTo(g0.x, g0.y);
		ctx.lineTo(g1.x, g1.y);
		ctx.stroke();
		ctx.strokeStyle = "rgba(240,238,234,0.06)";
		ctx.lineWidth = 1;
		for (let i = 0; i < 28; i++) {
			const x = left + (i + .2) / 28 * bw;
			ctx.beginPath();
			ctx.moveTo(x, g0.y);
			ctx.lineTo(x - 8, g0.y + 10);
			ctx.stroke();
		}
	}
	for (const z of world.zones) {
		const a = toScreen(view, world, z.x, z.y + z.h);
		const w = z.w * ppm;
		const h = z.h * ppm;
		ctx.save();
		ctx.strokeStyle = z.color;
		ctx.fillStyle = z.color;
		ctx.globalAlpha = .12;
		ctx.beginPath();
		ctx.roundRect(a.x, a.y, w, h, 8);
		ctx.fill();
		ctx.globalAlpha = .85;
		ctx.setLineDash([5, 4]);
		ctx.lineWidth = 1.4;
		ctx.stroke();
		ctx.setLineDash([]);
		if (z.label) {
			ctx.globalAlpha = .9;
			ctx.font = "500 11px Figtree, sans-serif";
			ctx.fillStyle = z.color;
			ctx.textAlign = "center";
			ctx.textBaseline = "middle";
			ctx.fillText(z.label, a.x + w / 2, a.y + h / 2);
		}
		ctx.restore();
	}
	for (const r of world.rects) {
		const a = toScreen(view, world, r.x, r.y + r.h);
		ctx.fillStyle = r.fill;
		ctx.strokeStyle = r.color;
		ctx.lineWidth = 1.5;
		ctx.beginPath();
		ctx.roundRect(a.x, a.y, r.w * ppm, r.h * ppm, 5);
		ctx.fill();
		ctx.stroke();
		if (r.role === "cart") {
			const wheelY = a.y + r.h * ppm + 3;
			ctx.fillStyle = "#c5cdd8";
			ctx.beginPath();
			ctx.arc(a.x + 10, wheelY, 4, 0, Math.PI * 2);
			ctx.arc(a.x + r.w * ppm - 10, wheelY, 4, 0, Math.PI * 2);
			ctx.fill();
		}
	}
	for (const s of world.segments) {
		const a = toScreen(view, world, s.x1, s.y1);
		const b = toScreen(view, world, s.x2, s.y2);
		ctx.strokeStyle = s.color;
		ctx.lineWidth = 3;
		ctx.lineCap = "round";
		ctx.beginPath();
		ctx.moveTo(a.x, a.y);
		ctx.lineTo(b.x, b.y);
		ctx.stroke();
	}
	for (const well of world.wells) {
		const p = toScreen(view, world, well.x, well.y);
		const r = well.radius * ppm;
		const g = ctx.createRadialGradient(p.x - r * .25, p.y - r * .3, r * .1, p.x, p.y, r);
		g.addColorStop(0, "#e8e4dc");
		g.addColorStop(.45, well.color);
		g.addColorStop(1, "#1a1c22");
		ctx.fillStyle = g;
		ctx.beginPath();
		ctx.arc(p.x, p.y, r, 0, Math.PI * 2);
		ctx.fill();
		ctx.strokeStyle = "rgba(240,238,234,0.18)";
		ctx.lineWidth = 1;
		ctx.beginPath();
		ctx.arc(p.x, p.y, r + 6, 0, Math.PI * 2);
		ctx.stroke();
		ctx.beginPath();
		ctx.arc(p.x, p.y, r + 14, .15, 1.4);
		ctx.stroke();
		if (well.label) {
			ctx.fillStyle = "rgba(240,238,234,0.7)";
			ctx.font = "500 11px Figtree, sans-serif";
			ctx.textAlign = "center";
			ctx.textBaseline = "middle";
			ctx.fillText(well.label, p.x, p.y);
		}
	}
	for (const s of world.springs) {
		const a = world.bodies.find((b) => b.id === s.a);
		if (!a) continue;
		const ap = bodyPos(a, opts.alpha);
		let bx = s.ax;
		let by = s.ay;
		if (s.b) {
			const other = world.bodies.find((b) => b.id === s.b);
			if (!other) continue;
			const bp = bodyPos(other, opts.alpha);
			bx = bp.x;
			by = bp.y;
		}
		const p0 = toScreen(view, world, ap.x, ap.y);
		const p1 = toScreen(view, world, bx, by);
		coil(ctx, p0.x, p0.y, p1.x, p1.y, 9, 7, "#c5cdd8");
	}
	if (opts.predict && opts.predict.length > 1) {
		ctx.beginPath();
		for (let i = 0; i < opts.predict.length; i++) {
			const p = toScreen(view, world, opts.predict[i].x, opts.predict[i].y);
			if (i === 0) ctx.moveTo(p.x, p.y);
			else ctx.lineTo(p.x, p.y);
		}
		ctx.strokeStyle = "rgba(142,180,211,0.55)";
		ctx.lineWidth = 1.5;
		ctx.setLineDash([4, 5]);
		ctx.stroke();
		ctx.setLineDash([]);
		for (let i = 6; i < opts.predict.length; i += 8) {
			const p = toScreen(view, world, opts.predict[i].x, opts.predict[i].y);
			ctx.fillStyle = "rgba(142,180,211,0.7)";
			ctx.beginPath();
			ctx.arc(p.x, p.y, 2.2, 0, Math.PI * 2);
			ctx.fill();
		}
	}
	for (const p of world.particles) {
		const t = 1 - p.age / p.life;
		const s = toScreen(view, world, p.x, p.y);
		ctx.globalAlpha = t;
		ctx.fillStyle = p.color;
		ctx.beginPath();
		ctx.arc(s.x, s.y, p.size * ppm * (.6 + t * .6), 0, Math.PI * 2);
		ctx.fill();
		ctx.globalAlpha = 1;
	}
	for (const b of world.bodies) {
		if (b.role === "planet") continue;
		const pos = bodyPos(b, opts.alpha);
		const p = toScreen(view, world, pos.x, pos.y);
		const r = b.radius * ppm;
		ctx.save();
		ctx.shadowColor = "rgba(0,0,0,0.45)";
		ctx.shadowBlur = 12;
		ctx.shadowOffsetY = 4;
		const grd = ctx.createRadialGradient(p.x - r * .3, p.y - r * .35, r * .1, p.x, p.y, r);
		grd.addColorStop(0, shade(b.color, 28));
		grd.addColorStop(1, shade(b.color, -18));
		ctx.fillStyle = grd;
		ctx.beginPath();
		ctx.arc(p.x, p.y, r, 0, Math.PI * 2);
		ctx.fill();
		ctx.restore();
		ctx.strokeStyle = b.id === opts.selectedId ? "#f0eeea" : "rgba(240,238,234,0.18)";
		ctx.lineWidth = b.id === opts.selectedId ? 2 : 1;
		ctx.beginPath();
		ctx.arc(p.x, p.y, r, 0, Math.PI * 2);
		ctx.stroke();
		ctx.fillStyle = "rgba(11,12,14,0.72)";
		ctx.font = `500 ${Math.max(9, Math.min(12, r * .55))}px 'IBM Plex Mono', monospace`;
		ctx.textAlign = "center";
		ctx.textBaseline = "middle";
		ctx.fillText(b.label ?? `${b.mass} kg`, p.x, p.y);
		if (opts.vectors && !b.fixed) {
			if (Math.hypot(b.vx, b.vy) > .18) {
				const tip = toScreen(view, world, pos.x + b.vx * .42, pos.y + b.vy * .42);
				arrow(ctx, p.x, p.y, tip.x, tip.y, "#8eb4d3", 2);
			}
			if (Math.hypot(b.lastFx, b.lastFy) > .8) {
				const ft = toScreen(view, world, pos.x + b.lastFx / b.mass * .18, pos.y + b.lastFy / b.mass * .18);
				arrow(ctx, p.x, p.y, ft.x, ft.y, "#d08a7a", 1.6);
			}
		}
	}
	if (opts.velHandle) {
		const b = world.bodies.find((x) => x.id === opts.selectedId);
		if (b) {
			const pos = bodyPos(b, opts.alpha);
			const p = toScreen(view, world, pos.x, pos.y);
			const h = toScreen(view, world, opts.velHandle.x, opts.velHandle.y);
			arrow(ctx, p.x, p.y, h.x, h.y, "#8eb4d3", 2.4);
			ctx.fillStyle = "#f0eeea";
			ctx.beginPath();
			ctx.arc(h.x, h.y, 6, 0, Math.PI * 2);
			ctx.fill();
			ctx.strokeStyle = "#8eb4d3";
			ctx.stroke();
		}
	}
	ctx.restore();
	ctx.strokeStyle = "rgba(240,238,234,0.10)";
	ctx.lineWidth = 1;
	ctx.strokeRect(left + .5, top + .5, bw - 1, bh - 1);
	ctx.restore();
}
function shade(hex, amt) {
	const n = hex.replace("#", "");
	return `rgb(${clamp255(parseInt(n.slice(0, 2), 16) + amt)},${clamp255(parseInt(n.slice(2, 4), 16) + amt)},${clamp255(parseInt(n.slice(4, 6), 16) + amt)})`;
}
function clamp255(n) {
	return Math.max(0, Math.min(255, n | 0));
}
function renderIdle(ctx, w, h, t) {
	ctx.fillStyle = "#0b0c0e";
	ctx.fillRect(0, 0, w, h);
	const cx = w * .62;
	const cy = h * .52;
	const planetR = Math.min(w, h) * .16;
	const vg = ctx.createRadialGradient(cx, cy, planetR * .2, cx, cy, Math.max(w, h) * .7);
	vg.addColorStop(0, "rgba(142,180,211,0.07)");
	vg.addColorStop(1, "rgba(11,12,14,0)");
	ctx.fillStyle = vg;
	ctx.fillRect(0, 0, w, h);
	ctx.save();
	ctx.translate(cx, cy);
	ctx.rotate(-.35);
	ctx.strokeStyle = "rgba(142,180,211,0.28)";
	ctx.lineWidth = 1;
	ctx.beginPath();
	ctx.ellipse(0, 0, planetR * 2.35, planetR * 1.05, 0, 0, Math.PI * 2);
	ctx.stroke();
	ctx.strokeStyle = "rgba(197,205,216,0.14)";
	ctx.beginPath();
	ctx.ellipse(0, 0, planetR * 3.4, planetR * 1.45, .15, 0, Math.PI * 2);
	ctx.stroke();
	ctx.restore();
	const pg = ctx.createRadialGradient(cx - planetR * .3, cy - planetR * .35, planetR * .1, cx, cy, planetR);
	pg.addColorStop(0, "#e6e1d6");
	pg.addColorStop(.45, "#c5cdd8");
	pg.addColorStop(1, "#2a2e36");
	ctx.fillStyle = pg;
	ctx.beginPath();
	ctx.arc(cx, cy, planetR, 0, Math.PI * 2);
	ctx.fill();
	const a1 = t * .42;
	const mx = cx + Math.cos(a1) * planetR * 2.35;
	const my = cy + Math.sin(a1) * planetR * 1.05;
	ctx.fillStyle = "#f0eeea";
	ctx.beginPath();
	ctx.arc(mx, my, 5, 0, Math.PI * 2);
	ctx.fill();
	const vx = -Math.sin(a1);
	const vy = Math.cos(a1);
	ctx.strokeStyle = "#8eb4d3";
	ctx.lineWidth = 1.6;
	ctx.beginPath();
	ctx.moveTo(mx, my);
	ctx.lineTo(mx + vx * 28, my + vy * 12);
	ctx.stroke();
	const a2 = t * .22 + 1.7;
	ctx.fillStyle = "#d4c4b0";
	ctx.beginPath();
	ctx.arc(cx + Math.cos(a2) * planetR * 3.4, cy + Math.sin(a2) * planetR * 1.45, 3.2, 0, Math.PI * 2);
	ctx.fill();
	for (let i = 0; i < 18; i++) {
		ctx.globalAlpha = .15 + (Math.sin(i * 12.1 + t * .05) * .5 + .5) * .35;
		ctx.fillStyle = "#f0eeea";
		ctx.beginPath();
		ctx.arc(i * 97 % w + Math.sin(t * .1 + i) * 8, i * 53 % h * .9, 1.1, 0, Math.PI * 2);
		ctx.fill();
	}
	ctx.globalAlpha = 1;
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function StarRow({ n, className, size = 14 }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("inline-flex shrink-0 items-center gap-1.5", className),
		"aria-label": `${n} of 3 stars`,
		children: [
			1,
			2,
			3
		].map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, {
			width: size,
			height: size,
			className: cn("shrink-0", i <= n ? "fill-accent text-accent" : "text-border"),
			strokeWidth: 1.75
		}, i))
	});
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap font-medium transition-[opacity,transform,background-color,color,border-color] duration-150 ease-[cubic-bezier(0.22,1,0.36,1)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/50 disabled:pointer-events-none disabled:opacity-40 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 active:scale-[0.98]", {
	variants: {
		variant: {
			default: "bg-primary text-primary-fg hover:opacity-90",
			secondary: "bg-elevated text-fg border border-border hover:bg-surface",
			ghost: "text-muted hover:text-fg hover:bg-elevated",
			outline: "border border-border bg-transparent text-fg hover:bg-elevated"
		},
		size: {
			default: "h-11 rounded-[10px] px-4 text-sm",
			sm: "h-9 rounded-[8px] px-3 text-sm",
			lg: "h-12 rounded-[12px] px-5 text-[15px]",
			icon: "size-11 rounded-[10px]",
			"icon-sm": "size-9 rounded-[8px]"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
var Button = import_react.forwardRef(({ className, variant, size, asChild = false, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		ref,
		...props
	});
});
Button.displayName = "Button";
function makeBody(partial) {
	const mass = partial.mass ?? 1;
	const radius = partial.radius ?? .35;
	return {
		vx: 0,
		vy: 0,
		ax: 0,
		ay: 0,
		px: partial.x,
		py: partial.y,
		mass,
		radius,
		restitution: .72,
		friction: .08,
		drag: 0,
		fixed: false,
		color: "#d4c4b0",
		lastFx: 0,
		lastFy: 0,
		forceX: 0,
		forceY: 0,
		grabbed: false,
		...partial
	};
}
function makeWorld(partial) {
	return {
		gx: 0,
		gy: 0,
		bounceBounds: true,
		groundY: null,
		bodies: [],
		segments: [],
		rects: [],
		springs: [],
		wells: [],
		zones: [],
		particles: [],
		events: [],
		time: 0,
		meta: {},
		...partial
	};
}
function kinetic(b) {
	return .5 * b.mass * (b.vx * b.vx + b.vy * b.vy);
}
function potential(b, world) {
	let pe = 0;
	if (world.gy !== 0) {
		const g = Math.abs(world.gy);
		const h = world.groundY !== null ? b.y - world.groundY : b.y;
		pe += b.mass * g * Math.max(0, h);
	}
	for (const well of world.wells) {
		const r = Math.max(.35, Math.hypot(b.x - well.x, b.y - well.y));
		pe += -well.gm * b.mass / r;
	}
	for (const s of world.springs) {
		const body = world.bodies.find((x) => x.id === s.a);
		if (!body) continue;
		let bx = s.ax;
		let by = s.ay;
		if (s.b) {
			const other = world.bodies.find((x) => x.id === s.b);
			if (!other) continue;
			bx = other.x;
			by = other.y;
		}
		const d = Math.hypot(body.x - bx, body.y - by) - s.rest;
		pe += .5 * s.k * d * d;
	}
	return pe;
}
function momentum(bodies) {
	let px = 0;
	let py = 0;
	for (const b of bodies) {
		if (b.fixed) continue;
		px += b.mass * b.vx;
		py += b.mass * b.vy;
	}
	return {
		px,
		py
	};
}
function emitSparks(world, x, y, mag, color) {
	const n = Math.min(14, 3 + Math.floor(mag * 2));
	for (let i = 0; i < n; i++) {
		const a = Math.random() * Math.PI * 2;
		const s = .6 + Math.random() * mag;
		world.particles.push({
			x,
			y,
			vx: Math.cos(a) * s,
			vy: Math.sin(a) * s,
			life: .35 + Math.random() * .4,
			age: 0,
			size: .04 + Math.random() * .06,
			color
		});
	}
}
function resolveCircleCircle(a, b, world) {
	const dx = b.x - a.x;
	const dy = b.y - a.y;
	const d2 = dx * dx + dy * dy;
	const min = a.radius + b.radius;
	if (d2 >= min * min || d2 < 1e-8) return;
	const d = Math.sqrt(d2);
	const nx = dx / d;
	const ny = dy / d;
	const overlap = min - d;
	const imA = a.fixed || a.grabbed ? 0 : 1 / a.mass;
	const imB = b.fixed || b.grabbed ? 0 : 1 / b.mass;
	const im = imA + imB;
	if (im <= 0) return;
	const corr = overlap / im;
	if (imA > 0) {
		a.x -= nx * corr * imA;
		a.y -= ny * corr * imA;
	}
	if (imB > 0) {
		b.x += nx * corr * imB;
		b.y += ny * corr * imB;
	}
	const rvx = b.vx - a.vx;
	const rvy = b.vy - a.vy;
	const velN = rvx * nx + rvy * ny;
	if (velN > 0) return;
	const j = -(1 + Math.min(a.restitution, b.restitution)) * velN / im;
	const ix = j * nx;
	const iy = j * ny;
	if (imA > 0) {
		a.vx -= ix * imA;
		a.vy -= iy * imA;
	}
	if (imB > 0) {
		b.vx += ix * imB;
		b.vy += iy * imB;
	}
	const tx = -ny;
	const ty = nx;
	const velT = rvx * tx + rvy * ty;
	const mu = Math.min(a.friction, b.friction);
	const jt = clamp(-velT / im, -Math.abs(j) * mu, Math.abs(j) * mu);
	if (imA > 0) {
		a.vx -= jt * tx * imA;
		a.vy -= jt * ty * imA;
	}
	if (imB > 0) {
		b.vx += jt * tx * imB;
		b.vy += jt * ty * imB;
	}
	const mag = Math.abs(j);
	if (mag > .35) {
		world.events.push({
			type: "collide",
			mag,
			x: a.x + nx * a.radius,
			y: a.y + ny * a.radius
		});
		emitSparks(world, a.x + nx * a.radius, a.y + ny * a.radius, mag * .25, "#c5cdd8");
	}
}
function resolveCirclePoint(b, px, py, restitution, world, friction = .12) {
	if (b.fixed || b.grabbed) return;
	const dx = b.x - px;
	const dy = b.y - py;
	const d2 = dx * dx + dy * dy;
	const min = b.radius;
	if (d2 >= min * min || d2 < 1e-8) return;
	const d = Math.sqrt(d2);
	const nx = dx / d;
	const ny = dy / d;
	const overlap = min - d;
	b.x += nx * overlap;
	b.y += ny * overlap;
	const velN = b.vx * nx + b.vy * ny;
	if (velN < 0) {
		const j = -(1 + Math.min(b.restitution, restitution)) * velN;
		b.vx += j * nx;
		b.vy += j * ny;
		const tx = -ny;
		const ty = nx;
		const velT = b.vx * tx + b.vy * ty;
		b.vx -= velT * tx * friction;
		b.vy -= velT * ty * friction;
		const mag = Math.abs(j) * b.mass;
		if (mag > .5) {
			world.events.push({
				type: "collide",
				mag,
				x: px,
				y: py
			});
			emitSparks(world, px, py, mag * .2, "#c5cdd8");
		}
	}
}
function resolveCircleSegment(b, s, world) {
	const c = closestOnSegment(b.x, b.y, s.x1, s.y1, s.x2, s.y2);
	resolveCirclePoint(b, c.x, c.y, s.restitution, world);
}
function resolveCircleRect(b, r, world) {
	if (!r.solid) return;
	resolveCirclePoint(b, clamp(b.x, r.x, r.x + r.w), clamp(b.y, r.y, r.y + r.h), r.restitution, world, .18);
}
function applyForces(world, dt) {
	for (const b of world.bodies) {
		if (b.fixed || b.grabbed) {
			b.lastFx = 0;
			b.lastFy = 0;
			b.ax = 0;
			b.ay = 0;
			continue;
		}
		let fx = b.forceX + b.mass * world.gx;
		let fy = b.forceY + b.mass * world.gy;
		for (const well of world.wells) {
			const dx = well.x - b.x;
			const dy = well.y - b.y;
			const r2 = dx * dx + dy * dy + .12;
			const inv = well.gm * b.mass / (r2 * Math.sqrt(r2));
			fx += dx * inv;
			fy += dy * inv;
		}
		for (const s of world.springs) {
			if (s.a !== b.id && s.b !== b.id) continue;
			let ox;
			let oy;
			if (s.a === b.id) {
				if (s.b) {
					const other = world.bodies.find((x) => x.id === s.b);
					if (!other) continue;
					ox = other.x;
					oy = other.y;
				} else {
					ox = s.ax;
					oy = s.ay;
				}
			} else {
				const other = world.bodies.find((x) => x.id === s.a);
				if (!other) continue;
				ox = other.x;
				oy = other.y;
			}
			const dx = b.x - ox;
			const dy = b.y - oy;
			const d = Math.hypot(dx, dy);
			if (d < 1e-8) continue;
			const nx = dx / d;
			const ny = dy / d;
			const stretch = d - s.rest;
			fx += -s.k * stretch * nx;
			fy += -s.k * stretch * ny;
			const rel = b.vx * nx + b.vy * ny;
			fx += -s.c * rel * nx;
			fy += -s.c * rel * ny;
		}
		if (b.drag > 0) {
			const sp = len(b.vx, b.vy);
			fx += -b.drag * b.vx * sp;
			fy += -b.drag * b.vy * sp;
		}
		b.lastFx = fx;
		b.lastFy = fy;
		b.ax = fx / b.mass;
		b.ay = fy / b.mass;
		b.vx += b.ax * dt;
		b.vy += b.ay * dt;
		const speed = len(b.vx, b.vy);
		const max = 42;
		if (speed > max) {
			b.vx = b.vx / speed * max;
			b.vy = b.vy / speed * max;
		}
	}
}
function integrate(world, dt) {
	for (const b of world.bodies) {
		b.px = b.x;
		b.py = b.y;
		if (b.fixed || b.grabbed) continue;
		b.x += b.vx * dt;
		b.y += b.vy * dt;
	}
	for (const r of world.rects) if (r.vx || r.vy) {
		r.x += r.vx * dt;
		r.y += r.vy * dt;
	}
}
function bounds(world) {
	for (const b of world.bodies) {
		if (b.fixed || b.grabbed) continue;
		if (world.groundY !== null && b.y - b.radius < world.groundY) {
			b.y = world.groundY + b.radius;
			if (b.vy < 0) {
				const mag = Math.abs(b.vy) * b.mass;
				b.vy = -b.vy * b.restitution;
				b.vx *= 1 - b.friction;
				if (Math.abs(b.vy) < .12) b.vy = 0;
				if (mag > .8) {
					world.events.push({
						type: "collide",
						mag,
						x: b.x,
						y: world.groundY
					});
					emitSparks(world, b.x, world.groundY, mag * .15, "#c5cdd8");
				}
			}
		}
		if (!world.bounceBounds) continue;
		if (b.x - b.radius < 0) {
			b.x = b.radius;
			b.vx = Math.abs(b.vx) * b.restitution;
		} else if (b.x + b.radius > world.width) {
			b.x = world.width - b.radius;
			b.vx = -Math.abs(b.vx) * b.restitution;
		}
		if (b.y - b.radius < 0) {
			b.y = b.radius;
			b.vy = Math.abs(b.vy) * b.restitution;
		} else if (b.y + b.radius > world.height) {
			b.y = world.height - b.radius;
			b.vy = -Math.abs(b.vy) * b.restitution;
		}
	}
}
function collideAll(world) {
	const n = world.bodies.length;
	for (let i = 0; i < n; i++) {
		const a = world.bodies[i];
		for (let j = i + 1; j < n; j++) resolveCircleCircle(a, world.bodies[j], world);
		for (const s of world.segments) resolveCircleSegment(a, s, world);
		for (const r of world.rects) resolveCircleRect(a, r, world);
	}
}
function stepParticles(world, dt) {
	const next = [];
	for (const p of world.particles) {
		p.age += dt;
		if (p.age >= p.life) continue;
		p.x += p.vx * dt;
		p.y += p.vy * dt;
		p.vy += world.gy * dt * .35;
		next.push(p);
	}
	world.particles = next;
}
function inZone(b, z) {
	return b.x > z.x && b.x < z.x + z.w && b.y > z.y && b.y < z.y + z.h;
}
function stepWorld(world, dt) {
	world.events.length = 0;
	world.time += dt;
	applyForces(world, dt);
	integrate(world, dt);
	collideAll(world);
	collideAll(world);
	bounds(world);
	stepParticles(world, dt);
}
function predictTrajectory(world, x, y, vx, vy, seconds = 2.4, dt = 1 / 60) {
	const pts = [];
	let cx = x;
	let cy = y;
	let cvx = vx;
	let cvy = vy;
	const steps = Math.floor(seconds / dt);
	for (let i = 0; i < steps; i++) {
		pts.push({
			x: cx,
			y: cy
		});
		let fx = world.gx;
		let fy = world.gy;
		for (const well of world.wells) {
			const dx = well.x - cx;
			const dy = well.y - cy;
			const r2 = dx * dx + dy * dy + .12;
			const inv = well.gm / (r2 * Math.sqrt(r2));
			fx += dx * inv;
			fy += dy * inv;
		}
		cvx += fx * dt;
		cvy += fy * dt;
		cx += cvx * dt;
		cy += cvy * dt;
		if (world.groundY !== null && cy < world.groundY) break;
		if (cx < -2 || cx > world.width + 2 || cy < -2 || cy > world.height + 2) break;
	}
	return pts;
}
var STEEL = "#c5cdd8";
var MASS = "#d4c4b0";
var ICE = "#8eb4d3";
var WARM = "#d08a7a";
var OK = "#8fbfa8";
function idle() {
	return {
		complete: false,
		stars: 0,
		detail: ""
	};
}
var LABS = [
	{
		id: "inertia",
		index: 1,
		chapter: "I",
		title: "Inertia",
		formula: "F_net = 0  ⇒  v = const",
		summary: "An object keeps its velocity unless a force acts on it.",
		theory: [
			"Newton’s first law is not about rest. It is about velocity: speed and direction stay the same when the net force is zero.",
			"On a frictionless table a puck never slows down. Slowing down is evidence of a force — usually friction.",
			"Drag the puck and let go. With friction off it will slide until a wall pushes back."
		],
		objective: "Dock the puck in the bay. A gentle arrival scores higher — inertia does not mean you cannot aim.",
		hint: "Throw softly and use a wall bounce as a planned force, not an accident.",
		interact: "Drag the puck to throw it. Toggle friction to feel the first law fail.",
		controls: [{
			key: "friction",
			label: "Friction",
			kind: "slider",
			min: 0,
			max: 1.4,
			step: .05,
			unit: ""
		}],
		build: () => {
			const w = makeWorld({
				width: 16,
				height: 9,
				bounceBounds: true,
				gy: 0,
				meta: {
					friction: 0,
					entered: 0,
					vAtEnter: 0
				}
			});
			w.bodies.push(makeBody({
				id: "puck",
				x: 2.6,
				y: 4.5,
				mass: 1,
				radius: .38,
				color: MASS,
				label: "1 kg",
				role: "player",
				restitution: .86,
				drag: 0
			}));
			w.rects.push({
				id: "wall-a",
				x: 7.2,
				y: 0,
				w: .35,
				h: 3.2,
				restitution: .9,
				color: STEEL,
				fill: "#1a1b20",
				vx: 0,
				vy: 0,
				solid: true
			}, {
				id: "wall-b",
				x: 7.2,
				y: 5.8,
				w: .35,
				h: 3.2,
				restitution: .9,
				color: STEEL,
				fill: "#1a1b20",
				vx: 0,
				vy: 0,
				solid: true
			});
			w.zones.push({
				id: "bay",
				x: 13.3,
				y: 3.4,
				w: 2.3,
				h: 2.2,
				kind: "goal",
				color: OK,
				label: "BAY"
			});
			return w;
		},
		applyControl: (world, key, value) => {
			if (key === "friction") {
				world.meta.friction = value;
				const puck = world.bodies[0];
				if (puck) puck.drag = value * .22;
			}
		},
		evaluate: (world) => {
			const puck = world.bodies[0];
			const bay = world.zones[0];
			if (!puck || !bay) return idle();
			if (inZone(puck, bay)) {
				const sp = Math.hypot(puck.vx, puck.vy);
				world.meta.entered = 1;
				world.meta.vAtEnter = sp;
				if (sp < 1.15) return {
					complete: true,
					stars: 3,
					detail: "Docked. Velocity nearly spent by design, not friction."
				};
				if (sp < 2.6) return {
					complete: true,
					stars: 2,
					detail: "In the bay. A slower approach would have been cleaner."
				};
				return {
					complete: true,
					stars: 1,
					detail: "You arrived. The first law did the rest."
				};
			}
			return idle();
		}
	},
	{
		id: "force",
		index: 2,
		chapter: "I",
		title: "Force & Mass",
		formula: "F = m a",
		summary: "The same push accelerates a light mass more than a heavy one.",
		theory: [
			"Force does not set speed. It sets how quickly velocity changes — acceleration.",
			"Rearranged: a = F / m. Double the mass, halve the acceleration, for the same force.",
			"A force of 6 N on 3 kg gives a = 2 m/s². After 2 seconds, v = 4 m/s, if it started at rest."
		],
		objective: "Drive the 3 kg crate across the line at 4.0 m/s (within 0.4). Same force, different mass — compare the 1 kg companion.",
		hint: "a = F/m. For 3 kg and a target of 4 m/s you need Δv = 4, so t = 4 / (F/3).",
		interact: "Set a constant force. Both crates feel it. Watch the acceleration arrows.",
		controls: [{
			key: "force",
			label: "Force",
			kind: "slider",
			min: -12,
			max: 12,
			step: .5,
			unit: "N"
		}],
		build: () => {
			const w = makeWorld({
				width: 16,
				height: 8,
				bounceBounds: true,
				gy: 0,
				meta: {
					force: 0,
					crossed: 0,
					vCross: 0
				}
			});
			w.bodies.push(makeBody({
				id: "light",
				x: 2.2,
				y: 5.4,
				mass: 1,
				radius: .32,
				color: ICE,
				label: "1 kg",
				restitution: .2,
				drag: 0
			}), makeBody({
				id: "heavy",
				x: 2.2,
				y: 2.6,
				mass: 3,
				radius: .5,
				color: MASS,
				label: "3 kg",
				role: "player",
				restitution: .2,
				drag: 0
			}));
			w.rects.push({
				id: "line",
				x: 12.9,
				y: 0,
				w: .08,
				h: 8,
				restitution: 0,
				color: OK,
				fill: "rgba(143,191,168,0.15)",
				vx: 0,
				vy: 0,
				solid: false
			});
			w.zones.push({
				id: "finish",
				x: 12.9,
				y: 0,
				w: 2.8,
				h: 8,
				kind: "goal",
				color: OK,
				label: "FINISH"
			});
			w.bodies.forEach((b) => {
				b.forceX = 0;
			});
			return w;
		},
		applyControl: (world, key, value) => {
			if (key === "force") {
				world.meta.force = value;
				for (const b of world.bodies) b.forceX = value;
			}
		},
		evaluate: (world) => {
			const heavy = world.bodies.find((b) => b.id === "heavy");
			if (!heavy) return idle();
			if (heavy.x > 12.9 && world.meta.crossed === 0) {
				world.meta.crossed = 1;
				world.meta.vCross = heavy.vx;
				const err = Math.abs(heavy.vx - 4);
				if (err <= .35) return {
					complete: true,
					stars: 3,
					detail: `v = ${heavy.vx.toFixed(2)} m/s at the line. F = ma held.`
				};
				if (err <= .85) return {
					complete: true,
					stars: 2,
					detail: `v = ${heavy.vx.toFixed(2)} m/s. Close to 4.0.`
				};
				if (heavy.vx > .4) return {
					complete: true,
					stars: 1,
					detail: `Crossed at ${heavy.vx.toFixed(2)} m/s. Target was 4.0.`
				};
			}
			return idle();
		}
	},
	{
		id: "gravity",
		index: 3,
		chapter: "I",
		title: "Free Fall",
		formula: "a = g  (vacuum)",
		summary: "Mass cancels. In vacuum everything falls together.",
		theory: [
			"Weight is mg, a force. Acceleration is F/m, so a = g. The mass in the force is the same mass that resists acceleration.",
			"Air drag is a second force that depends on speed and shape, not on mass in the same way. That is why a feather lags.",
			"Time a drop onto the cart. Horizontal motion of the cart and vertical free-fall are independent."
		],
		objective: "Land the mass on the moving cart on the first drop.",
		hint: "The fall from 12 m takes about √(2h/g) ≈ 1.56 s. Watch the cart’s period.",
		interact: "The ball is held until you release. Air drag can be added to break the law.",
		controls: [{
			key: "air",
			label: "Air drag",
			kind: "slider",
			min: 0,
			max: .35,
			step: .01,
			unit: ""
		}, {
			key: "release",
			label: "Release",
			kind: "action",
			actionLabel: "Drop"
		}],
		build: () => {
			const w = makeWorld({
				width: 12,
				height: 14,
				gy: -9.81,
				bounceBounds: true,
				groundY: 0,
				meta: {
					air: 0,
					held: 1,
					drops: 0,
					landed: 0
				}
			});
			w.bodies.push(makeBody({
				id: "ball",
				x: 6,
				y: 12.2,
				mass: 2,
				radius: .36,
				color: MASS,
				label: "2 kg",
				role: "player",
				restitution: .18,
				drag: 0,
				fixed: true
			}));
			w.rects.push({
				id: "cart",
				x: 1.2,
				y: .35,
				w: 1.9,
				h: .55,
				restitution: .1,
				color: STEEL,
				fill: "#22242a",
				role: "cart",
				vx: 0,
				vy: 0,
				solid: true
			});
			return w;
		},
		tick: (world) => {
			const cart = world.rects.find((r) => r.role === "cart");
			if (cart) cart.x = 6 - cart.w / 2 + 3.6 * Math.sin(world.time * .85);
			const ball = world.bodies[0];
			if (ball && world.meta.held === 1) {
				ball.x = 6;
				ball.y = 12.2;
				ball.vx = 0;
				ball.vy = 0;
				ball.fixed = true;
			}
		},
		applyControl: (world, key, value) => {
			if (key === "air") {
				world.meta.air = value;
				const ball = world.bodies[0];
				if (ball) ball.drag = value;
			}
		},
		action: (world, key) => {
			if (key === "release") {
				const ball = world.bodies[0];
				if (!ball) return;
				if (world.meta.held === 1) {
					world.meta.held = 0;
					world.meta.drops += 1;
					ball.fixed = false;
					ball.vx = 0;
					ball.vy = 0;
				}
			}
		},
		evaluate: (world) => {
			const ball = world.bodies[0];
			const cart = world.rects.find((r) => r.role === "cart");
			if (!ball || !cart || world.meta.held === 1) return idle();
			if (ball.y - ball.radius <= cart.y + cart.h + .12 && ball.y > cart.y && ball.x > cart.x - .05 && ball.x < cart.x + cart.w + .05 && ball.vy <= .8) {
				const centered = Math.abs(ball.x - (cart.x + cart.w / 2)) < .45;
				const first = world.meta.drops <= 1;
				if (first && centered) return {
					complete: true,
					stars: 3,
					detail: "Independent components: the cart moved in x, the mass in y."
				};
				if (first) return {
					complete: true,
					stars: 2,
					detail: "On the cart. A more centered landing would be three stars."
				};
				return {
					complete: true,
					stars: 1,
					detail: "Landed. Free-fall time is independent of mass."
				};
			}
			return idle();
		}
	},
	{
		id: "projectile",
		index: 4,
		chapter: "I",
		title: "Projectiles",
		formula: "R = v² sin(2θ) / g",
		summary: "Horizontal motion is uniform. Vertical motion is free-fall.",
		theory: [
			"Once launched, the only force (ignoring air) is weight, which is vertical. vx never changes.",
			"Range on flat ground is greatest at 45°, because sin(2θ) peaks there. Complementary angles (30° and 60°) share a range.",
			"The dashed curve is the kinematic prediction — not a suggestion. Fire when it threads the target."
		],
		objective: "Hit the target. First-shot hits are three stars.",
		hint: "For a level target, 45° maximises range. You may need a steeper or shallower shot from here.",
		interact: "Set angle and speed, then fire. The ghost path uses the same equations as the ball.",
		controls: [
			{
				key: "angle",
				label: "Angle",
				kind: "slider",
				min: 12,
				max: 78,
				step: 1,
				unit: "°"
			},
			{
				key: "speed",
				label: "Speed",
				kind: "slider",
				min: 4,
				max: 18,
				step: .2,
				unit: "m/s"
			},
			{
				key: "fire",
				label: "Fire",
				kind: "action",
				actionLabel: "Fire"
			}
		],
		build: () => {
			const w = makeWorld({
				width: 18,
				height: 10,
				gy: -9.81,
				bounceBounds: false,
				groundY: 0,
				meta: {
					angle: 48,
					speed: 12,
					shots: 0,
					flying: 0,
					hit: 0
				}
			});
			w.bodies.push(makeBody({
				id: "shot",
				x: 1.6,
				y: .95,
				mass: .8,
				radius: .28,
				color: MASS,
				label: "m",
				role: "player",
				restitution: .35,
				fixed: true
			}));
			w.rects.push({
				id: "cannon",
				x: .6,
				y: 0,
				w: 1.3,
				h: .7,
				restitution: 0,
				color: STEEL,
				fill: "#1c1e24",
				vx: 0,
				vy: 0,
				solid: true
			});
			w.zones.push({
				id: "target",
				x: 13.6,
				y: 1.4,
				w: 1.5,
				h: 1.5,
				kind: "goal",
				color: WARM,
				label: "TARGET"
			});
			return w;
		},
		applyControl: (world, key, value) => {
			if (key === "angle") world.meta.angle = value;
			if (key === "speed") world.meta.speed = value;
		},
		action: (world, key) => {
			if (key !== "fire") return;
			const b = world.bodies[0];
			if (!b) return;
			const th = world.meta.angle * Math.PI / 180;
			const v = world.meta.speed;
			b.x = 1.6;
			b.y = .95;
			b.vx = Math.cos(th) * v;
			b.vy = Math.sin(th) * v;
			b.fixed = false;
			world.meta.shots += 1;
			world.meta.flying = 1;
		},
		evaluate: (world) => {
			const b = world.bodies[0];
			const z = world.zones[0];
			if (!b || !z || world.meta.flying !== 1) return idle();
			if (inZone(b, z)) {
				const n = world.meta.shots;
				if (n <= 1) return {
					complete: true,
					stars: 3,
					detail: "First shot. The parabola is not a guess."
				};
				if (n <= 3) return {
					complete: true,
					stars: 2,
					detail: `Hit on shot ${n}. Complementary angles share a range.`
				};
				return {
					complete: true,
					stars: 1,
					detail: "On target. Horizontal and vertical motions really are independent."
				};
			}
			return idle();
		}
	},
	{
		id: "momentum",
		index: 5,
		chapter: "II",
		title: "Momentum",
		formula: "p = m v    Σp conserved",
		summary: "Isolated collisions trade velocity so that total momentum stays put.",
		theory: [
			"Momentum is mass times velocity — a vector. Two equal masses exchanging velocity in a head-on elastic hit is the cleanest picture.",
			"If the target is at rest, a cue of equal mass stops and the target takes the velocity (elastic, 1D).",
			"Watch the Σp readout. It should barely move. Kinetic energy is conserved only if the collision is elastic."
		],
		objective: "Pocket the marked mass with a single collision. Do not sink the cue.",
		hint: "Equal masses, elastic, head-on: the cue should almost stop. Aim through the center.",
		interact: "Drag the cue back and throw it. The hit is elastic.",
		controls: [],
		build: () => {
			const w = makeWorld({
				width: 16,
				height: 9,
				bounceBounds: true,
				gy: 0,
				meta: {
					pocketed: 0,
					cueIn: 0
				}
			});
			w.bodies.push(makeBody({
				id: "cue",
				x: 3.2,
				y: 4.5,
				mass: 1,
				radius: .36,
				color: ICE,
				label: "cue",
				role: "player",
				restitution: .98
			}), makeBody({
				id: "obj",
				x: 8.2,
				y: 4.5,
				mass: 1,
				radius: .36,
				color: WARM,
				label: "m",
				role: "target",
				restitution: .98
			}));
			w.zones.push({
				id: "pocket",
				x: 13.6,
				y: 3.5,
				w: 2,
				h: 2,
				kind: "pocket",
				color: OK,
				label: "POCKET"
			});
			return w;
		},
		evaluate: (world) => {
			const cue = world.bodies.find((b) => b.id === "cue");
			const obj = world.bodies.find((b) => b.id === "obj");
			const z = world.zones[0];
			if (!cue || !obj || !z) return idle();
			const objIn = inZone(obj, z);
			const cueIn = inZone(cue, z);
			if (objIn && !cueIn) return {
				complete: true,
				stars: 3,
				detail: "One collision, cue spared. Momentum moved; it did not vanish."
			};
			if (objIn && cueIn) return {
				complete: true,
				stars: 1,
				detail: "Both fell in. The transfer worked — the aim was wide."
			};
			return idle();
		}
	},
	{
		id: "energy",
		index: 6,
		chapter: "II",
		title: "Energy",
		formula: "E = ½mv² + mgh",
		summary: "Height is stored motion. Motion is spent height.",
		theory: [
			"Gravitational potential energy is mgh, measured from any zero you choose. Kinetic energy is ½mv².",
			"Without friction the sum is constant. A ball that starts 4 m above the valley floor can climb 4 m on the far side — not more.",
			"The bell sits above the valley. Release from the lowest height that still rings it. Extra height is wasted energy."
		],
		objective: "Ring the bell. Three stars if you start no higher than you must.",
		hint: "The bell is at 5.4 m. With no friction you need PE at least mg × 5.4.",
		interact: "Set release height, then drop. Watch KE and PE trade in the instruments.",
		controls: [{
			key: "height",
			label: "Release height",
			kind: "slider",
			min: 2.2,
			max: 8.4,
			step: .1,
			unit: "m"
		}, {
			key: "drop",
			label: "Drop",
			kind: "action",
			actionLabel: "Release"
		}],
		build: () => {
			const w = makeWorld({
				width: 16,
				height: 10,
				gy: -9.81,
				bounceBounds: false,
				groundY: 0,
				meta: {
					height: 6.2,
					held: 1,
					rang: 0
				}
			});
			applyEnergyHill(w, 6.2);
			w.bodies.push(makeBody({
				id: "ball",
				x: 1.7,
				y: 6.2 + .32,
				mass: 1,
				radius: .32,
				color: MASS,
				label: "1 kg",
				role: "player",
				restitution: .18,
				friction: .02,
				fixed: true
			}));
			w.zones.push({
				id: "bell",
				x: 11.6,
				y: 5.45,
				w: 1.5,
				h: 1.3,
				kind: "bell",
				color: "#c4a574",
				label: "BELL"
			});
			return w;
		},
		tick: (world) => {
			const b = world.bodies[0];
			if (!b) return;
			if (world.meta.held === 1) {
				const h = world.meta.height;
				applyEnergyHill(world, h);
				b.x = 1.7;
				b.y = h + b.radius + .03;
				b.vx = 0;
				b.vy = 0;
				b.fixed = true;
			}
		},
		applyControl: (world, key, value) => {
			if (key === "height") world.meta.height = value;
		},
		action: (world, key) => {
			if (key === "drop") {
				const b = world.bodies[0];
				if (!b) return;
				world.meta.held = 0;
				b.fixed = false;
				b.vx = 0;
				b.vy = 0;
			}
		},
		evaluate: (world) => {
			const b = world.bodies[0];
			const z = world.zones[0];
			if (!b || !z || world.meta.held === 1) return idle();
			if (inZone(b, z) || b.x > 11.4 && b.x < 13.2 && b.y > 5.35) {
				const h = world.meta.height;
				if (h <= 6) return {
					complete: true,
					stars: 3,
					detail: "Minimum PE that still reaches the bell. Nothing wasted."
				};
				if (h <= 7.2) return {
					complete: true,
					stars: 2,
					detail: "Rung. You had surplus height — surplus energy."
				};
				return {
					complete: true,
					stars: 1,
					detail: "The bell rang. Energy changed form; the sum barely moved."
				};
			}
			return idle();
		}
	},
	{
		id: "spring",
		index: 7,
		chapter: "II",
		title: "Springs",
		formula: "F = −k x     U = ½ k x²",
		summary: "A spring stores energy in stretch and returns it as motion.",
		theory: [
			"Hooke’s law: the restoring force is proportional to displacement from rest, and opposite in direction.",
			"The energy stored is ½kx². Launching a mass converts that into kinetic energy, then into gravitational PE if it climbs.",
			"Period of SHM is 2π√(m/k) — independent of how far you pull, as long as the spring stays linear."
		],
		objective: "Compress a vertical spring so the mass just reaches the marker.",
		hint: "½kx² = mgh at the top. For k = 48 and h = 5.2 m, x ≈ √(2mgh/k) ≈ 1.46 m.",
		interact: "Set compression, then release. Watch PE in the spring become height.",
		controls: [
			{
				key: "k",
				label: "Stiffness k",
				kind: "slider",
				min: 20,
				max: 90,
				step: 1,
				unit: "N/m"
			},
			{
				key: "comp",
				label: "Compression",
				kind: "slider",
				min: .3,
				max: 2.2,
				step: .05,
				unit: "m"
			},
			{
				key: "launch",
				label: "Release",
				kind: "action",
				actionLabel: "Release"
			}
		],
		build: () => {
			const w = makeWorld({
				width: 12,
				height: 10,
				gy: -9.81,
				bounceBounds: true,
				groundY: 0,
				meta: {
					k: 48,
					comp: 1.4,
					held: 1,
					landed: 0,
					apex: 0
				}
			});
			const rest = 2.4;
			w.bodies.push(makeBody({
				id: "mass",
				x: 6,
				y: 1.38,
				mass: 1,
				radius: .38,
				color: MASS,
				label: "1 kg",
				role: "player",
				restitution: .2,
				friction: .04,
				fixed: true
			}));
			w.springs.push({
				id: "s",
				a: "mass",
				ax: 6,
				ay: .15,
				rest,
				k: 48,
				c: .8
			});
			w.zones.push({
				id: "mark",
				x: 5.1,
				y: 5,
				w: 1.8,
				h: .7,
				kind: "pad",
				color: OK,
				label: "MARK"
			});
			w.rects.push({
				id: "base",
				x: 5.55,
				y: 0,
				w: .9,
				h: .18,
				restitution: .1,
				color: STEEL,
				fill: "#1c1e24",
				vx: 0,
				vy: 0,
				solid: true
			});
			return w;
		},
		tick: (world) => {
			const b = world.bodies[0];
			const s = world.springs[0];
			if (!b || !s) return;
			s.k = world.meta.k;
			if (world.meta.held === 1) {
				const y = Math.max(b.radius + .2, s.ay + s.rest - world.meta.comp);
				b.x = 6;
				b.y = y;
				b.vx = 0;
				b.vy = 0;
				b.fixed = true;
			} else if (world.springs.length > 0) {
				if (Math.hypot(b.x - s.ax, b.y - s.ay) >= s.rest && b.vy >= -.05) world.springs = [];
			}
		},
		applyControl: (world, key, value) => {
			if (key === "k") world.meta.k = value;
			if (key === "comp") world.meta.comp = value;
		},
		action: (world, key) => {
			if (key === "launch") {
				const b = world.bodies[0];
				if (!b) return;
				world.meta.held = 0;
				b.fixed = false;
			}
		},
		evaluate: (world) => {
			const b = world.bodies[0];
			const z = world.zones[0];
			if (!b || !z || world.meta.held === 1) return idle();
			const apex = Math.max(world.meta.apex || 0, b.y);
			world.meta.apex = apex;
			const reached = world.meta.apex >= 5.15;
			const falling = b.vy < 0 && world.meta.apex > 1.5;
			if (reached && falling) {
				const over = world.meta.apex - 5.35;
				if (over >= 0 && over < .55) return {
					complete: true,
					stars: 3,
					detail: "Just to the mark. ½kx² paid for mgh, almost nothing left."
				};
				if (over < 1.6) return {
					complete: true,
					stars: 2,
					detail: "Past the mark. A little less compression would be exact."
				};
				return {
					complete: true,
					stars: 1,
					detail: "You reached it. Spring PE became gravitational PE."
				};
			}
			return idle();
		}
	},
	{
		id: "orbit",
		index: 8,
		chapter: "III",
		title: "Orbits",
		formula: "v = √(GM / r)",
		summary: "An orbit is perpetual free-fall missing the ground.",
		theory: [
			"Newton’s gravity is inverse-square. The same law that drops an apple bends a moon into a closed path.",
			"For a circular orbit, centripetal acceleration v²/r equals GM/r², so v = √(GM/r). Too slow and you fall in; too fast and you leave.",
			"Place the craft, set its velocity with the handle, then engage. A thin ellipse is still an orbit. A circle is the special case."
		],
		objective: "Stay in a bound orbit for eight seconds without hitting the planet.",
		hint: "Start at r = 4 m. Circular speed is √(GM/r) with GM = 90, so about 4.7 m/s, tangent.",
		interact: "Drag the craft to place it. Drag the ice handle to set velocity. Press Engage.",
		controls: [{
			key: "engage",
			label: "Engage",
			kind: "action",
			actionLabel: "Engage"
		}],
		build: () => {
			const w = makeWorld({
				width: 16,
				height: 16,
				gy: 0,
				bounceBounds: false,
				meta: {
					setup: 1,
					alive: 0,
					rmin: 99,
					rmax: 0,
					crashed: 0,
					escaped: 0
				}
			});
			w.wells.push({
				id: "star",
				x: 8,
				y: 8,
				gm: 90,
				radius: 1.25,
				color: "#b7b1a6",
				label: "M"
			});
			w.bodies.push(makeBody({
				id: "craft",
				x: 8,
				y: 12,
				mass: 1,
				radius: .22,
				color: ICE,
				label: "m",
				role: "craft",
				restitution: .1,
				fixed: true
			}));
			w.meta.vx0 = 4.74;
			w.meta.vy0 = 0;
			return w;
		},
		tick: (world) => {
			const b = world.bodies[0];
			const well = world.wells[0];
			if (!b || !well) return;
			if (world.meta.setup === 1) {
				b.fixed = true;
				b.vx = 0;
				b.vy = 0;
				return;
			}
			const r = Math.hypot(b.x - well.x, b.y - well.y);
			world.meta.rmin = Math.min(world.meta.rmin, r);
			world.meta.rmax = Math.max(world.meta.rmax, r);
			world.meta.alive += 1 / 120;
			if (r < well.radius + b.radius) world.meta.crashed = 1;
			if (r > 9.5) world.meta.escaped = 1;
		},
		action: (world, key) => {
			if (key !== "engage") return;
			const b = world.bodies[0];
			if (!b) return;
			world.meta.setup = 0;
			world.meta.alive = 0;
			world.meta.rmin = 99;
			world.meta.rmax = 0;
			world.meta.crashed = 0;
			world.meta.escaped = 0;
			b.fixed = false;
			b.vx = world.meta.vx0 ?? 4.7;
			b.vy = world.meta.vy0 ?? 0;
		},
		evaluate: (world) => {
			if (world.meta.setup === 1) return idle();
			if (world.meta.crashed === 1) return idle();
			if (world.meta.escaped === 1) return idle();
			const t = world.meta.alive;
			const rmin = world.meta.rmin;
			const rmax = world.meta.rmax;
			const e = rmax + rmin > 0 ? (rmax - rmin) / (rmax + rmin) : 1;
			if (t >= 8 && rmin > 1.6) {
				if (e < .18) return {
					complete: true,
					stars: 3,
					detail: `Nearly circular (e ≈ ${e.toFixed(2)}). Free-fall, forever missing.`
				};
				if (e < .55) return {
					complete: true,
					stars: 2,
					detail: `Bound ellipse (e ≈ ${e.toFixed(2)}). Kepler would approve.`
				};
				return {
					complete: true,
					stars: 1,
					detail: "Bound for eight seconds. An orbit is just a long fall."
				};
			}
			return idle();
		}
	},
	{
		id: "sandbox",
		index: 9,
		chapter: "III",
		title: "Sandbox",
		formula: "F = ma",
		summary: "No prompt. Spawn masses, pull them, add a well, watch what the laws do.",
		theory: ["Everything in the campaign is the same three ideas: inertia, F = ma, and pairwise forces.", "Spawn with a tap on empty space. Drag to throw. Toggle gravity or drop a well in the middle."],
		objective: "There is no test. Stay until something surprises you.",
		hint: "Two masses and a well is already a three-body problem.",
		interact: "Tap empty space to spawn. Drag to throw. Use the controls to change the world.",
		sandbox: true,
		controls: [
			{
				key: "g",
				label: "Gravity g",
				kind: "slider",
				min: 0,
				max: 14,
				step: .2,
				unit: "m/s²"
			},
			{
				key: "well",
				label: "Central well",
				kind: "toggle"
			},
			{
				key: "clear",
				label: "Clear",
				kind: "action",
				actionLabel: "Clear masses"
			}
		],
		build: () => {
			const w = makeWorld({
				width: 16,
				height: 10,
				gy: -9.81,
				bounceBounds: true,
				groundY: 0,
				meta: {
					g: 9.81,
					well: 0,
					spawn: 0
				}
			});
			w.bodies.push(makeBody({
				id: "a",
				x: 5,
				y: 6,
				mass: 1,
				radius: .36,
				color: MASS,
				label: "1"
			}), makeBody({
				id: "b",
				x: 9,
				y: 4.5,
				mass: 2,
				radius: .48,
				color: ICE,
				label: "2"
			}));
			return w;
		},
		applyControl: (world, key, value) => {
			if (key === "g") {
				world.meta.g = value;
				world.gy = -value;
			}
			if (key === "well") {
				world.meta.well = value;
				world.wells = value ? [{
					id: "w",
					x: 8,
					y: 5,
					gm: 70,
					radius: .9,
					color: "#b7b1a6",
					label: "M"
				}] : [];
				world.gy = value ? 0 : -(world.meta.g || 9.81);
				world.groundY = value ? null : 0;
			}
		},
		action: (world, key) => {
			if (key === "clear") world.bodies = world.bodies.filter((b) => b.grabbed);
		},
		evaluate: () => idle()
	}
];
function getLab(id) {
	return LABS.find((l) => l.id === id);
}
LABS.map((l) => l.id);
function nextLabId(id) {
	const i = LABS.findIndex((l) => l.id === id);
	if (i < 0 || i >= LABS.length - 1) return null;
	return LABS[i + 1].id;
}
function applyEnergyHill(world, height) {
	const h = clamp(height, 2.2, 8.4);
	const pts = [
		[0, h],
		[2.6, h],
		[5.4, 1.15],
		[8.6, 1.15],
		[11.2, 5.4],
		[13.6, 5.4],
		[16, 3.2]
	];
	world.segments = pts.slice(0, -1).map((a, i) => {
		const b = pts[i + 1];
		return {
			id: `s${i}`,
			x1: a[0],
			y1: a[1],
			x2: b[0],
			y2: b[1],
			restitution: .08,
			color: STEEL
		};
	});
}
var KEY = "principia-save-v1";
var DEFAULTS = {
	version: 1,
	completed: {},
	settings: {
		sound: true,
		vectors: true,
		shake: true
	}
};
function migrate(raw) {
	return {
		version: 1,
		completed: {
			...DEFAULTS.completed,
			...raw.completed
		},
		settings: {
			...DEFAULTS.settings,
			...raw.settings
		}
	};
}
function loadSave() {
	try {
		const raw = localStorage.getItem(KEY);
		if (!raw) return structuredClone(DEFAULTS);
		return migrate(JSON.parse(raw));
	} catch {
		return structuredClone(DEFAULTS);
	}
}
function writeSave(state) {
	try {
		localStorage.setItem(KEY, JSON.stringify({
			...state,
			version: 1
		}));
	} catch {}
}
function isUnlocked(id, completed) {
	const lab = LABS.find((l) => l.id === id);
	if (!lab) return false;
	if (lab.sandbox) return true;
	if (lab.index <= 1) return true;
	const prev = LABS.find((l) => l.index === lab.index - 1);
	if (!prev) return true;
	return Boolean(completed[prev.id]);
}
function campaignLabsCompleted(completed) {
	return LABS.filter((l) => !l.sandbox && completed[l.id]).length;
}
function firstIncomplete(completed) {
	for (const lab of LABS) {
		if (lab.sandbox) continue;
		if (!completed[lab.id]) return lab.id;
	}
	return "sandbox";
}
function totalStars(completed) {
	return Object.values(completed).reduce((n, v) => n + (v?.stars ?? 0), 0);
}
var ctx = null;
var master = null;
var sfx = null;
var enabled = true;
function ac() {
	if (typeof window === "undefined") return null;
	if (!ctx) {
		const Ctor = window.AudioContext || window.webkitAudioContext;
		if (!Ctor) return null;
		ctx = new Ctor({ latencyHint: "interactive" });
		master = ctx.createGain();
		sfx = ctx.createGain();
		sfx.gain.value = .7;
		master.gain.value = enabled ? .85 : 0;
		sfx.connect(master);
		master.connect(ctx.destination);
	}
	return ctx;
}
function unlockAudio() {
	const c = ac();
	if (!c) return;
	if (c.state === "suspended") c.resume();
}
function setSoundEnabled(on) {
	enabled = on;
	const c = ac();
	if (c && master) master.gain.setTargetAtTime(on ? .85 : 0, c.currentTime, .03);
}
function envGain(c, peak, dur) {
	const g = c.createGain();
	g.gain.setValueAtTime(1e-4, c.currentTime);
	g.gain.exponentialRampToValueAtTime(Math.max(2e-4, peak), c.currentTime + .012);
	g.gain.exponentialRampToValueAtTime(1e-4, c.currentTime + dur);
	g.connect(sfx ?? c.destination);
	return g;
}
function playCollide(mag) {
	const c = ac();
	if (!c || !enabled) return;
	const peak = Math.min(.28, .05 + mag * .04);
	const osc = c.createOscillator();
	osc.type = "sine";
	const f = 90 + Math.min(220, mag * 28) + (Math.random() - .5) * 16;
	osc.frequency.setValueAtTime(f, c.currentTime);
	osc.frequency.exponentialRampToValueAtTime(40, c.currentTime + .12);
	osc.connect(envGain(c, peak, .14));
	osc.start();
	osc.stop(c.currentTime + .16);
}
function playLaunch() {
	const c = ac();
	if (!c || !enabled) return;
	const osc = c.createOscillator();
	osc.type = "triangle";
	osc.frequency.setValueAtTime(220, c.currentTime);
	osc.frequency.exponentialRampToValueAtTime(140, c.currentTime + .18);
	osc.connect(envGain(c, .12, .2));
	osc.start();
	osc.stop(c.currentTime + .22);
}
function playSuccess() {
	const c = ac();
	if (!c || !enabled) return;
	[
		392,
		494,
		587
	].forEach((f, i) => {
		const osc = c.createOscillator();
		osc.type = "sine";
		osc.frequency.value = f;
		const g = c.createGain();
		const t = c.currentTime + i * .09;
		g.gain.setValueAtTime(1e-4, t);
		g.gain.exponentialRampToValueAtTime(.14, t + .02);
		g.gain.exponentialRampToValueAtTime(1e-4, t + .28);
		osc.connect(g);
		g.connect(sfx ?? c.destination);
		osc.start(t);
		osc.stop(t + .3);
	});
}
function playClick() {
	const c = ac();
	if (!c || !enabled) return;
	const osc = c.createOscillator();
	osc.type = "square";
	osc.frequency.value = 880;
	osc.connect(envGain(c, .04, .05));
	osc.start();
	osc.stop(c.currentTime + .06);
}
function playBell() {
	const c = ac();
	if (!c || !enabled) return;
	const osc = c.createOscillator();
	osc.type = "sine";
	osc.frequency.setValueAtTime(740, c.currentTime);
	osc.frequency.exponentialRampToValueAtTime(620, c.currentTime + .4);
	osc.connect(envGain(c, .16, .45));
	osc.start();
	osc.stop(c.currentTime + .5);
}
if (typeof window !== "undefined") {
	const resume = () => {
		const c = ac();
		if (c && c.state === "suspended") c.resume();
	};
	document.addEventListener("visibilitychange", () => {
		if (document.visibilityState === "visible") resume();
	});
}
function persist(get) {
	const { completed, settings } = get();
	writeSave({
		version: 1,
		completed,
		settings
	});
}
var useProgress = create((set, get) => ({
	hydrated: false,
	completed: {},
	settings: {
		sound: true,
		vectors: true,
		shake: true
	},
	hydrate: () => {
		if (get().hydrated) return;
		const s = loadSave();
		setSoundEnabled(s.settings.sound);
		set({
			hydrated: true,
			completed: s.completed,
			settings: s.settings
		});
	},
	recordStars: (id, stars) => {
		if (stars <= (get().completed[id]?.stars ?? 0)) {
			if (!get().completed[id]) {
				set({ completed: {
					...get().completed,
					[id]: { stars }
				} });
				persist(get);
			}
			return;
		}
		set({ completed: {
			...get().completed,
			[id]: { stars }
		} });
		persist(get);
	},
	patchSettings: (p) => {
		const settings = {
			...get().settings,
			...p
		};
		if (p.sound !== void 0) setSoundEnabled(p.sound);
		set({ settings });
		persist(get);
	},
	unlocked: (id) => isUnlocked(id, get().completed),
	continueId: () => firstIncomplete(get().completed),
	campaignDone: () => campaignLabsCompleted(get().completed)
}));
//#endregion
export { stepWorld as C, unlockAudio as D, totalStars as E, useProgress as O, renderWorld as S, toWorld as T, playLaunch as _, cn as a, predictTrajectory as b, getLab as c, makeBody as d, momentum as f, playCollide as g, playClick as h, clamp as i, isUnlocked as l, playBell as m, LABS as n, fitView as o, nextLabId as p, StarRow as r, formatNum as s, Button as t, kinetic as u, playSuccess as v, toScreen as w, renderIdle as x, potential as y };
