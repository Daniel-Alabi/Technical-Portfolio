import { i as __toESM } from "../_runtime.mjs";
import { o as require_jsx_runtime, s as require_react } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { _ as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as Orbit, l as Lock, p as ArrowRight } from "../_libs/lucide-react.mjs";
import { D as unlockAudio, E as totalStars, O as useProgress, a as cn, n as LABS, r as StarRow, t as Button, x as renderIdle } from "./store-CfcFqHlv.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-MfeRLE6W.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function IdleCanvas({ className }) {
	const ref = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		const canvas = ref.current;
		if (!canvas) return;
		const ctx = canvas.getContext("2d");
		if (!ctx) return;
		let raf = 0;
		let running = true;
		const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
		const start = performance.now();
		const draw = (now) => {
			if (!running) return;
			const parent = canvas.parentElement;
			const w = parent?.clientWidth ?? 800;
			const h = parent?.clientHeight ?? 480;
			const dpr = Math.min(2, window.devicePixelRatio || 1);
			if (canvas.width !== Math.floor(w * dpr) || canvas.height !== Math.floor(h * dpr)) {
				canvas.width = Math.floor(w * dpr);
				canvas.height = Math.floor(h * dpr);
				canvas.style.width = `${w}px`;
				canvas.style.height = `${h}px`;
			}
			ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
			renderIdle(ctx, w, h, reduced ? 0 : (now - start) / 1e3);
			raf = requestAnimationFrame(draw);
		};
		raf = requestAnimationFrame(draw);
		return () => {
			running = false;
			cancelAnimationFrame(raf);
		};
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
		ref,
		className,
		"aria-hidden": true
	});
}
var CHAPTERS = [
	{
		id: "I",
		title: "Motion"
	},
	{
		id: "II",
		title: "Conservation"
	},
	{
		id: "III",
		title: "Fields"
	}
];
function HubView() {
	const hydrate = useProgress((s) => s.hydrate);
	const completed = useProgress((s) => s.completed);
	const unlocked = useProgress((s) => s.unlocked);
	const continueId = useProgress((s) => s.continueId);
	const campaignDone = useProgress((s) => s.campaignDone);
	(0, import_react.useEffect)(() => {
		hydrate();
	}, [hydrate]);
	const cont = continueId();
	const done = campaignDone();
	const stars = totalStars(completed);
	const contLab = LABS.find((l) => l.id === cont);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative min-h-dvh bg-bg text-fg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "grain absolute inset-0 opacity-80" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative mx-auto flex min-h-dvh max-w-6xl flex-col px-4 pb-16 pt-6 sm:px-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "flex items-center justify-between gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 text-muted",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Orbit, {
							className: "size-4 text-accent",
							strokeWidth: 1.6
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs font-medium uppercase tracking-[0.18em]",
							children: "Laboratory"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-mono text-xs tabular-nums text-muted",
						children: [
							done,
							"/8 · ",
							stars,
							"★"
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "mt-6 grid items-center gap-8 lg:grid-cols-[1.05fr_0.95fr] lg:gap-12",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "max-w-xl",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-medium uppercase tracking-[0.22em] text-muted",
								children: "A course in motion"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "font-display mt-3 text-[clamp(3.2rem,9vw,5.6rem)] leading-[0.92] tracking-[-0.03em] text-fg",
								children: "Principia"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-5 max-w-md text-[17px] leading-relaxed text-muted",
								children: "Eight experiments. The same laws. Drag a mass, fire a shot, fall around a planet — and watch the equations hold."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-8 flex flex-wrap items-center gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									asChild: true,
									size: "lg",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
										to: "/lab/$id",
										params: { id: cont },
										onClick: () => unlockAudio(),
										children: [done === 0 ? "Begin" : done >= 8 ? "Open sandbox" : "Continue", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" })]
									})
								}), contLab && done > 0 && done < 8 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-sm text-subtle",
									children: [
										"Next · ",
										String(contLab.index).padStart(2, "0"),
										" ",
										contLab.title
									]
								})]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative h-[220px] overflow-hidden rounded-[28px] border border-border bg-surface sm:h-[300px] lg:h-[340px]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IdleCanvas, { className: "absolute inset-0 size-full" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute inset-0 bg-gradient-to-r from-bg/40 to-transparent lg:from-transparent" })]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-14 space-y-10",
					children: CHAPTERS.map((ch) => {
						const labs = LABS.filter((l) => l.chapter === ch.id);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-4 flex items-baseline gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-display text-xl italic text-subtle",
								children: ch.id
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-sm font-medium uppercase tracking-[0.16em] text-muted",
								children: ch.title
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "grid gap-3 sm:grid-cols-2",
							children: labs.map((lab) => {
								const open = unlocked(lab.id);
								const rec = completed[lab.id];
								return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LabCard, {
									index: lab.index,
									title: lab.title,
									formula: lab.formula,
									summary: lab.summary,
									id: lab.id,
									locked: !open,
									stars: rec?.stars ?? 0,
									sandbox: lab.sandbox
								}) }, lab.id);
							})
						})] }, ch.id);
					})
				})
			]
		})]
	});
}
function LabCard({ index, title, formula, summary, id, locked, stars, sandbox }) {
	const inner = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: cn("group flex h-full flex-col rounded-[24px] border border-border bg-surface p-5 transition-[background-color,border-color] duration-200", locked ? "opacity-55" : "hover:border-accent/40 hover:bg-elevated"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-mono text-[11px] tabular-nums text-subtle",
					children: sandbox ? "FREE" : String(index).padStart(2, "0")
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "mt-1 font-display text-2xl tracking-tight text-fg",
					children: title
				})] }), locked ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lock, {
					className: "size-4 text-subtle",
					strokeWidth: 1.6
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StarRow, { n: stars })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 flex-1 text-sm leading-relaxed text-muted",
				children: summary
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 font-mono text-[12px] text-accent/90",
				children: formula
			})
		]
	});
	if (locked) return inner;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/lab/$id",
		params: { id },
		onClick: () => unlockAudio(),
		className: "block h-full",
		children: inner
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HubView, {});
}
//#endregion
export { Home as component };
