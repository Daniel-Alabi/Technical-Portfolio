//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-D-Ha2fxN.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/", "/lab/$id"],
		preloads: ["/assets/index-CxsXo_-A.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CxsXo_-A.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-CDp0cfqx.js", "/assets/store-Da2uZEbY.js"]
	},
	"/lab/$id": {
		filePath: "/workspace/src/routes/lab.$id.tsx",
		children: void 0,
		preloads: ["/assets/lab._id-CBn3d3gD.js", "/assets/store-Da2uZEbY.js"]
	}
} });
//#endregion
export { tsrStartManifest };
