import { useEffect } from "react";
import { Link } from "@tanstack/react-router";
import { ArrowRight, Lock, Orbit } from "lucide-react";
import { IdleCanvas } from "@/components/idle-canvas";
import { StarRow } from "@/components/star-row";
import { Button } from "@/components/ui/button";
import { LABS } from "@/lib/labs/catalog";
import { CHAPTERS, type LabId } from "@/lib/labs/types";
import { totalStars } from "@/lib/save";
import { useProgress } from "@/lib/store";
import { cn } from "@/lib/utils";
import { unlockAudio } from "@/lib/audio";

export function HubView() {
  const hydrate = useProgress((s) => s.hydrate);
  const completed = useProgress((s) => s.completed);
  const unlocked = useProgress((s) => s.unlocked);
  const continueId = useProgress((s) => s.continueId);
  const campaignDone = useProgress((s) => s.campaignDone);

  useEffect(() => {
    hydrate();
  }, [hydrate]);

  const cont = continueId();
  const done = campaignDone();
  const stars = totalStars(completed);
  const contLab = LABS.find((l) => l.id === cont);

  return (
    <div className="relative min-h-dvh bg-bg text-fg">
      <div className="grain absolute inset-0 opacity-80" />
      <div className="relative mx-auto flex min-h-dvh max-w-6xl flex-col px-4 pb-16 pt-6 sm:px-8">
        <header className="flex items-center justify-between gap-4">
          <div className="flex items-center gap-2 text-muted">
            <Orbit className="size-4 text-accent" strokeWidth={1.6} />
            <span className="text-xs font-medium uppercase tracking-[0.18em]">Laboratory</span>
          </div>
          <p className="font-mono text-xs tabular-nums text-muted">
            {done}/8 · {stars}★
          </p>
        </header>

        <section className="mt-6 grid items-center gap-8 lg:grid-cols-[1.05fr_0.95fr] lg:gap-12">
          <div className="max-w-xl">
            <p className="text-xs font-medium uppercase tracking-[0.22em] text-muted">A course in motion</p>
            <h1 className="font-display mt-3 text-[clamp(3.2rem,9vw,5.6rem)] leading-[0.92] tracking-[-0.03em] text-fg">
              Principia
            </h1>
            <p className="mt-5 max-w-md text-[17px] leading-relaxed text-muted">
              Eight experiments. The same laws. Drag a mass, fire a shot, fall around a planet — and watch the
              equations hold.
            </p>
            <div className="mt-8 flex flex-wrap items-center gap-3">
              <Button asChild size="lg">
                <Link
                  to="/lab/$id"
                  params={{ id: cont }}
                  onClick={() => unlockAudio()}
                >
                  {done === 0 ? "Begin" : done >= 8 ? "Open sandbox" : "Continue"}
                  <ArrowRight className="size-4" />
                </Link>
              </Button>
              {contLab && done > 0 && done < 8 && (
                <span className="text-sm text-subtle">
                  Next · {String(contLab.index).padStart(2, "0")} {contLab.title}
                </span>
              )}
            </div>
          </div>
          <div className="relative h-[220px] overflow-hidden rounded-[28px] border border-border bg-surface sm:h-[300px] lg:h-[340px]">
            <IdleCanvas className="absolute inset-0 size-full" />
            <div className="pointer-events-none absolute inset-0 bg-gradient-to-r from-bg/40 to-transparent lg:from-transparent" />
          </div>
        </section>

        <div className="mt-14 space-y-10">
          {CHAPTERS.map((ch) => {
            const labs = LABS.filter((l) => l.chapter === ch.id);
            return (
              <section key={ch.id}>
                <div className="mb-4 flex items-baseline gap-3">
                  <span className="font-display text-xl italic text-subtle">{ch.id}</span>
                  <h2 className="text-sm font-medium uppercase tracking-[0.16em] text-muted">{ch.title}</h2>
                </div>
                <ul className="grid gap-3 sm:grid-cols-2">
                  {labs.map((lab) => {
                    const open = unlocked(lab.id);
                    const rec = completed[lab.id as LabId];
                    return (
                      <li key={lab.id}>
                        <LabCard
                          index={lab.index}
                          title={lab.title}
                          formula={lab.formula}
                          summary={lab.summary}
                          id={lab.id}
                          locked={!open}
                          stars={rec?.stars ?? 0}
                          sandbox={lab.sandbox}
                        />
                      </li>
                    );
                  })}
                </ul>
              </section>
            );
          })}
        </div>
      </div>
    </div>
  );
}

function LabCard({
  index,
  title,
  formula,
  summary,
  id,
  locked,
  stars,
  sandbox,
}: {
  index: number;
  title: string;
  formula: string;
  summary: string;
  id: string;
  locked: boolean;
  stars: number;
  sandbox?: boolean;
}) {
  const inner = (
    <article
      className={cn(
        "group flex h-full flex-col rounded-[24px] border border-border bg-surface p-5 transition-[background-color,border-color] duration-200",
        locked ? "opacity-55" : "hover:border-accent/40 hover:bg-elevated",
      )}
    >
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="font-mono text-[11px] tabular-nums text-subtle">
            {sandbox ? "FREE" : String(index).padStart(2, "0")}
          </p>
          <h3 className="mt-1 font-display text-2xl tracking-tight text-fg">{title}</h3>
        </div>
        {locked ? (
          <Lock className="size-4 text-subtle" strokeWidth={1.6} />
        ) : (
          <StarRow n={stars} />
        )}
      </div>
      <p className="mt-3 flex-1 text-sm leading-relaxed text-muted">{summary}</p>
      <p className="mt-4 font-mono text-[12px] text-accent/90">{formula}</p>
    </article>
  );

  if (locked) return inner;
  return (
    <Link to="/lab/$id" params={{ id }} onClick={() => unlockAudio()} className="block h-full">
      {inner}
    </Link>
  );
}
