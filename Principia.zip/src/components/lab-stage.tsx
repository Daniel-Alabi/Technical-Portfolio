import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Link, useNavigate } from "@tanstack/react-router";
import {
  ArrowLeft,
  BookOpen,
  Eye,
  EyeOff,
  Pause,
  Play,
  RotateCcw,
  Volume2,
  VolumeX,
} from "lucide-react";
import { StarRow } from "@/components/star-row";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { getLab, nextLabId } from "@/lib/labs/catalog";
import type { LabId } from "@/lib/labs/types";
import { isUnlocked } from "@/lib/save";
import { formatNum } from "@/lib/physics/math";
import { LabRuntime, type RuntimeSnapshot } from "@/lib/physics/runtime";
import { useProgress } from "@/lib/store";
import { playClick, unlockAudio } from "@/lib/audio";

const emptySnap: RuntimeSnapshot = {
  telemetry: {
    t: 0,
    mass: 0,
    vx: 0,
    vy: 0,
    speed: 0,
    ax: 0,
    ay: 0,
    ke: 0,
    pe: 0,
    e: 0,
    px: 0,
    py: 0,
  },
  paused: false,
  complete: false,
  stars: 0,
  detail: "",
  meta: {},
};

export function LabStage({ id }: { id: string }) {
  const lab = getLab(id);
  const navigate = useNavigate();
  const hydrate = useProgress((s) => s.hydrate);
  const recordStars = useProgress((s) => s.recordStars);
  const settings = useProgress((s) => s.settings);
  const patchSettings = useProgress((s) => s.patchSettings);
  const completed = useProgress((s) => s.completed);

  const canvasRef = useRef<HTMLCanvasElement>(null);
  const runtimeRef = useRef<LabRuntime | null>(null);
  const introRef = useRef(true);
  const uiAt = useRef(0);
  const [snap, setSnap] = useState<RuntimeSnapshot>(emptySnap);
  const [showTheory, setShowTheory] = useState(true);
  const [resetKey, setResetKey] = useState(0);
  const [controls, setControls] = useState<Record<string, number>>({});

  useEffect(() => {
    hydrate();
  }, [hydrate]);

  const allowed = lab ? isUnlocked(lab.id, completed) : false;

  const defaults = useMemo(() => {
    if (!lab) return {};
    const d: Record<string, number> = {};
    for (const c of lab.controls) {
      if (c.kind === "slider") d[c.key] = (c.min ?? 0) + ((c.max ?? 1) - (c.min ?? 0)) * 0.45;
      if (c.kind === "toggle") d[c.key] = 0;
    }
    if (lab.id === "force") d.force = 0;
    if (lab.id === "projectile") {
      d.angle = 48;
      d.speed = 12;
    }
    if (lab.id === "energy") d.height = 6.2;
    if (lab.id === "spring") {
      d.k = 48;
      d.comp = 1.4;
    }
    if (lab.id === "sandbox") d.g = 9.81;
    if (lab.id === "gravity") d.air = 0;
    if (lab.id === "inertia") d.friction = 0;
    return d;
  }, [lab]);

  useEffect(() => {
    setControls(defaults);
    setShowTheory(true);
    introRef.current = true;
    setSnap(emptySnap);
  }, [defaults, id]);

  useEffect(() => {
    if (!lab || !allowed) return;
    const rt = new LabRuntime(lab);
    runtimeRef.current = rt;
    rt.paused = introRef.current;
    for (const [k, v] of Object.entries(defaults)) rt.setControl(k, v);

    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let raf = 0;
    let last = performance.now();
    let live = true;
    let reported = false;

    const loop = (now: number) => {
      if (!live) return;
      const dt = (now - last) / 1000;
      last = now;
      const parent = canvas.parentElement;
      const cssW = parent?.clientWidth ?? 800;
      const cssH = parent?.clientHeight ?? 480;
      const dpr = Math.min(2, window.devicePixelRatio || 1);
      const bw = Math.floor(cssW * dpr);
      const bh = Math.floor(cssH * dpr);
      if (canvas.width !== bw || canvas.height !== bh) {
        canvas.width = bw;
        canvas.height = bh;
        canvas.style.width = `${cssW}px`;
        canvas.style.height = `${cssH}px`;
      }
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      const st = useProgress.getState().settings;
      rt.vectors = st.vectors;
      rt.shake = st.shake;
      if (introRef.current) rt.paused = true;
      rt.frame(dt);
      rt.render(ctx, cssW, cssH);
      if (now - uiAt.current > 80 || rt.complete) {
        uiAt.current = now;
        const s = rt.snapshot();
        setSnap(s);
        if (s.complete && !reported) {
          reported = true;
          recordStars(lab.id, s.stars);
        }
      }
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);

    const onKey = (e: KeyboardEvent) => {
      if (e.key === " " || e.code === "Space") {
        e.preventDefault();
        rt.paused = !rt.paused;
      } else if (e.key === "r" || e.key === "R") {
        rt.reset();
        for (const [k, v] of Object.entries(defaults)) rt.setControl(k, v);
        reported = false;
      } else if (e.key === "Escape") {
        navigate({ to: "/" });
      }
    };
    window.addEventListener("keydown", onKey);

    return () => {
      live = false;
      cancelAnimationFrame(raf);
      window.removeEventListener("keydown", onKey);
      runtimeRef.current = null;
    };
  }, [lab, allowed, defaults, recordStars, navigate, resetKey]);

  const toLocal = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    return { x: e.clientX - rect.left, y: e.clientY - rect.top };
  };

  const onDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    unlockAudio();
    e.currentTarget.setPointerCapture(e.pointerId);
    const p = toLocal(e);
    runtimeRef.current?.pointerDown(p.x, p.y);
  };
  const onMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const p = toLocal(e);
    runtimeRef.current?.pointerMove(p.x, p.y);
  };
  const onUp = () => runtimeRef.current?.pointerUp();

  const setCtrl = useCallback((key: string, value: number) => {
    setControls((c) => ({ ...c, [key]: value }));
    runtimeRef.current?.setControl(key, value);
  }, []);

  const fire = (key: string) => {
    unlockAudio();
    playClick();
    runtimeRef.current?.doAction(key);
  };

  if (!lab) {
    return (
      <main className="flex min-h-dvh flex-col items-center justify-center gap-4 bg-bg px-6 text-fg">
        <p className="font-display text-3xl">No such experiment</p>
        <Button asChild>
          <Link to="/">Back to the laboratory</Link>
        </Button>
      </main>
    );
  }

  if (!allowed) {
    return (
      <main className="flex min-h-dvh flex-col items-center justify-center gap-4 bg-bg px-6 text-center text-fg">
        <p className="font-display text-3xl">Still locked</p>
        <p className="max-w-sm text-sm text-muted">Finish the previous experiment to open this station.</p>
        <Button asChild>
          <Link to="/">Back to the laboratory</Link>
        </Button>
      </main>
    );
  }

  const next = nextLabId(lab.id as LabId);
  const t = snap.telemetry;

  return (
    <div className="relative flex h-dvh flex-col bg-bg text-fg">
      <div className="grain pointer-events-none absolute inset-0 opacity-50" />
      <header className="relative z-10 flex shrink-0 items-center gap-2 border-b border-border px-3 py-2 sm:px-4">
        <Button asChild variant="ghost" size="icon-sm" aria-label="Back to laboratory">
          <Link to="/">
            <ArrowLeft className="size-4" />
          </Link>
        </Button>
        <div className="min-w-0 flex-1">
          <p className="font-mono text-[10px] uppercase tracking-[0.16em] text-subtle">
            {lab.sandbox ? "Free play" : `Experiment ${String(lab.index).padStart(2, "0")}`}
          </p>
          <h1 className="truncate font-display text-lg leading-tight sm:text-xl">{lab.title}</h1>
        </div>
        <div className="flex items-center gap-1">
          <Button
            variant="ghost"
            size="icon-sm"
            aria-label={settings.sound ? "Mute" : "Unmute"}
            onClick={() => patchSettings({ sound: !settings.sound })}
          >
            {settings.sound ? <Volume2 className="size-4" /> : <VolumeX className="size-4" />}
          </Button>
          <Button
            variant="ghost"
            size="icon-sm"
            aria-label={settings.vectors ? "Hide vectors" : "Show vectors"}
            onClick={() => patchSettings({ vectors: !settings.vectors })}
          >
            {settings.vectors ? <Eye className="size-4" /> : <EyeOff className="size-4" />}
          </Button>
          <Button
            variant="ghost"
            size="icon-sm"
            aria-label="Theory"
            onClick={() => {
              introRef.current = true;
              setShowTheory(true);
            }}
          >
            <BookOpen className="size-4" />
          </Button>
        </div>
      </header>

      <div className="relative z-10 flex min-h-0 flex-1 flex-col lg:flex-row">
        <div className="flex min-h-0 min-w-0 flex-1 flex-col">
          <p className="shrink-0 px-4 py-2 text-center text-xs leading-relaxed text-muted sm:text-sm">
            {lab.objective}
          </p>
          <div className="relative min-h-[220px] flex-1 sm:min-h-[280px] px-2 pb-2 sm:px-3">
            <div className="relative h-full overflow-hidden rounded-[20px] border border-border bg-[#101114] touch-none">
              <canvas
                ref={canvasRef}
                className="absolute inset-0 size-full cursor-grab active:cursor-grabbing"
                style={{ touchAction: "none" }}
                onPointerDown={onDown}
                onPointerMove={onMove}
                onPointerUp={onUp}
                onPointerCancel={onUp}
              />
            </div>
          </div>
        </div>

        <aside className="flex max-h-[46vh] shrink-0 flex-col gap-3 overflow-y-auto border-t border-border bg-surface px-4 py-3 lg:max-h-none lg:w-[300px] lg:gap-4 lg:overflow-visible lg:border-l lg:border-t-0 lg:py-4">
          <p className="hidden font-mono text-[11px] text-accent lg:block">{lab.formula}</p>

          <div className="grid grid-cols-3 gap-2 font-mono text-[11px] tabular-nums">
            <Meter label="v" value={`${formatNum(t.speed, 2)}`} unit="m/s" />
            <Meter label="a" value={`${formatNum(Math.hypot(t.ax, t.ay), 2)}`} unit="m/s²" />
            <Meter label="t" value={`${formatNum(t.t, 1)}`} unit="s" />
            <Meter label="KE" value={`${formatNum(t.ke, 1)}`} unit="J" />
            <Meter label="PE" value={`${formatNum(t.pe, 1)}`} unit="J" />
            <Meter label="Σp" value={`${formatNum(Math.hypot(t.px, t.py), 1)}`} unit="kg·m/s" />
          </div>

          <div className="space-y-3">
            {lab.controls.map((c) => {
              if (c.kind === "slider") {
                const v = controls[c.key] ?? c.min ?? 0;
                return (
                  <label key={c.key} className="block">
                    <span className="flex items-baseline justify-between text-xs text-muted">
                      <span>{c.label}</span>
                      <span className="font-mono tabular-nums text-fg">
                        {formatNum(v, c.step && c.step < 0.1 ? 2 : 1)}
                        {c.unit ? ` ${c.unit}` : ""}
                      </span>
                    </span>
                    <Slider
                      min={c.min}
                      max={c.max}
                      step={c.step}
                      value={[v]}
                      onValueChange={(val) => setCtrl(c.key, val[0] ?? 0)}
                    />
                  </label>
                );
              }
              if (c.kind === "toggle") {
                const v = controls[c.key] ?? 0;
                return (
                  <label key={c.key} className="flex items-center justify-between gap-3 text-sm">
                    <span className="text-muted">{c.label}</span>
                    <Switch checked={v > 0.5} onCheckedChange={(on) => setCtrl(c.key, on ? 1 : 0)} />
                  </label>
                );
              }
              return (
                <Button key={c.key} className="w-full" onClick={() => fire(c.key)}>
                  {c.actionLabel ?? c.label}
                </Button>
              );
            })}
          </div>

          <div className="mt-auto flex gap-2">
            <Button
              variant="secondary"
              className="flex-1"
              onClick={() => {
                runtimeRef.current && (runtimeRef.current.paused = !runtimeRef.current.paused);
              }}
            >
              {snap.paused ? <Play className="size-4" /> : <Pause className="size-4" />}
              {snap.paused ? "Resume" : "Pause"}
            </Button>
            <Button
              variant="outline"
              className="flex-1"
              onClick={() => {
                setResetKey((n) => n + 1);
                setControls(defaults);
              }}
            >
              <RotateCcw className="size-4" />
              Reset
            </Button>
          </div>
          <p className="hidden text-[11px] leading-relaxed text-subtle lg:block">{lab.interact}</p>
        </aside>
      </div>

      {showTheory && !snap.complete && (
        <div className="absolute inset-0 z-20 flex items-end justify-center bg-bg/70 p-4 sm:items-center">
          <div className="max-h-[85dvh] w-full max-w-lg overflow-auto rounded-[28px] border border-border bg-surface p-6 shadow-[var(--shadow-panel)] sm:p-8">
            <p className="font-mono text-[11px] uppercase tracking-[0.18em] text-subtle">
              {lab.sandbox ? "Notebook" : `Experiment ${String(lab.index).padStart(2, "0")}`}
            </p>
            <h2 className="font-display mt-2 text-3xl tracking-tight">{lab.title}</h2>
            <p className="mt-3 font-mono text-sm text-accent">{lab.formula}</p>
            <div className="mt-5 space-y-3 text-[15px] leading-relaxed text-muted">
              {lab.theory.map((p) => (
                <p key={p}>{p}</p>
              ))}
            </div>
            <p className="mt-5 text-sm text-fg">{lab.objective}</p>
            <p className="mt-2 text-xs text-subtle">{lab.interact}</p>
            <Button
              className="mt-6 w-full"
              size="lg"
              onClick={() => {
                unlockAudio();
                introRef.current = false;
                const rt = runtimeRef.current;
                if (rt) rt.paused = false;
                setShowTheory(false);
              }}
            >
              Begin
            </Button>
          </div>
        </div>
      )}

      {snap.complete && (
        <div className="absolute inset-0 z-20 flex items-end justify-center bg-bg/70 p-4 sm:items-center">
          <div className="w-full max-w-md rounded-[28px] border border-border bg-surface p-6 text-center shadow-[var(--shadow-panel)] sm:p-8">
            <StarRow n={snap.stars} size={22} className="justify-center" />
            <h2 className="font-display mt-4 text-3xl tracking-tight">Confirmed</h2>
            <p className="mt-3 text-[15px] leading-relaxed text-muted">{snap.detail}</p>
            <p className="mt-2 font-mono text-xs text-accent">{lab.formula}</p>
            <div className="mt-6 flex flex-col gap-2 sm:flex-row">
              <Button
                variant="secondary"
                className="flex-1"
                onClick={() => {
                  setResetKey((n) => n + 1);
                  setControls(defaults);
                }}
              >
                Replay
              </Button>
              {next ? (
                <Button asChild className="flex-1">
                  <Link to="/lab/$id" params={{ id: next }}>
                    Next experiment
                  </Link>
                </Button>
              ) : (
                <Button asChild className="flex-1">
                  <Link to="/">Laboratory</Link>
                </Button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function Meter({ label, value, unit }: { label: string; value: string; unit: string }) {
  return (
    <div className="rounded-[12px] bg-elevated px-2 py-1.5">
      <p className="text-[10px] uppercase tracking-wider text-subtle">{label}</p>
      <p className="text-fg">
        {value}
        <span className="ml-0.5 text-[9px] text-subtle">{unit}</span>
      </p>
    </div>
  );
}

