import { Star } from "lucide-react";
import { cn } from "@/lib/utils";

export function StarRow({ n, className, size = 14 }: { n: number; className?: string; size?: number }) {
  return (
    <span className={cn("inline-flex shrink-0 items-center gap-1.5", className)} aria-label={`${n} of 3 stars`}>
      {[1, 2, 3].map((i) => (
        <Star
          key={i}
          width={size}
          height={size}
          className={cn("shrink-0", i <= n ? "fill-accent text-accent" : "text-border")}
          strokeWidth={1.75}
        />
      ))}
    </span>
  );
}
