import type { LabId } from "@/lib/labs/types";
import { LABS } from "@/lib/labs/catalog";

export const SAVE_VERSION = 1;
const KEY = "principia-save-v1";

export type Settings = {
  sound: boolean;
  vectors: boolean;
  shake: boolean;
};

export type SaveState = {
  version: number;
  completed: Partial<Record<LabId, { stars: number }>>;
  settings: Settings;
};

const DEFAULTS: SaveState = {
  version: SAVE_VERSION,
  completed: {},
  settings: { sound: true, vectors: true, shake: true },
};

function migrate(raw: SaveState): SaveState {
  const s: SaveState = {
    version: SAVE_VERSION,
    completed: { ...DEFAULTS.completed, ...raw.completed },
    settings: { ...DEFAULTS.settings, ...raw.settings },
  };
  return s;
}

export function loadSave(): SaveState {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return structuredClone(DEFAULTS);
    const parsed = JSON.parse(raw) as SaveState;
    return migrate(parsed);
  } catch {
    return structuredClone(DEFAULTS);
  }
}

export function writeSave(state: SaveState) {
  try {
    localStorage.setItem(KEY, JSON.stringify({ ...state, version: SAVE_VERSION }));
  } catch {
    /* private mode / quota */
  }
}

export function isUnlocked(id: LabId, completed: SaveState["completed"]) {
  const lab = LABS.find((l) => l.id === id);
  if (!lab) return false;
  if (lab.sandbox) return true;
  if (lab.index <= 1) return true;
  const prev = LABS.find((l) => l.index === lab.index - 1);
  if (!prev) return true;
  return Boolean(completed[prev.id]);
}

export function campaignLabsCompleted(completed: SaveState["completed"]) {
  return LABS.filter((l) => !l.sandbox && completed[l.id]).length;
}

export function firstIncomplete(completed: SaveState["completed"]): LabId {
  for (const lab of LABS) {
    if (lab.sandbox) continue;
    if (!completed[lab.id]) return lab.id;
  }
  return "sandbox";
}

export function totalStars(completed: SaveState["completed"]) {
  return Object.values(completed).reduce((n, v) => n + (v?.stars ?? 0), 0);
}
