import { inZone, makeBody, makeWorld, type World } from "@/lib/physics/world";
import { clamp } from "@/lib/physics/math";
import type { EvalResult, LabDef, LabId } from "./types";

const STEEL = "#c5cdd8";
const MASS = "#d4c4b0";
const ICE = "#8eb4d3";
const WARM = "#d08a7a";
const OK = "#8fbfa8";

function idle(): EvalResult {
  return { complete: false, stars: 0, detail: "" };
}

export const LABS: LabDef[] = [
  {
    id: "inertia",
    index: 1,
    chapter: "I",
    title: "Inertia",
    formula: "F_net = 0  ⇒  v = const",
    summary: "An object keeps its velocity unless a force acts on it.",
    theory: [
      "Newton’s first law is not about rest. It is about velocity: speed and direction stay the same when the net force is zero.",
      "On a frictionless table a puck never slows down. Slowing down is evidence of a force — usually friction.",
      "Drag the puck and let go. With friction off it will slide until a wall pushes back.",
    ],
    objective: "Dock the puck in the bay. A gentle arrival scores higher — inertia does not mean you cannot aim.",
    hint: "Throw softly and use a wall bounce as a planned force, not an accident.",
    interact: "Drag the puck to throw it. Toggle friction to feel the first law fail.",
    controls: [
      {
        key: "friction",
        label: "Friction",
        kind: "slider",
        min: 0,
        max: 1.4,
        step: 0.05,
        unit: "",
      },
    ],
    build: () => {
      const w = makeWorld({
        width: 16,
        height: 9,
        bounceBounds: true,
        gy: 0,
        meta: { friction: 0, entered: 0, vAtEnter: 0 },
      });
      w.bodies.push(
        makeBody({
          id: "puck",
          x: 2.6,
          y: 4.5,
          mass: 1,
          radius: 0.38,
          color: MASS,
          label: "1 kg",
          role: "player",
          restitution: 0.86,
          drag: 0,
        }),
      );
      w.rects.push(
        {
          id: "wall-a",
          x: 7.2,
          y: 0,
          w: 0.35,
          h: 3.2,
          restitution: 0.9,
          color: STEEL,
          fill: "#1a1b20",
          vx: 0,
          vy: 0,
          solid: true,
        },
        {
          id: "wall-b",
          x: 7.2,
          y: 5.8,
          w: 0.35,
          h: 3.2,
          restitution: 0.9,
          color: STEEL,
          fill: "#1a1b20",
          vx: 0,
          vy: 0,
          solid: true,
        },
      );
      w.zones.push({
        id: "bay",
        x: 13.3,
        y: 3.4,
        w: 2.3,
        h: 2.2,
        kind: "goal",
        color: OK,
        label: "BAY",
      });
      return w;
    },
    applyControl: (world, key, value) => {
      if (key === "friction") {
        world.meta.friction = value;
        const puck = world.bodies[0];
        if (puck) puck.drag = value * 0.22;
      }
    },
    evaluate: (world) => {
      const puck = world.bodies[0];
      const bay = world.zones[0];
      if (!puck || !bay) return idle();
      if (inZone(puck, bay)) {
        const sp = Math.hypot(puck.vx, puck.vy);
        world.meta.entered = 1;
        world.meta.vAtEnter = sp;
        if (sp < 1.15) return { complete: true, stars: 3, detail: "Docked. Velocity nearly spent by design, not friction." };
        if (sp < 2.6) return { complete: true, stars: 2, detail: "In the bay. A slower approach would have been cleaner." };
        return { complete: true, stars: 1, detail: "You arrived. The first law did the rest." };
      }
      return idle();
    },
  },
  {
    id: "force",
    index: 2,
    chapter: "I",
    title: "Force & Mass",
    formula: "F = m a",
    summary: "The same push accelerates a light mass more than a heavy one.",
    theory: [
      "Force does not set speed. It sets how quickly velocity changes — acceleration.",
      "Rearranged: a = F / m. Double the mass, halve the acceleration, for the same force.",
      "A force of 6 N on 3 kg gives a = 2 m/s². After 2 seconds, v = 4 m/s, if it started at rest.",
    ],
    objective: "Drive the 3 kg crate across the line at 4.0 m/s (within 0.4). Same force, different mass — compare the 1 kg companion.",
    hint: "a = F/m. For 3 kg and a target of 4 m/s you need Δv = 4, so t = 4 / (F/3).",
    interact: "Set a constant force. Both crates feel it. Watch the acceleration arrows.",
    controls: [
      { key: "force", label: "Force", kind: "slider", min: -12, max: 12, step: 0.5, unit: "N" },
    ],
    build: () => {
      const w = makeWorld({
        width: 16,
        height: 8,
        bounceBounds: true,
        gy: 0,
        meta: { force: 0, crossed: 0, vCross: 0 },
      });
      w.bodies.push(
        makeBody({
          id: "light",
          x: 2.2,
          y: 5.4,
          mass: 1,
          radius: 0.32,
          color: ICE,
          label: "1 kg",
          restitution: 0.2,
          drag: 0,
        }),
        makeBody({
          id: "heavy",
          x: 2.2,
          y: 2.6,
          mass: 3,
          radius: 0.5,
          color: MASS,
          label: "3 kg",
          role: "player",
          restitution: 0.2,
          drag: 0,
        }),
      );
      w.rects.push({
        id: "line",
        x: 12.9,
        y: 0,
        w: 0.08,
        h: 8,
        restitution: 0,
        color: OK,
        fill: "rgba(143,191,168,0.15)",
        vx: 0,
        vy: 0,
        solid: false,
      });
      w.zones.push({
        id: "finish",
        x: 12.9,
        y: 0,
        w: 2.8,
        h: 8,
        kind: "goal",
        color: OK,
        label: "FINISH",
      });
      w.bodies.forEach((b) => {
        b.forceX = 0;
      });
      return w;
    },
    applyControl: (world, key, value) => {
      if (key === "force") {
        world.meta.force = value;
        for (const b of world.bodies) b.forceX = value;
      }
    },
    evaluate: (world) => {
      const heavy = world.bodies.find((b) => b.id === "heavy");
      if (!heavy) return idle();
      if (heavy.x > 12.9 && world.meta.crossed === 0) {
        world.meta.crossed = 1;
        world.meta.vCross = heavy.vx;
        const err = Math.abs(heavy.vx - 4);
        if (err <= 0.35) {
          return { complete: true, stars: 3, detail: `v = ${heavy.vx.toFixed(2)} m/s at the line. F = ma held.` };
        }
        if (err <= 0.85) {
          return { complete: true, stars: 2, detail: `v = ${heavy.vx.toFixed(2)} m/s. Close to 4.0.` };
        }
        if (heavy.vx > 0.4) {
          return { complete: true, stars: 1, detail: `Crossed at ${heavy.vx.toFixed(2)} m/s. Target was 4.0.` };
        }
      }
      return idle();
    },
  },
  {
    id: "gravity",
    index: 3,
    chapter: "I",
    title: "Free Fall",
    formula: "a = g  (vacuum)",
    summary: "Mass cancels. In vacuum everything falls together.",
    theory: [
      "Weight is mg, a force. Acceleration is F/m, so a = g. The mass in the force is the same mass that resists acceleration.",
      "Air drag is a second force that depends on speed and shape, not on mass in the same way. That is why a feather lags.",
      "Time a drop onto the cart. Horizontal motion of the cart and vertical free-fall are independent.",
    ],
    objective: "Land the mass on the moving cart on the first drop.",
    hint: "The fall from 12 m takes about √(2h/g) ≈ 1.56 s. Watch the cart’s period.",
    interact: "The ball is held until you release. Air drag can be added to break the law.",
    controls: [
      { key: "air", label: "Air drag", kind: "slider", min: 0, max: 0.35, step: 0.01, unit: "" },
      { key: "release", label: "Release", kind: "action", actionLabel: "Drop" },
    ],
    build: () => {
      const w = makeWorld({
        width: 12,
        height: 14,
        gy: -9.81,
        bounceBounds: true,
        groundY: 0,
        meta: { air: 0, held: 1, drops: 0, landed: 0 },
      });
      w.bodies.push(
        makeBody({
          id: "ball",
          x: 6,
          y: 12.2,
          mass: 2,
          radius: 0.36,
          color: MASS,
          label: "2 kg",
          role: "player",
          restitution: 0.18,
          drag: 0,
          fixed: true,
        }),
      );
      w.rects.push({
        id: "cart",
        x: 1.2,
        y: 0.35,
        w: 1.9,
        h: 0.55,
        restitution: 0.1,
        color: STEEL,
        fill: "#22242a",
        role: "cart",
        vx: 0,
        vy: 0,
        solid: true,
      });
      return w;
    },
    tick: (world) => {
      const cart = world.rects.find((r) => r.role === "cart");
      if (cart) {
        const mid = 6 - cart.w / 2;
        cart.x = mid + 3.6 * Math.sin(world.time * 0.85);
      }
      const ball = world.bodies[0];
      if (ball && world.meta.held === 1) {
        ball.x = 6;
        ball.y = 12.2;
        ball.vx = 0;
        ball.vy = 0;
        ball.fixed = true;
      }
    },
    applyControl: (world, key, value) => {
      if (key === "air") {
        world.meta.air = value;
        const ball = world.bodies[0];
        if (ball) ball.drag = value;
      }
    },
    action: (world, key) => {
      if (key === "release") {
        const ball = world.bodies[0];
        if (!ball) return;
        if (world.meta.held === 1) {
          world.meta.held = 0;
          world.meta.drops += 1;
          ball.fixed = false;
          ball.vx = 0;
          ball.vy = 0;
        }
      }
    },
    evaluate: (world) => {
      const ball = world.bodies[0];
      const cart = world.rects.find((r) => r.role === "cart");
      if (!ball || !cart || world.meta.held === 1) return idle();
      const on =
        ball.y - ball.radius <= cart.y + cart.h + 0.12 &&
        ball.y > cart.y &&
        ball.x > cart.x - 0.05 &&
        ball.x < cart.x + cart.w + 0.05 &&
        ball.vy <= 0.8;
      if (on) {
        const centered = Math.abs(ball.x - (cart.x + cart.w / 2)) < 0.45;
        const first = world.meta.drops <= 1;
        if (first && centered) {
          return { complete: true, stars: 3, detail: "Independent components: the cart moved in x, the mass in y." };
        }
        if (first) return { complete: true, stars: 2, detail: "On the cart. A more centered landing would be three stars." };
        return { complete: true, stars: 1, detail: "Landed. Free-fall time is independent of mass." };
      }
      return idle();
    },
  },
  {
    id: "projectile",
    index: 4,
    chapter: "I",
    title: "Projectiles",
    formula: "R = v² sin(2θ) / g",
    summary: "Horizontal motion is uniform. Vertical motion is free-fall.",
    theory: [
      "Once launched, the only force (ignoring air) is weight, which is vertical. vx never changes.",
      "Range on flat ground is greatest at 45°, because sin(2θ) peaks there. Complementary angles (30° and 60°) share a range.",
      "The dashed curve is the kinematic prediction — not a suggestion. Fire when it threads the target.",
    ],
    objective: "Hit the target. First-shot hits are three stars.",
    hint: "For a level target, 45° maximises range. You may need a steeper or shallower shot from here.",
    interact: "Set angle and speed, then fire. The ghost path uses the same equations as the ball.",
    controls: [
      { key: "angle", label: "Angle", kind: "slider", min: 12, max: 78, step: 1, unit: "°" },
      { key: "speed", label: "Speed", kind: "slider", min: 4, max: 18, step: 0.2, unit: "m/s" },
      { key: "fire", label: "Fire", kind: "action", actionLabel: "Fire" },
    ],
    build: () => {
      const w = makeWorld({
        width: 18,
        height: 10,
        gy: -9.81,
        bounceBounds: false,
        groundY: 0,
        meta: { angle: 48, speed: 12, shots: 0, flying: 0, hit: 0 },
      });
      w.bodies.push(
        makeBody({
          id: "shot",
          x: 1.6,
          y: 0.95,
          mass: 0.8,
          radius: 0.28,
          color: MASS,
          label: "m",
          role: "player",
          restitution: 0.35,
          fixed: true,
        }),
      );
      w.rects.push({
        id: "cannon",
        x: 0.6,
        y: 0,
        w: 1.3,
        h: 0.7,
        restitution: 0,
        color: STEEL,
        fill: "#1c1e24",
        vx: 0,
        vy: 0,
        solid: true,
      });
      w.zones.push({
        id: "target",
        x: 13.6,
        y: 1.4,
        w: 1.5,
        h: 1.5,
        kind: "goal",
        color: WARM,
        label: "TARGET",
      });
      return w;
    },
    applyControl: (world, key, value) => {
      if (key === "angle") world.meta.angle = value;
      if (key === "speed") world.meta.speed = value;
    },
    action: (world, key) => {
      if (key !== "fire") return;
      const b = world.bodies[0];
      if (!b) return;
      const th = (world.meta.angle * Math.PI) / 180;
      const v = world.meta.speed;
      b.x = 1.6;
      b.y = 0.95;
      b.vx = Math.cos(th) * v;
      b.vy = Math.sin(th) * v;
      b.fixed = false;
      world.meta.shots += 1;
      world.meta.flying = 1;
    },
    evaluate: (world) => {
      const b = world.bodies[0];
      const z = world.zones[0];
      if (!b || !z || world.meta.flying !== 1) return idle();
      if (inZone(b, z)) {
        const n = world.meta.shots;
        if (n <= 1) return { complete: true, stars: 3, detail: "First shot. The parabola is not a guess." };
        if (n <= 3) return { complete: true, stars: 2, detail: `Hit on shot ${n}. Complementary angles share a range.` };
        return { complete: true, stars: 1, detail: "On target. Horizontal and vertical motions really are independent." };
      }
      return idle();
    },
  },
  {
    id: "momentum",
    index: 5,
    chapter: "II",
    title: "Momentum",
    formula: "p = m v    Σp conserved",
    summary: "Isolated collisions trade velocity so that total momentum stays put.",
    theory: [
      "Momentum is mass times velocity — a vector. Two equal masses exchanging velocity in a head-on elastic hit is the cleanest picture.",
      "If the target is at rest, a cue of equal mass stops and the target takes the velocity (elastic, 1D).",
      "Watch the Σp readout. It should barely move. Kinetic energy is conserved only if the collision is elastic.",
    ],
    objective: "Pocket the marked mass with a single collision. Do not sink the cue.",
    hint: "Equal masses, elastic, head-on: the cue should almost stop. Aim through the center.",
    interact: "Drag the cue back and throw it. The hit is elastic.",
    controls: [],
    build: () => {
      const w = makeWorld({
        width: 16,
        height: 9,
        bounceBounds: true,
        gy: 0,
        meta: { pocketed: 0, cueIn: 0 },
      });
      w.bodies.push(
        makeBody({
          id: "cue",
          x: 3.2,
          y: 4.5,
          mass: 1,
          radius: 0.36,
          color: ICE,
          label: "cue",
          role: "player",
          restitution: 0.98,
        }),
        makeBody({
          id: "obj",
          x: 8.2,
          y: 4.5,
          mass: 1,
          radius: 0.36,
          color: WARM,
          label: "m",
          role: "target",
          restitution: 0.98,
        }),
      );
      w.zones.push({
        id: "pocket",
        x: 13.6,
        y: 3.5,
        w: 2,
        h: 2,
        kind: "pocket",
        color: OK,
        label: "POCKET",
      });
      return w;
    },
    evaluate: (world) => {
      const cue = world.bodies.find((b) => b.id === "cue");
      const obj = world.bodies.find((b) => b.id === "obj");
      const z = world.zones[0];
      if (!cue || !obj || !z) return idle();
      const objIn = inZone(obj, z);
      const cueIn = inZone(cue, z);
      if (objIn && !cueIn) {
        return { complete: true, stars: 3, detail: "One collision, cue spared. Momentum moved; it did not vanish." };
      }
      if (objIn && cueIn) {
        return { complete: true, stars: 1, detail: "Both fell in. The transfer worked — the aim was wide." };
      }
      return idle();
    },
  },
  {
    id: "energy",
    index: 6,
    chapter: "II",
    title: "Energy",
    formula: "E = ½mv² + mgh",
    summary: "Height is stored motion. Motion is spent height.",
    theory: [
      "Gravitational potential energy is mgh, measured from any zero you choose. Kinetic energy is ½mv².",
      "Without friction the sum is constant. A ball that starts 4 m above the valley floor can climb 4 m on the far side — not more.",
      "The bell sits above the valley. Release from the lowest height that still rings it. Extra height is wasted energy.",
    ],
    objective: "Ring the bell. Three stars if you start no higher than you must.",
    hint: "The bell is at 5.4 m. With no friction you need PE at least mg × 5.4.",
    interact: "Set release height, then drop. Watch KE and PE trade in the instruments.",
    controls: [
      { key: "height", label: "Release height", kind: "slider", min: 2.2, max: 8.4, step: 0.1, unit: "m" },
      { key: "drop", label: "Drop", kind: "action", actionLabel: "Release" },
    ],
    build: () => {
      const w = makeWorld({
        width: 16,
        height: 10,
        gy: -9.81,
        bounceBounds: false,
        groundY: 0,
        meta: { height: 6.2, held: 1, rang: 0 },
      });
      applyEnergyHill(w, 6.2);
      w.bodies.push(
        makeBody({
          id: "ball",
          x: 1.7,
          y: 6.2 + 0.32,
          mass: 1,
          radius: 0.32,
          color: MASS,
          label: "1 kg",
          role: "player",
          restitution: 0.18,
          friction: 0.02,
          fixed: true,
        }),
      );
      w.zones.push({
        id: "bell",
        x: 11.6,
        y: 5.45,
        w: 1.5,
        h: 1.3,
        kind: "bell",
        color: "#c4a574",
        label: "BELL",
      });
      return w;
    },
    tick: (world) => {
      const b = world.bodies[0];
      if (!b) return;
      if (world.meta.held === 1) {
        const h = world.meta.height;
        applyEnergyHill(world, h);
        b.x = 1.7;
        b.y = h + b.radius + 0.03;
        b.vx = 0;
        b.vy = 0;
        b.fixed = true;
      }
    },
    applyControl: (world, key, value) => {
      if (key === "height") world.meta.height = value;
    },
    action: (world, key) => {
      if (key === "drop") {
        const b = world.bodies[0];
        if (!b) return;
        world.meta.held = 0;
        b.fixed = false;
        b.vx = 0;
        b.vy = 0;
      }
    },
    evaluate: (world) => {
      const b = world.bodies[0];
      const z = world.zones[0];
      if (!b || !z || world.meta.held === 1) return idle();
      if (inZone(b, z) || (b.x > 11.4 && b.x < 13.2 && b.y > 5.35)) {
        const h = world.meta.height;
        if (h <= 6.0) return { complete: true, stars: 3, detail: "Minimum PE that still reaches the bell. Nothing wasted." };
        if (h <= 7.2) return { complete: true, stars: 2, detail: "Rung. You had surplus height — surplus energy." };
        return { complete: true, stars: 1, detail: "The bell rang. Energy changed form; the sum barely moved." };
      }
      return idle();
    },
  },
  {
    id: "spring",
    index: 7,
    chapter: "II",
    title: "Springs",
    formula: "F = −k x     U = ½ k x²",
    summary: "A spring stores energy in stretch and returns it as motion.",
    theory: [
      "Hooke’s law: the restoring force is proportional to displacement from rest, and opposite in direction.",
      "The energy stored is ½kx². Launching a mass converts that into kinetic energy, then into gravitational PE if it climbs.",
      "Period of SHM is 2π√(m/k) — independent of how far you pull, as long as the spring stays linear.",
    ],
    objective: "Compress a vertical spring so the mass just reaches the marker.",
    hint: "½kx² = mgh at the top. For k = 48 and h = 5.2 m, x ≈ √(2mgh/k) ≈ 1.46 m.",
    interact: "Set compression, then release. Watch PE in the spring become height.",
    controls: [
      { key: "k", label: "Stiffness k", kind: "slider", min: 20, max: 90, step: 1, unit: "N/m" },
      { key: "comp", label: "Compression", kind: "slider", min: 0.3, max: 2.2, step: 0.05, unit: "m" },
      { key: "launch", label: "Release", kind: "action", actionLabel: "Release" },
    ],
    build: () => {
      const w = makeWorld({
        width: 12,
        height: 10,
        gy: -9.81,
        bounceBounds: true,
        groundY: 0,
        meta: { k: 48, comp: 1.4, held: 1, landed: 0, apex: 0 },
      });
      const rest = 2.4;
      const comp = 1.4;
      w.bodies.push(
        makeBody({
          id: "mass",
          x: 6,
          y: rest - comp + 0.38,
          mass: 1,
          radius: 0.38,
          color: MASS,
          label: "1 kg",
          role: "player",
          restitution: 0.2,
          friction: 0.04,
          fixed: true,
        }),
      );
      w.springs.push({
        id: "s",
        a: "mass",
        ax: 6,
        ay: 0.15,
        rest,
        k: 48,
        c: 0.8,
      });
      w.zones.push({
        id: "mark",
        x: 5.1,
        y: 5.0,
        w: 1.8,
        h: 0.7,
        kind: "pad",
        color: OK,
        label: "MARK",
      });
      w.rects.push({
        id: "base",
        x: 5.55,
        y: 0,
        w: 0.9,
        h: 0.18,
        restitution: 0.1,
        color: STEEL,
        fill: "#1c1e24",
        vx: 0,
        vy: 0,
        solid: true,
      });
      return w;
    },
    tick: (world) => {
      const b = world.bodies[0];
      const s = world.springs[0];
      if (!b || !s) return;
      s.k = world.meta.k;
      if (world.meta.held === 1) {
        const y = Math.max(b.radius + 0.2, s.ay + s.rest - world.meta.comp);
        b.x = 6;
        b.y = y;
        b.vx = 0;
        b.vy = 0;
        b.fixed = true;
      } else if (world.springs.length > 0) {
        const d = Math.hypot(b.x - s.ax, b.y - s.ay);
        if (d >= s.rest && b.vy >= -0.05) {
          world.springs = [];
        }
      }
    },
    applyControl: (world, key, value) => {
      if (key === "k") world.meta.k = value;
      if (key === "comp") world.meta.comp = value;
    },
    action: (world, key) => {
      if (key === "launch") {
        const b = world.bodies[0];
        if (!b) return;
        world.meta.held = 0;
        b.fixed = false;
      }
    },
    evaluate: (world) => {
      const b = world.bodies[0];
      const z = world.zones[0];
      if (!b || !z || world.meta.held === 1) return idle();
      const apex = Math.max(world.meta.apex || 0, b.y);
      world.meta.apex = apex;
      const reached = world.meta.apex >= 5.15;
      const falling = b.vy < 0 && world.meta.apex > 1.5;
      if (reached && falling) {
        const over = world.meta.apex - 5.35;
        if (over >= 0 && over < 0.55) {
          return { complete: true, stars: 3, detail: "Just to the mark. ½kx² paid for mgh, almost nothing left." };
        }
        if (over < 1.6) {
          return { complete: true, stars: 2, detail: "Past the mark. A little less compression would be exact." };
        }
        return { complete: true, stars: 1, detail: "You reached it. Spring PE became gravitational PE." };
      }
      return idle();
    },
  },
  {
    id: "orbit",
    index: 8,
    chapter: "III",
    title: "Orbits",
    formula: "v = √(GM / r)",
    summary: "An orbit is perpetual free-fall missing the ground.",
    theory: [
      "Newton’s gravity is inverse-square. The same law that drops an apple bends a moon into a closed path.",
      "For a circular orbit, centripetal acceleration v²/r equals GM/r², so v = √(GM/r). Too slow and you fall in; too fast and you leave.",
      "Place the craft, set its velocity with the handle, then engage. A thin ellipse is still an orbit. A circle is the special case.",
    ],
    objective: "Stay in a bound orbit for eight seconds without hitting the planet.",
    hint: "Start at r = 4 m. Circular speed is √(GM/r) with GM = 90, so about 4.7 m/s, tangent.",
    interact: "Drag the craft to place it. Drag the ice handle to set velocity. Press Engage.",
    controls: [
      { key: "engage", label: "Engage", kind: "action", actionLabel: "Engage" },
    ],
    build: () => {
      const w = makeWorld({
        width: 16,
        height: 16,
        gy: 0,
        bounceBounds: false,
        meta: { setup: 1, alive: 0, rmin: 99, rmax: 0, crashed: 0, escaped: 0 },
      });
      w.wells.push({
        id: "star",
        x: 8,
        y: 8,
        gm: 90,
        radius: 1.25,
        color: "#b7b1a6",
        label: "M",
      });
      w.bodies.push(
        makeBody({
          id: "craft",
          x: 8,
          y: 12,
          mass: 1,
          radius: 0.22,
          color: ICE,
          label: "m",
          role: "craft",
          restitution: 0.1,
          fixed: true,
        }),
      );
      w.meta.vx0 = 4.74;
      w.meta.vy0 = 0;
      return w;
    },
    tick: (world) => {
      const b = world.bodies[0];
      const well = world.wells[0];
      if (!b || !well) return;
      if (world.meta.setup === 1) {
        b.fixed = true;
        b.vx = 0;
        b.vy = 0;
        return;
      }
      const r = Math.hypot(b.x - well.x, b.y - well.y);
      world.meta.rmin = Math.min(world.meta.rmin, r);
      world.meta.rmax = Math.max(world.meta.rmax, r);
      world.meta.alive += 1 / 120;
      if (r < well.radius + b.radius) world.meta.crashed = 1;
      if (r > 9.5) world.meta.escaped = 1;
    },
    action: (world, key) => {
      if (key !== "engage") return;
      const b = world.bodies[0];
      if (!b) return;
      world.meta.setup = 0;
      world.meta.alive = 0;
      world.meta.rmin = 99;
      world.meta.rmax = 0;
      world.meta.crashed = 0;
      world.meta.escaped = 0;
      b.fixed = false;
      b.vx = world.meta.vx0 ?? 4.7;
      b.vy = world.meta.vy0 ?? 0;
    },
    evaluate: (world) => {
      if (world.meta.setup === 1) return idle();
      if (world.meta.crashed === 1) return idle();
      if (world.meta.escaped === 1) return idle();
      const t = world.meta.alive;
      const rmin = world.meta.rmin;
      const rmax = world.meta.rmax;
      const e = rmax + rmin > 0 ? (rmax - rmin) / (rmax + rmin) : 1;
      if (t >= 8 && rmin > 1.6) {
        if (e < 0.18) {
          return { complete: true, stars: 3, detail: `Nearly circular (e ≈ ${e.toFixed(2)}). Free-fall, forever missing.` };
        }
        if (e < 0.55) {
          return { complete: true, stars: 2, detail: `Bound ellipse (e ≈ ${e.toFixed(2)}). Kepler would approve.` };
        }
        return { complete: true, stars: 1, detail: "Bound for eight seconds. An orbit is just a long fall." };
      }
      return idle();
    },
  },
  {
    id: "sandbox",
    index: 9,
    chapter: "III",
    title: "Sandbox",
    formula: "F = ma",
    summary: "No prompt. Spawn masses, pull them, add a well, watch what the laws do.",
    theory: [
      "Everything in the campaign is the same three ideas: inertia, F = ma, and pairwise forces.",
      "Spawn with a tap on empty space. Drag to throw. Toggle gravity or drop a well in the middle.",
    ],
    objective: "There is no test. Stay until something surprises you.",
    hint: "Two masses and a well is already a three-body problem.",
    interact: "Tap empty space to spawn. Drag to throw. Use the controls to change the world.",
    sandbox: true,
    controls: [
      { key: "g", label: "Gravity g", kind: "slider", min: 0, max: 14, step: 0.2, unit: "m/s²" },
      { key: "well", label: "Central well", kind: "toggle" },
      { key: "clear", label: "Clear", kind: "action", actionLabel: "Clear masses" },
    ],
    build: () => {
      const w = makeWorld({
        width: 16,
        height: 10,
        gy: -9.81,
        bounceBounds: true,
        groundY: 0,
        meta: { g: 9.81, well: 0, spawn: 0 },
      });
      w.bodies.push(
        makeBody({ id: "a", x: 5, y: 6, mass: 1, radius: 0.36, color: MASS, label: "1" }),
        makeBody({ id: "b", x: 9, y: 4.5, mass: 2, radius: 0.48, color: ICE, label: "2" }),
      );
      return w;
    },
    applyControl: (world, key, value) => {
      if (key === "g") {
        world.meta.g = value;
        world.gy = -value;
      }
      if (key === "well") {
        world.meta.well = value;
        world.wells = value
          ? [{ id: "w", x: 8, y: 5, gm: 70, radius: 0.9, color: "#b7b1a6", label: "M" }]
          : [];
        world.gy = value ? 0 : -(world.meta.g || 9.81);
        world.groundY = value ? null : 0;
      }
    },
    action: (world, key) => {
      if (key === "clear") {
        world.bodies = world.bodies.filter((b) => b.grabbed);
      }
    },
    evaluate: () => idle(),
  },
];

export function getLab(id: string | undefined): LabDef | undefined {
  return LABS.find((l) => l.id === id);
}

export function campaignLabs() {
  return LABS.filter((l) => !l.sandbox);
}

export const LAB_IDS = LABS.map((l) => l.id) as LabId[];

export function nextLabId(id: LabId): LabId | null {
  const i = LABS.findIndex((l) => l.id === id);
  if (i < 0 || i >= LABS.length - 1) return null;
  return LABS[i + 1].id;
}

function applyEnergyHill(world: World, height: number) {
  const h = clamp(height, 2.2, 8.4);
  const pts: [number, number][] = [
    [0, h],
    [2.6, h],
    [5.4, 1.15],
    [8.6, 1.15],
    [11.2, 5.4],
    [13.6, 5.4],
    [16, 3.2],
  ];
  world.segments = pts.slice(0, -1).map((a, i) => {
    const b = pts[i + 1];
    return {
      id: `s${i}`,
      x1: a[0],
      y1: a[1],
      x2: b[0],
      y2: b[1],
      restitution: 0.08,
      color: STEEL,
    };
  });
}
