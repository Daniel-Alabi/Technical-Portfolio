import type { Body, World } from "@/lib/physics/world";

export type LabId =
  | "inertia"
  | "force"
  | "gravity"
  | "projectile"
  | "momentum"
  | "energy"
  | "spring"
  | "orbit"
  | "sandbox";

export type ControlKind = "slider" | "toggle" | "action";

export type ControlSpec = {
  key: string;
  label: string;
  kind: ControlKind;
  min?: number;
  max?: number;
  step?: number;
  unit?: string;
  actionLabel?: string;
};

export type EvalResult = {
  complete: boolean;
  stars: 0 | 1 | 2 | 3;
  detail: string;
};

export type LabDef = {
  id: LabId;
  index: number;
  chapter: string;
  title: string;
  formula: string;
  summary: string;
  theory: string[];
  objective: string;
  hint: string;
  interact: string;
  sandbox?: boolean;
  controls: ControlSpec[];
  build: () => World;
  tick?: (world: World, dt: number) => void;
  applyControl?: (world: World, key: string, value: number) => void;
  action?: (world: World, key: string) => void;
  evaluate: (world: World) => EvalResult;
  selectHint?: (world: World) => Body | null;
};

export const CHAPTERS = [
  { id: "I", title: "Motion" },
  { id: "II", title: "Conservation" },
  { id: "III", title: "Fields" },
] as const;
