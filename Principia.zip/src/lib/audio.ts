let ctx: AudioContext | null = null;
let master: GainNode | null = null;
let sfx: GainNode | null = null;
let enabled = true;

function ac(): AudioContext | null {
  if (typeof window === "undefined") return null;
  if (!ctx) {
    const Ctor = window.AudioContext || (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!Ctor) return null;
    ctx = new Ctor({ latencyHint: "interactive" });
    master = ctx.createGain();
    sfx = ctx.createGain();
    sfx.gain.value = 0.7;
    master.gain.value = enabled ? 0.85 : 0;
    sfx.connect(master);
    master.connect(ctx.destination);
  }
  return ctx;
}

export function unlockAudio() {
  const c = ac();
  if (!c) return;
  if (c.state === "suspended") void c.resume();
}

export function setSoundEnabled(on: boolean) {
  enabled = on;
  const c = ac();
  if (c && master) {
    master.gain.setTargetAtTime(on ? 0.85 : 0, c.currentTime, 0.03);
  }
}

function envGain(c: AudioContext, peak: number, dur: number) {
  const g = c.createGain();
  g.gain.setValueAtTime(0.0001, c.currentTime);
  g.gain.exponentialRampToValueAtTime(Math.max(0.0002, peak), c.currentTime + 0.012);
  g.gain.exponentialRampToValueAtTime(0.0001, c.currentTime + dur);
  g.connect(sfx ?? c.destination);
  return g;
}

export function playCollide(mag: number) {
  const c = ac();
  if (!c || !enabled) return;
  const peak = Math.min(0.28, 0.05 + mag * 0.04);
  const osc = c.createOscillator();
  osc.type = "sine";
  const f = 90 + Math.min(220, mag * 28) + (Math.random() - 0.5) * 16;
  osc.frequency.setValueAtTime(f, c.currentTime);
  osc.frequency.exponentialRampToValueAtTime(40, c.currentTime + 0.12);
  osc.connect(envGain(c, peak, 0.14));
  osc.start();
  osc.stop(c.currentTime + 0.16);
}

export function playLaunch() {
  const c = ac();
  if (!c || !enabled) return;
  const osc = c.createOscillator();
  osc.type = "triangle";
  osc.frequency.setValueAtTime(220, c.currentTime);
  osc.frequency.exponentialRampToValueAtTime(140, c.currentTime + 0.18);
  osc.connect(envGain(c, 0.12, 0.2));
  osc.start();
  osc.stop(c.currentTime + 0.22);
}

export function playSuccess() {
  const c = ac();
  if (!c || !enabled) return;
  const notes = [392, 494, 587];
  notes.forEach((f, i) => {
    const osc = c.createOscillator();
    osc.type = "sine";
    osc.frequency.value = f;
    const g = c.createGain();
    const t = c.currentTime + i * 0.09;
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(0.14, t + 0.02);
    g.gain.exponentialRampToValueAtTime(0.0001, t + 0.28);
    osc.connect(g);
    g.connect(sfx ?? c.destination);
    osc.start(t);
    osc.stop(t + 0.3);
  });
}

export function playClick() {
  const c = ac();
  if (!c || !enabled) return;
  const osc = c.createOscillator();
  osc.type = "square";
  osc.frequency.value = 880;
  osc.connect(envGain(c, 0.04, 0.05));
  osc.start();
  osc.stop(c.currentTime + 0.06);
}

export function playBell() {
  const c = ac();
  if (!c || !enabled) return;
  const osc = c.createOscillator();
  osc.type = "sine";
  osc.frequency.setValueAtTime(740, c.currentTime);
  osc.frequency.exponentialRampToValueAtTime(620, c.currentTime + 0.4);
  osc.connect(envGain(c, 0.16, 0.45));
  osc.start();
  osc.stop(c.currentTime + 0.5);
}

if (typeof window !== "undefined") {
  const resume = () => {
    const c = ac();
    if (c && c.state === "suspended") void c.resume();
  };
  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "visible") resume();
  });
}
