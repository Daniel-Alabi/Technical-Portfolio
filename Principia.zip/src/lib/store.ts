import { create } from "zustand";
import {
  campaignLabsCompleted,
  firstIncomplete,
  isUnlocked,
  loadSave,
  type SaveState,
  type Settings,
  writeSave,
} from "@/lib/save";
import type { LabId } from "@/lib/labs/types";
import { setSoundEnabled } from "@/lib/audio";

type Store = {
  hydrated: boolean;
  completed: SaveState["completed"];
  settings: Settings;
  hydrate: () => void;
  recordStars: (id: LabId, stars: number) => void;
  patchSettings: (p: Partial<Settings>) => void;
  unlocked: (id: LabId) => boolean;
  continueId: () => LabId;
  campaignDone: () => number;
};

function persist(get: () => Store) {
  const { completed, settings } = get();
  writeSave({ version: 1, completed, settings });
}

export const useProgress = create<Store>((set, get) => ({
  hydrated: false,
  completed: {},
  settings: { sound: true, vectors: true, shake: true },
  hydrate: () => {
    if (get().hydrated) return;
    const s = loadSave();
    setSoundEnabled(s.settings.sound);
    set({ hydrated: true, completed: s.completed, settings: s.settings });
  },
  recordStars: (id, stars) => {
    const prev = get().completed[id]?.stars ?? 0;
    if (stars <= prev) {
      if (!get().completed[id]) {
        set({ completed: { ...get().completed, [id]: { stars } } });
        persist(get);
      }
      return;
    }
    set({ completed: { ...get().completed, [id]: { stars } } });
    persist(get);
  },
  patchSettings: (p) => {
    const settings = { ...get().settings, ...p };
    if (p.sound !== undefined) setSoundEnabled(p.sound);
    set({ settings });
    persist(get);
  },
  unlocked: (id) => isUnlocked(id, get().completed),
  continueId: () => firstIncomplete(get().completed),
  campaignDone: () => campaignLabsCompleted(get().completed),
}));
