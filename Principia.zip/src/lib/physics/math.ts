export const TAU = Math.PI * 2;
export const EPS = 1e-8;

export function clamp(v: number, a: number, b: number) {
  return Math.max(a, Math.min(b, v));
}

export function lerp(a: number, b: number, t: number) {
  return a + (b - a) * t;
}

export function len(x: number, y: number) {
  return Math.hypot(x, y);
}

export function dist(ax: number, ay: number, bx: number, by: number) {
  return Math.hypot(bx - ax, by - ay);
}

export function dist2(ax: number, ay: number, bx: number, by: number) {
  const dx = bx - ax;
  const dy = by - ay;
  return dx * dx + dy * dy;
}

export function norm(x: number, y: number): [number, number] {
  const l = Math.hypot(x, y);
  if (l < EPS) return [0, 0];
  return [x / l, y / l];
}

export function dot(ax: number, ay: number, bx: number, by: number) {
  return ax * bx + ay * by;
}

export function closestOnSegment(
  px: number,
  py: number,
  x1: number,
  y1: number,
  x2: number,
  y2: number,
): { x: number; y: number; t: number } {
  const dx = x2 - x1;
  const dy = y2 - y1;
  const d2 = dx * dx + dy * dy;
  if (d2 < EPS) return { x: x1, y: y1, t: 0 };
  const t = clamp(((px - x1) * dx + (py - y1) * dy) / d2, 0, 1);
  return { x: x1 + dx * t, y: y1 + dy * t, t };
}

export function formatNum(n: number, digits = 2) {
  if (!Number.isFinite(n)) return "—";
  const abs = Math.abs(n);
  if (abs !== 0 && abs < 0.005) return "0.00";
  return n.toFixed(digits);
}
