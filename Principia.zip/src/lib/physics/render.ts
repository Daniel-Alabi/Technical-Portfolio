import { lerp } from "./math";
import type { Body, World } from "./world";

export type View = {
  ppm: number;
  ox: number;
  oy: number;
  cssW: number;
  cssH: number;
};

export function fitView(world: World, cssW: number, cssH: number, pad = 20): View {
  const sx = (cssW - pad * 2) / world.width;
  const sy = (cssH - pad * 2) / world.height;
  const ppm = Math.max(8, Math.min(sx, sy));
  const ox = (cssW - world.width * ppm) / 2;
  const oy = (cssH - world.height * ppm) / 2;
  return { ppm, ox, oy, cssW, cssH };
}

export function toScreen(view: View, world: World, x: number, y: number) {
  return {
    x: view.ox + x * view.ppm,
    y: view.oy + (world.height - y) * view.ppm,
  };
}

export function toWorld(view: View, world: World, sx: number, sy: number) {
  return {
    x: (sx - view.ox) / view.ppm,
    y: world.height - (sy - view.oy) / view.ppm,
  };
}

function bodyPos(b: Body, alpha: number) {
  return { x: lerp(b.px, b.x, alpha), y: lerp(b.py, b.y, alpha) };
}

function arrow(
  ctx: CanvasRenderingContext2D,
  x0: number,
  y0: number,
  x1: number,
  y1: number,
  color: string,
  width: number,
) {
  const dx = x1 - x0;
  const dy = y1 - y0;
  const L = Math.hypot(dx, dy);
  if (L < 4) return;
  const ang = Math.atan2(dy, dx);
  const head = Math.min(12, 6 + width * 2);
  ctx.strokeStyle = color;
  ctx.fillStyle = color;
  ctx.lineWidth = width;
  ctx.lineCap = "round";
  ctx.beginPath();
  ctx.moveTo(x0, y0);
  ctx.lineTo(x1 - Math.cos(ang) * head * 0.65, y1 - Math.sin(ang) * head * 0.65);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(x1, y1);
  ctx.lineTo(x1 - Math.cos(ang - 0.4) * head, y1 - Math.sin(ang - 0.4) * head);
  ctx.lineTo(x1 - Math.cos(ang + 0.4) * head, y1 - Math.sin(ang + 0.4) * head);
  ctx.closePath();
  ctx.fill();
}

function coil(
  ctx: CanvasRenderingContext2D,
  x0: number,
  y0: number,
  x1: number,
  y1: number,
  turns: number,
  amp: number,
  color: string,
) {
  const dx = x1 - x0;
  const dy = y1 - y0;
  const L = Math.hypot(dx, dy) || 1;
  const ux = dx / L;
  const uy = dy / L;
  const px = -uy;
  const py = ux;
  ctx.beginPath();
  ctx.moveTo(x0, y0);
  const n = Math.max(12, turns * 8);
  for (let i = 1; i <= n; i++) {
    const t = i / n;
    const w = Math.sin(t * turns * Math.PI * 2) * amp;
    ctx.lineTo(x0 + ux * L * t + px * w, y0 + uy * L * t + py * w);
  }
  ctx.strokeStyle = color;
  ctx.lineWidth = 1.6;
  ctx.stroke();
}

export type RenderOpts = {
  alpha: number;
  vectors: boolean;
  selectedId: string | null;
  predict: { x: number; y: number }[] | null;
  shakeX: number;
  shakeY: number;
  velHandle: { x: number; y: number } | null;
};

export function renderWorld(
  ctx: CanvasRenderingContext2D,
  world: World,
  view: View,
  opts: RenderOpts,
) {
  const { cssW, cssH, ppm } = view;
  ctx.save();
  ctx.translate(opts.shakeX, opts.shakeY);

  ctx.fillStyle = "#101114";
  ctx.fillRect(0, 0, cssW, cssH);

  const origin = toScreen(view, world, 0, 0);
  const far = toScreen(view, world, world.width, world.height);
  const left = origin.x;
  const bottom = origin.y;
  const right = far.x;
  const top = far.y;
  const bw = right - left;
  const bh = bottom - top;

  ctx.fillStyle = "#0d0e11";
  ctx.fillRect(left, top, bw, bh);

  ctx.save();
  ctx.beginPath();
  ctx.rect(left, top, bw, bh);
  ctx.clip();

  const step = ppm >= 36 ? 1 : 2;
  ctx.lineWidth = 1;
  for (let x = 0; x <= world.width + 0.01; x += step) {
    const p = toScreen(view, world, x, 0);
    ctx.strokeStyle = x % 5 === 0 ? "rgba(240,238,234,0.10)" : "rgba(240,238,234,0.045)";
    ctx.beginPath();
    ctx.moveTo(p.x, top);
    ctx.lineTo(p.x, bottom);
    ctx.stroke();
  }
  for (let y = 0; y <= world.height + 0.01; y += step) {
    const p = toScreen(view, world, 0, y);
    ctx.strokeStyle = y % 5 === 0 ? "rgba(240,238,234,0.10)" : "rgba(240,238,234,0.045)";
    ctx.beginPath();
    ctx.moveTo(left, p.y);
    ctx.lineTo(right, p.y);
    ctx.stroke();
  }

  ctx.font = "500 10px 'IBM Plex Mono', monospace";
  ctx.fillStyle = "rgba(156,154,148,0.7)";
  ctx.textAlign = "center";
  ctx.textBaseline = "top";
  for (let x = 0; x <= world.width; x += 5) {
    const p = toScreen(view, world, x, 0);
    ctx.fillText(`${x} m`, p.x, bottom + 4);
  }
  ctx.textAlign = "right";
  ctx.textBaseline = "middle";
  for (let y = 0; y <= world.height; y += 5) {
    if (y === 0) continue;
    const p = toScreen(view, world, 0, y);
    ctx.fillText(`${y}`, left - 6, p.y);
  }

  if (world.groundY !== null) {
    const g0 = toScreen(view, world, 0, world.groundY);
    const g1 = toScreen(view, world, world.width, world.groundY);
    ctx.fillStyle = "#16171b";
    ctx.fillRect(left, g0.y, bw, bottom - g0.y);
    ctx.strokeStyle = "rgba(197,205,216,0.35)";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(g0.x, g0.y);
    ctx.lineTo(g1.x, g1.y);
    ctx.stroke();
    ctx.strokeStyle = "rgba(240,238,234,0.06)";
    ctx.lineWidth = 1;
    for (let i = 0; i < 28; i++) {
      const x = left + ((i + 0.2) / 28) * bw;
      ctx.beginPath();
      ctx.moveTo(x, g0.y);
      ctx.lineTo(x - 8, g0.y + 10);
      ctx.stroke();
    }
  }

  for (const z of world.zones) {
    const a = toScreen(view, world, z.x, z.y + z.h);
    const w = z.w * ppm;
    const h = z.h * ppm;
    ctx.save();
    ctx.strokeStyle = z.color;
    ctx.fillStyle = z.color;
    ctx.globalAlpha = 0.12;
    ctx.beginPath();
    ctx.roundRect(a.x, a.y, w, h, 8);
    ctx.fill();
    ctx.globalAlpha = 0.85;
    ctx.setLineDash([5, 4]);
    ctx.lineWidth = 1.4;
    ctx.stroke();
    ctx.setLineDash([]);
    if (z.label) {
      ctx.globalAlpha = 0.9;
      ctx.font = "500 11px Figtree, sans-serif";
      ctx.fillStyle = z.color;
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.fillText(z.label, a.x + w / 2, a.y + h / 2);
    }
    ctx.restore();
  }

  for (const r of world.rects) {
    const a = toScreen(view, world, r.x, r.y + r.h);
    ctx.fillStyle = r.fill;
    ctx.strokeStyle = r.color;
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.roundRect(a.x, a.y, r.w * ppm, r.h * ppm, 5);
    ctx.fill();
    ctx.stroke();
    if (r.role === "cart") {
      const wheelY = a.y + r.h * ppm + 3;
      ctx.fillStyle = "#c5cdd8";
      ctx.beginPath();
      ctx.arc(a.x + 10, wheelY, 4, 0, Math.PI * 2);
      ctx.arc(a.x + r.w * ppm - 10, wheelY, 4, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  for (const s of world.segments) {
    const a = toScreen(view, world, s.x1, s.y1);
    const b = toScreen(view, world, s.x2, s.y2);
    ctx.strokeStyle = s.color;
    ctx.lineWidth = 3;
    ctx.lineCap = "round";
    ctx.beginPath();
    ctx.moveTo(a.x, a.y);
    ctx.lineTo(b.x, b.y);
    ctx.stroke();
  }

  for (const well of world.wells) {
    const p = toScreen(view, world, well.x, well.y);
    const r = well.radius * ppm;
    const g = ctx.createRadialGradient(p.x - r * 0.25, p.y - r * 0.3, r * 0.1, p.x, p.y, r);
    g.addColorStop(0, "#e8e4dc");
    g.addColorStop(0.45, well.color);
    g.addColorStop(1, "#1a1c22");
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.arc(p.x, p.y, r, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = "rgba(240,238,234,0.18)";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.arc(p.x, p.y, r + 6, 0, Math.PI * 2);
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(p.x, p.y, r + 14, 0.15, 1.4);
    ctx.stroke();
    if (well.label) {
      ctx.fillStyle = "rgba(240,238,234,0.7)";
      ctx.font = "500 11px Figtree, sans-serif";
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.fillText(well.label, p.x, p.y);
    }
  }

  for (const s of world.springs) {
    const a = world.bodies.find((b) => b.id === s.a);
    if (!a) continue;
    const ap = bodyPos(a, opts.alpha);
    let bx = s.ax;
    let by = s.ay;
    if (s.b) {
      const other = world.bodies.find((b) => b.id === s.b);
      if (!other) continue;
      const bp = bodyPos(other, opts.alpha);
      bx = bp.x;
      by = bp.y;
    }
    const p0 = toScreen(view, world, ap.x, ap.y);
    const p1 = toScreen(view, world, bx, by);
    coil(ctx, p0.x, p0.y, p1.x, p1.y, 9, 7, "#c5cdd8");
  }

  if (opts.predict && opts.predict.length > 1) {
    ctx.beginPath();
    for (let i = 0; i < opts.predict.length; i++) {
      const p = toScreen(view, world, opts.predict[i].x, opts.predict[i].y);
      if (i === 0) ctx.moveTo(p.x, p.y);
      else ctx.lineTo(p.x, p.y);
    }
    ctx.strokeStyle = "rgba(142,180,211,0.55)";
    ctx.lineWidth = 1.5;
    ctx.setLineDash([4, 5]);
    ctx.stroke();
    ctx.setLineDash([]);
    for (let i = 6; i < opts.predict.length; i += 8) {
      const p = toScreen(view, world, opts.predict[i].x, opts.predict[i].y);
      ctx.fillStyle = "rgba(142,180,211,0.7)";
      ctx.beginPath();
      ctx.arc(p.x, p.y, 2.2, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  for (const p of world.particles) {
    const t = 1 - p.age / p.life;
    const s = toScreen(view, world, p.x, p.y);
    ctx.globalAlpha = t;
    ctx.fillStyle = p.color;
    ctx.beginPath();
    ctx.arc(s.x, s.y, p.size * ppm * (0.6 + t * 0.6), 0, Math.PI * 2);
    ctx.fill();
    ctx.globalAlpha = 1;
  }

  for (const b of world.bodies) {
    if (b.role === "planet") continue;
    const pos = bodyPos(b, opts.alpha);
    const p = toScreen(view, world, pos.x, pos.y);
    const r = b.radius * ppm;
    ctx.save();
    ctx.shadowColor = "rgba(0,0,0,0.45)";
    ctx.shadowBlur = 12;
    ctx.shadowOffsetY = 4;
    const grd = ctx.createRadialGradient(p.x - r * 0.3, p.y - r * 0.35, r * 0.1, p.x, p.y, r);
    grd.addColorStop(0, shade(b.color, 28));
    grd.addColorStop(1, shade(b.color, -18));
    ctx.fillStyle = grd;
    ctx.beginPath();
    ctx.arc(p.x, p.y, r, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
    ctx.strokeStyle = b.id === opts.selectedId ? "#f0eeea" : "rgba(240,238,234,0.18)";
    ctx.lineWidth = b.id === opts.selectedId ? 2 : 1;
    ctx.beginPath();
    ctx.arc(p.x, p.y, r, 0, Math.PI * 2);
    ctx.stroke();
    ctx.fillStyle = "rgba(11,12,14,0.72)";
    ctx.font = `500 ${Math.max(9, Math.min(12, r * 0.55))}px 'IBM Plex Mono', monospace`;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(b.label ?? `${b.mass} kg`, p.x, p.y);

    if (opts.vectors && !b.fixed) {
      const sp = Math.hypot(b.vx, b.vy);
      if (sp > 0.18) {
        const tip = toScreen(view, world, pos.x + b.vx * 0.42, pos.y + b.vy * 0.42);
        arrow(ctx, p.x, p.y, tip.x, tip.y, "#8eb4d3", 2);
      }
      const fLen = Math.hypot(b.lastFx, b.lastFy);
      if (fLen > 0.8) {
        const ft = toScreen(
          view,
          world,
          pos.x + (b.lastFx / b.mass) * 0.18,
          pos.y + (b.lastFy / b.mass) * 0.18,
        );
        arrow(ctx, p.x, p.y, ft.x, ft.y, "#d08a7a", 1.6);
      }
    }
  }

  if (opts.velHandle) {
    const b = world.bodies.find((x) => x.id === opts.selectedId);
    if (b) {
      const pos = bodyPos(b, opts.alpha);
      const p = toScreen(view, world, pos.x, pos.y);
      const h = toScreen(view, world, opts.velHandle.x, opts.velHandle.y);
      arrow(ctx, p.x, p.y, h.x, h.y, "#8eb4d3", 2.4);
      ctx.fillStyle = "#f0eeea";
      ctx.beginPath();
      ctx.arc(h.x, h.y, 6, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = "#8eb4d3";
      ctx.stroke();
    }
  }

  ctx.restore();

  ctx.strokeStyle = "rgba(240,238,234,0.10)";
  ctx.lineWidth = 1;
  ctx.strokeRect(left + 0.5, top + 0.5, bw - 1, bh - 1);

  ctx.restore();
}

function shade(hex: string, amt: number) {
  const n = hex.replace("#", "");
  const r = clamp255(parseInt(n.slice(0, 2), 16) + amt);
  const g = clamp255(parseInt(n.slice(2, 4), 16) + amt);
  const b = clamp255(parseInt(n.slice(4, 6), 16) + amt);
  return `rgb(${r},${g},${b})`;
}

function clamp255(n: number) {
  return Math.max(0, Math.min(255, n | 0));
}

export function renderIdle(ctx: CanvasRenderingContext2D, w: number, h: number, t: number) {
  ctx.fillStyle = "#0b0c0e";
  ctx.fillRect(0, 0, w, h);
  const cx = w * 0.62;
  const cy = h * 0.52;
  const planetR = Math.min(w, h) * 0.16;

  const vg = ctx.createRadialGradient(cx, cy, planetR * 0.2, cx, cy, Math.max(w, h) * 0.7);
  vg.addColorStop(0, "rgba(142,180,211,0.07)");
  vg.addColorStop(1, "rgba(11,12,14,0)");
  ctx.fillStyle = vg;
  ctx.fillRect(0, 0, w, h);

  ctx.save();
  ctx.translate(cx, cy);
  ctx.rotate(-0.35);
  ctx.strokeStyle = "rgba(142,180,211,0.28)";
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.ellipse(0, 0, planetR * 2.35, planetR * 1.05, 0, 0, Math.PI * 2);
  ctx.stroke();
  ctx.strokeStyle = "rgba(197,205,216,0.14)";
  ctx.beginPath();
  ctx.ellipse(0, 0, planetR * 3.4, planetR * 1.45, 0.15, 0, Math.PI * 2);
  ctx.stroke();
  ctx.restore();

  const pg = ctx.createRadialGradient(cx - planetR * 0.3, cy - planetR * 0.35, planetR * 0.1, cx, cy, planetR);
  pg.addColorStop(0, "#e6e1d6");
  pg.addColorStop(0.45, "#c5cdd8");
  pg.addColorStop(1, "#2a2e36");
  ctx.fillStyle = pg;
  ctx.beginPath();
  ctx.arc(cx, cy, planetR, 0, Math.PI * 2);
  ctx.fill();

  const a1 = t * 0.42;
  const mx = cx + Math.cos(a1) * planetR * 2.35;
  const my = cy + Math.sin(a1) * planetR * 1.05;
  ctx.fillStyle = "#f0eeea";
  ctx.beginPath();
  ctx.arc(mx, my, 5, 0, Math.PI * 2);
  ctx.fill();
  const vx = -Math.sin(a1);
  const vy = Math.cos(a1);
  ctx.strokeStyle = "#8eb4d3";
  ctx.lineWidth = 1.6;
  ctx.beginPath();
  ctx.moveTo(mx, my);
  ctx.lineTo(mx + vx * 28, my + vy * 12);
  ctx.stroke();

  const a2 = t * 0.22 + 1.7;
  ctx.fillStyle = "#d4c4b0";
  ctx.beginPath();
  ctx.arc(cx + Math.cos(a2) * planetR * 3.4, cy + Math.sin(a2) * planetR * 1.45, 3.2, 0, Math.PI * 2);
  ctx.fill();

  for (let i = 0; i < 18; i++) {
    const s = Math.sin(i * 12.1 + t * 0.05) * 0.5 + 0.5;
    ctx.globalAlpha = 0.15 + s * 0.35;
    ctx.fillStyle = "#f0eeea";
    ctx.beginPath();
    ctx.arc(((i * 97) % w) + Math.sin(t * 0.1 + i) * 8, ((i * 53) % h) * 0.9, 1.1, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.globalAlpha = 1;
}
