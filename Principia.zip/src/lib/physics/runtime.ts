import { playBell, playCollide, playLaunch, playSuccess } from "@/lib/audio";
import type { LabDef } from "@/lib/labs/types";
import { clamp } from "@/lib/physics/math";
import {
  fitView,
  renderWorld,
  toScreen,
  toWorld,
  type View,
} from "@/lib/physics/render";
import {
  kinetic,
  makeBody,
  momentum,
  potential,
  predictTrajectory,
  stepWorld,
  type Body,
  type World,
} from "@/lib/physics/world";

const STEP = 1 / 120;

export type Telemetry = {
  t: number;
  mass: number;
  vx: number;
  vy: number;
  speed: number;
  ax: number;
  ay: number;
  ke: number;
  pe: number;
  e: number;
  px: number;
  py: number;
};

export type RuntimeSnapshot = {
  telemetry: Telemetry;
  paused: boolean;
  complete: boolean;
  stars: 0 | 1 | 2 | 3;
  detail: string;
  meta: Record<string, number>;
};

const emptyTel: Telemetry = {
  t: 0,
  mass: 0,
  vx: 0,
  vy: 0,
  speed: 0,
  ax: 0,
  ay: 0,
  ke: 0,
  pe: 0,
  e: 0,
  px: 0,
  py: 0,
};

export class LabRuntime {
  lab: LabDef;
  world: World;
  view: View | null = null;
  paused = false;
  selected: string | null = null;
  grab: { id: string; lastX: number; lastY: number; lastT: number } | null = null;
  velDrag = false;
  acc = 0;
  trauma = 0;
  predict: { x: number; y: number }[] | null = null;
  complete = false;
  stars: 0 | 1 | 2 | 3 = 0;
  detail = "";
  vectors = true;
  shake = true;
  reduced = false;
  spawnCount = 0;
  private lastEval = 0;

  constructor(lab: LabDef) {
    this.lab = lab;
    this.world = lab.build();
    this.selected = this.world.bodies.find((b) => b.role === "player" || b.role === "craft")?.id ?? this.world.bodies[0]?.id ?? null;
    if (typeof window !== "undefined") {
      this.reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    }
  }

  reset() {
    this.world = this.lab.build();
    this.acc = 0;
    this.complete = false;
    this.stars = 0;
    this.detail = "";
    this.paused = false;
    this.grab = null;
    this.velDrag = false;
    this.trauma = 0;
    this.selected = this.world.bodies.find((b) => b.role === "player" || b.role === "craft")?.id ?? this.world.bodies[0]?.id ?? null;
  }

  setControl(key: string, value: number) {
    this.lab.applyControl?.(this.world, key, value);
    this.world.meta[key] = value;
  }

  doAction(key: string) {
    this.lab.action?.(this.world, key);
    if (key === "fire" || key === "launch" || key === "release" || key === "drop" || key === "engage") {
      playLaunch();
    }
  }

  frame(dt: number) {
    const cap = Math.min(dt, 0.1);
    if (!this.paused && !this.complete) {
      this.acc += cap;
      this.acc = Math.min(this.acc, 0.25);
      while (this.acc >= STEP) {
        this.lab.tick?.(this.world, STEP);
        stepWorld(this.world, STEP);
        this.consumeEvents();
        this.acc -= STEP;
        this.lastEval += STEP;
        if (this.lastEval > 0.08) {
          this.lastEval = 0;
          this.check();
        }
      }
    } else {
      this.lab.tick?.(this.world, 0);
    }
    this.trauma = Math.max(0, this.trauma - cap * 2.4);
    this.updatePredict();
  }

  private check() {
    if (this.complete || this.lab.sandbox) return;
    const ev = this.lab.evaluate(this.world);
    if (ev.complete && ev.stars > 0) {
      this.complete = true;
      this.stars = ev.stars;
      this.detail = ev.detail;
      this.paused = true;
      playSuccess();
      this.trauma = Math.min(1, this.trauma + 0.45);
    }
  }

  private consumeEvents() {
    for (const e of this.world.events) {
      if (e.type === "collide") {
        playCollide(e.mag);
        if (this.shake && !this.reduced) this.trauma = Math.min(1, this.trauma + Math.min(0.4, e.mag * 0.05));
      }
      if (e.type === "bell") playBell();
    }
  }

  private updatePredict() {
    if (this.lab.id !== "projectile" && this.lab.id !== "orbit") {
      this.predict = null;
      return;
    }
    if (this.lab.id === "projectile") {
      const th = ((this.world.meta.angle ?? 45) * Math.PI) / 180;
      const v = this.world.meta.speed ?? 12;
      const flying = this.world.meta.flying === 1 && !this.world.bodies[0]?.fixed;
      if (flying) {
        this.predict = null;
        return;
      }
      this.predict = predictTrajectory(this.world, 1.6, 0.95, Math.cos(th) * v, Math.sin(th) * v, 2.6);
      return;
    }
    const craft = this.world.bodies.find((b) => b.role === "craft");
    if (!craft) return;
    if (this.world.meta.setup === 1) {
      this.predict = predictTrajectory(
        this.world,
        craft.x,
        craft.y,
        this.world.meta.vx0 ?? 0,
        this.world.meta.vy0 ?? 0,
        6,
        1 / 45,
      );
    } else {
      this.predict = predictTrajectory(this.world, craft.x, craft.y, craft.vx, craft.vy, 4, 1 / 45);
    }
  }

  pointerDown(sx: number, sy: number) {
    if (!this.view) return;
    const p = toWorld(this.view, this.world, sx, sy);
    if (this.lab.id === "orbit" && this.world.meta.setup === 1 && this.selected) {
      const craft = this.world.bodies.find((b) => b.id === this.selected);
      if (craft) {
        const handle = toScreen(this.view, this.world, craft.x + (this.world.meta.vx0 ?? 0) * 0.45, craft.y + (this.world.meta.vy0 ?? 0) * 0.45);
        if ((handle.x - sx) ** 2 + (handle.y - sy) ** 2 < 18 * 18) {
          this.velDrag = true;
          return;
        }
      }
    }
    const hit = this.hitScreen(sx, sy);
    if (hit && (!hit.fixed || (hit.role === "craft" && this.world.meta.setup === 1))) {
      this.selected = hit.id;
      hit.grabbed = true;
      hit.vx = 0;
      hit.vy = 0;
      this.grab = { id: hit.id, lastX: p.x, lastY: p.y, lastT: performance.now() };
      return;
    }
    if (this.lab.id === "sandbox") {
      this.spawnCount += 1;
      const colors = ["#d4c4b0", "#8eb4d3", "#c5cdd8", "#d08a7a"];
      const mass = 0.6 + Math.random() * 2.2;
      this.world.bodies.push(
        makeBody({
          id: `s${this.spawnCount}`,
          x: clamp(p.x, 0.4, this.world.width - 0.4),
          y: clamp(p.y, 0.4, this.world.height - 0.4),
          mass,
          radius: 0.22 + mass * 0.12,
          color: colors[this.spawnCount % colors.length],
          label: mass.toFixed(1),
        }),
      );
    }
  }

  private hitScreen(sx: number, sy: number): Body | null {
    if (!this.view) return null;
    let best: Body | null = null;
    let bestD = Infinity;
    for (const b of this.world.bodies) {
      if (b.role === "planet") continue;
      const p = toScreen(this.view, this.world, b.x, b.y);
      const r = Math.max(28, b.radius * this.view.ppm * 1.25);
      const d2 = (p.x - sx) ** 2 + (p.y - sy) ** 2;
      if (d2 <= r * r && d2 < bestD) {
        best = b;
        bestD = d2;
      }
    }
    return best;
  }

  pointerMove(sx: number, sy: number) {
    if (!this.view) return;
    const p = toWorld(this.view, this.world, sx, sy);
    if (this.velDrag) {
      const craft = this.world.bodies.find((b) => b.id === this.selected);
      if (craft) {
        this.world.meta.vx0 = clamp((p.x - craft.x) / 0.45, -12, 12);
        this.world.meta.vy0 = clamp((p.y - craft.y) / 0.45, -12, 12);
      }
      return;
    }
    if (!this.grab) return;
    const b = this.world.bodies.find((x) => x.id === this.grab?.id);
    if (!b) return;
    const now = performance.now();
    const dt = Math.max(0.008, (now - this.grab.lastT) / 1000);
    const nx = clamp(p.x, b.radius, this.world.width - b.radius);
    const ny = clamp(p.y, b.radius, this.world.height - b.radius);
    b.vx = (nx - this.grab.lastX) / dt;
    b.vy = (ny - this.grab.lastY) / dt;
    b.x = nx;
    b.y = ny;
    b.px = nx;
    b.py = ny;
    this.grab.lastX = nx;
    this.grab.lastY = ny;
    this.grab.lastT = now;
  }

  pointerUp() {
    if (this.velDrag) {
      this.velDrag = false;
      return;
    }
    if (!this.grab) return;
    const b = this.world.bodies.find((x) => x.id === this.grab?.id);
    if (b) {
      b.grabbed = false;
      const sp = Math.hypot(b.vx, b.vy);
      const max = 18;
      if (sp > max) {
        b.vx = (b.vx / sp) * max;
        b.vy = (b.vy / sp) * max;
      }
      if (this.lab.id === "orbit" && this.world.meta.setup === 1) {
        b.vx = 0;
        b.vy = 0;
        b.fixed = true;
      }
    }
    this.grab = null;
  }

  render(ctx: CanvasRenderingContext2D, cssW: number, cssH: number) {
    this.view = fitView(this.world, cssW, cssH);
    const alpha = this.paused || this.complete ? 1 : this.acc / STEP;
    const shake = this.shake && !this.reduced ? this.trauma * this.trauma : 0;
    const craft = this.world.bodies.find((b) => b.role === "craft");
    const velHandle =
      this.lab.id === "orbit" && this.world.meta.setup === 1 && craft
        ? { x: craft.x + (this.world.meta.vx0 ?? 0) * 0.45, y: craft.y + (this.world.meta.vy0 ?? 0) * 0.45 }
        : null;
    renderWorld(ctx, this.world, this.view, {
      alpha,
      vectors: this.vectors,
      selectedId: this.selected,
      predict: this.predict,
      shakeX: (Math.random() * 2 - 1) * shake * 10,
      shakeY: (Math.random() * 2 - 1) * shake * 10,
      velHandle,
    });
  }

  snapshot(): RuntimeSnapshot {
    const b = this.selectedBody();
    const ke = this.world.bodies.reduce((n, x) => n + kinetic(x), 0);
    const pe = this.world.bodies.reduce((n, x) => n + (x.fixed ? 0 : potential(x, this.world)), 0);
    const p = momentum(this.world.bodies);
    return {
      telemetry: b
        ? {
            t: this.world.time,
            mass: b.mass,
            vx: b.vx,
            vy: b.vy,
            speed: Math.hypot(b.vx, b.vy),
            ax: b.ax,
            ay: b.ay,
            ke,
            pe,
            e: ke + pe,
            px: p.px,
            py: p.py,
          }
        : { ...emptyTel, t: this.world.time, ke, pe, e: ke + pe, px: p.px, py: p.py },
      paused: this.paused,
      complete: this.complete,
      stars: this.stars,
      detail: this.detail,
      meta: this.world.meta,
    };
  }

  selectedBody(): Body | null {
    return this.world.bodies.find((b) => b.id === this.selected) ?? this.world.bodies[0] ?? null;
  }
}
