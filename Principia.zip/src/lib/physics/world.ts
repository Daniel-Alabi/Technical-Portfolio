import { closestOnSegment, clamp, dist2, EPS, len, norm } from "./math";

export type Body = {
  id: string;
  x: number;
  y: number;
  vx: number;
  vy: number;
  ax: number;
  ay: number;
  px: number;
  py: number;
  mass: number;
  radius: number;
  restitution: number;
  friction: number;
  drag: number;
  fixed: boolean;
  color: string;
  label?: string;
  role?: string;
  lastFx: number;
  lastFy: number;
  forceX: number;
  forceY: number;
  grabbed: boolean;
};

export type Segment = {
  id: string;
  x1: number;
  y1: number;
  x2: number;
  y2: number;
  restitution: number;
  color: string;
};

export type Rect = {
  id: string;
  x: number;
  y: number;
  w: number;
  h: number;
  restitution: number;
  color: string;
  fill: string;
  role?: string;
  vx: number;
  vy: number;
  solid: boolean;
};

export type Spring = {
  id: string;
  a: string;
  b?: string;
  ax: number;
  ay: number;
  rest: number;
  k: number;
  c: number;
};

export type Well = {
  id: string;
  x: number;
  y: number;
  gm: number;
  radius: number;
  color: string;
  label?: string;
};

export type Zone = {
  id: string;
  x: number;
  y: number;
  w: number;
  h: number;
  kind: "goal" | "hazard" | "bell" | "pad" | "pocket";
  color: string;
  label?: string;
};

export type Particle = {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  age: number;
  size: number;
  color: string;
};

export type WorldEvent =
  | { type: "collide"; mag: number; x: number; y: number }
  | { type: "success"; x: number; y: number }
  | { type: "bell"; x: number; y: number };

export type World = {
  width: number;
  height: number;
  gx: number;
  gy: number;
  bounceBounds: boolean;
  groundY: number | null;
  bodies: Body[];
  segments: Segment[];
  rects: Rect[];
  springs: Spring[];
  wells: Well[];
  zones: Zone[];
  particles: Particle[];
  events: WorldEvent[];
  time: number;
  meta: Record<string, number>;
};

export function makeBody(partial: Partial<Body> & { id: string; x: number; y: number }): Body {
  const mass = partial.mass ?? 1;
  const radius = partial.radius ?? 0.35;
  return {
    vx: 0,
    vy: 0,
    ax: 0,
    ay: 0,
    px: partial.x,
    py: partial.y,
    mass,
    radius,
    restitution: 0.72,
    friction: 0.08,
    drag: 0,
    fixed: false,
    color: "#d4c4b0",
    lastFx: 0,
    lastFy: 0,
    forceX: 0,
    forceY: 0,
    grabbed: false,
    ...partial,
  };
}

export function makeWorld(partial: Partial<World> & { width: number; height: number }): World {
  return {
    gx: 0,
    gy: 0,
    bounceBounds: true,
    groundY: null,
    bodies: [],
    segments: [],
    rects: [],
    springs: [],
    wells: [],
    zones: [],
    particles: [],
    events: [],
    time: 0,
    meta: {},
    ...partial,
  };
}

export function kinetic(b: Body) {
  return 0.5 * b.mass * (b.vx * b.vx + b.vy * b.vy);
}

export function potential(b: Body, world: World) {
  let pe = 0;
  if (world.gy !== 0) {
    const g = Math.abs(world.gy);
    const h = world.groundY !== null ? b.y - world.groundY : b.y;
    pe += b.mass * g * Math.max(0, h);
  }
  for (const well of world.wells) {
    const r = Math.max(0.35, Math.hypot(b.x - well.x, b.y - well.y));
    pe += (-well.gm * b.mass) / r;
  }
  for (const s of world.springs) {
    const body = world.bodies.find((x) => x.id === s.a);
    if (!body) continue;
    let bx = s.ax;
    let by = s.ay;
    if (s.b) {
      const other = world.bodies.find((x) => x.id === s.b);
      if (!other) continue;
      bx = other.x;
      by = other.y;
    }
    const d = Math.hypot(body.x - bx, body.y - by) - s.rest;
    pe += 0.5 * s.k * d * d;
  }
  return pe;
}

export function momentum(bodies: Body[]) {
  let px = 0;
  let py = 0;
  for (const b of bodies) {
    if (b.fixed) continue;
    px += b.mass * b.vx;
    py += b.mass * b.vy;
  }
  return { px, py };
}

function emitSparks(world: World, x: number, y: number, mag: number, color: string) {
  const n = Math.min(14, 3 + Math.floor(mag * 2));
  for (let i = 0; i < n; i++) {
    const a = Math.random() * Math.PI * 2;
    const s = 0.6 + Math.random() * mag;
    world.particles.push({
      x,
      y,
      vx: Math.cos(a) * s,
      vy: Math.sin(a) * s,
      life: 0.35 + Math.random() * 0.4,
      age: 0,
      size: 0.04 + Math.random() * 0.06,
      color,
    });
  }
}

function resolveCircleCircle(a: Body, b: Body, world: World) {
  const dx = b.x - a.x;
  const dy = b.y - a.y;
  const d2 = dx * dx + dy * dy;
  const min = a.radius + b.radius;
  if (d2 >= min * min || d2 < EPS) return;
  const d = Math.sqrt(d2);
  const nx = dx / d;
  const ny = dy / d;
  const overlap = min - d;
  const imA = a.fixed || a.grabbed ? 0 : 1 / a.mass;
  const imB = b.fixed || b.grabbed ? 0 : 1 / b.mass;
  const im = imA + imB;
  if (im <= 0) return;
  const corr = overlap / im;
  if (imA > 0) {
    a.x -= nx * corr * imA;
    a.y -= ny * corr * imA;
  }
  if (imB > 0) {
    b.x += nx * corr * imB;
    b.y += ny * corr * imB;
  }
  const rvx = b.vx - a.vx;
  const rvy = b.vy - a.vy;
  const velN = rvx * nx + rvy * ny;
  if (velN > 0) return;
  const e = Math.min(a.restitution, b.restitution);
  const j = (-(1 + e) * velN) / im;
  const ix = j * nx;
  const iy = j * ny;
  if (imA > 0) {
    a.vx -= ix * imA;
    a.vy -= iy * imA;
  }
  if (imB > 0) {
    b.vx += ix * imB;
    b.vy += iy * imB;
  }
  const tx = -ny;
  const ty = nx;
  const velT = rvx * tx + rvy * ty;
  const mu = Math.min(a.friction, b.friction);
  const jt = clamp(-velT / im, -Math.abs(j) * mu, Math.abs(j) * mu);
  if (imA > 0) {
    a.vx -= jt * tx * imA;
    a.vy -= jt * ty * imA;
  }
  if (imB > 0) {
    b.vx += jt * tx * imB;
    b.vy += jt * ty * imB;
  }
  const mag = Math.abs(j);
  if (mag > 0.35) {
    world.events.push({ type: "collide", mag, x: a.x + nx * a.radius, y: a.y + ny * a.radius });
    emitSparks(world, a.x + nx * a.radius, a.y + ny * a.radius, mag * 0.25, "#c5cdd8");
  }
}

function resolveCirclePoint(
  b: Body,
  px: number,
  py: number,
  restitution: number,
  world: World,
  friction = 0.12,
) {
  if (b.fixed || b.grabbed) return;
  const dx = b.x - px;
  const dy = b.y - py;
  const d2 = dx * dx + dy * dy;
  const min = b.radius;
  if (d2 >= min * min || d2 < EPS) return;
  const d = Math.sqrt(d2);
  const nx = dx / d;
  const ny = dy / d;
  const overlap = min - d;
  b.x += nx * overlap;
  b.y += ny * overlap;
  const velN = b.vx * nx + b.vy * ny;
  if (velN < 0) {
    const e = Math.min(b.restitution, restitution);
    const j = -(1 + e) * velN;
    b.vx += j * nx;
    b.vy += j * ny;
    const tx = -ny;
    const ty = nx;
    const velT = b.vx * tx + b.vy * ty;
    b.vx -= velT * tx * friction;
    b.vy -= velT * ty * friction;
    const mag = Math.abs(j) * b.mass;
    if (mag > 0.5) {
      world.events.push({ type: "collide", mag, x: px, y: py });
      emitSparks(world, px, py, mag * 0.2, "#c5cdd8");
    }
  }
}

function resolveCircleSegment(b: Body, s: Segment, world: World) {
  const c = closestOnSegment(b.x, b.y, s.x1, s.y1, s.x2, s.y2);
  resolveCirclePoint(b, c.x, c.y, s.restitution, world);
}

function resolveCircleRect(b: Body, r: Rect, world: World) {
  if (!r.solid) return;
  const qx = clamp(b.x, r.x, r.x + r.w);
  const qy = clamp(b.y, r.y, r.y + r.h);
  resolveCirclePoint(b, qx, qy, r.restitution, world, 0.18);
}

function applyForces(world: World, dt: number) {
  for (const b of world.bodies) {
    if (b.fixed || b.grabbed) {
      b.lastFx = 0;
      b.lastFy = 0;
      b.ax = 0;
      b.ay = 0;
      continue;
    }
    let fx = b.forceX + b.mass * world.gx;
    let fy = b.forceY + b.mass * world.gy;

    for (const well of world.wells) {
      const dx = well.x - b.x;
      const dy = well.y - b.y;
      const r2 = dx * dx + dy * dy + 0.12;
      const inv = well.gm * b.mass / (r2 * Math.sqrt(r2));
      fx += dx * inv;
      fy += dy * inv;
    }

    for (const s of world.springs) {
      if (s.a !== b.id && s.b !== b.id) continue;
      let ox: number;
      let oy: number;
      if (s.a === b.id) {
        if (s.b) {
          const other = world.bodies.find((x) => x.id === s.b);
          if (!other) continue;
          ox = other.x;
          oy = other.y;
        } else {
          ox = s.ax;
          oy = s.ay;
        }
      } else {
        const other = world.bodies.find((x) => x.id === s.a);
        if (!other) continue;
        ox = other.x;
        oy = other.y;
      }
      const dx = b.x - ox;
      const dy = b.y - oy;
      const d = Math.hypot(dx, dy);
      if (d < EPS) continue;
      const nx = dx / d;
      const ny = dy / d;
      const stretch = d - s.rest;
      fx += -s.k * stretch * nx;
      fy += -s.k * stretch * ny;
      const rel = b.vx * nx + b.vy * ny;
      fx += -s.c * rel * nx;
      fy += -s.c * rel * ny;
    }

    if (b.drag > 0) {
      const sp = len(b.vx, b.vy);
      fx += -b.drag * b.vx * sp;
      fy += -b.drag * b.vy * sp;
    }

    b.lastFx = fx;
    b.lastFy = fy;
    b.ax = fx / b.mass;
    b.ay = fy / b.mass;
    b.vx += b.ax * dt;
    b.vy += b.ay * dt;
    const speed = len(b.vx, b.vy);
    const max = 42;
    if (speed > max) {
      b.vx = (b.vx / speed) * max;
      b.vy = (b.vy / speed) * max;
    }
  }
}

function integrate(world: World, dt: number) {
  for (const b of world.bodies) {
    b.px = b.x;
    b.py = b.y;
    if (b.fixed || b.grabbed) continue;
    b.x += b.vx * dt;
    b.y += b.vy * dt;
  }
  for (const r of world.rects) {
    if (r.vx || r.vy) {
      r.x += r.vx * dt;
      r.y += r.vy * dt;
    }
  }
}

function bounds(world: World) {
  for (const b of world.bodies) {
    if (b.fixed || b.grabbed) continue;
    if (world.groundY !== null && b.y - b.radius < world.groundY) {
      b.y = world.groundY + b.radius;
      if (b.vy < 0) {
        const mag = Math.abs(b.vy) * b.mass;
        b.vy = -b.vy * b.restitution;
        b.vx *= 1 - b.friction;
        if (Math.abs(b.vy) < 0.12) b.vy = 0;
        if (mag > 0.8) {
          world.events.push({ type: "collide", mag, x: b.x, y: world.groundY });
          emitSparks(world, b.x, world.groundY, mag * 0.15, "#c5cdd8");
        }
      }
    }
    if (!world.bounceBounds) continue;
    if (b.x - b.radius < 0) {
      b.x = b.radius;
      b.vx = Math.abs(b.vx) * b.restitution;
    } else if (b.x + b.radius > world.width) {
      b.x = world.width - b.radius;
      b.vx = -Math.abs(b.vx) * b.restitution;
    }
    if (b.y - b.radius < 0) {
      b.y = b.radius;
      b.vy = Math.abs(b.vy) * b.restitution;
    } else if (b.y + b.radius > world.height) {
      b.y = world.height - b.radius;
      b.vy = -Math.abs(b.vy) * b.restitution;
    }
  }
}

function collideAll(world: World) {
  const n = world.bodies.length;
  for (let i = 0; i < n; i++) {
    const a = world.bodies[i];
    for (let j = i + 1; j < n; j++) resolveCircleCircle(a, world.bodies[j], world);
    for (const s of world.segments) resolveCircleSegment(a, s, world);
    for (const r of world.rects) resolveCircleRect(a, r, world);
  }
}

function stepParticles(world: World, dt: number) {
  const next: Particle[] = [];
  for (const p of world.particles) {
    p.age += dt;
    if (p.age >= p.life) continue;
    p.x += p.vx * dt;
    p.y += p.vy * dt;
    p.vy += world.gy * dt * 0.35;
    next.push(p);
  }
  world.particles = next;
}

export function inZone(b: Body, z: Zone) {
  return b.x > z.x && b.x < z.x + z.w && b.y > z.y && b.y < z.y + z.h;
}

export function stepWorld(world: World, dt: number) {
  world.events.length = 0;
  world.time += dt;
  applyForces(world, dt);
  integrate(world, dt);
  collideAll(world);
  collideAll(world);
  bounds(world);
  stepParticles(world, dt);
}

export function predictTrajectory(
  world: World,
  x: number,
  y: number,
  vx: number,
  vy: number,
  seconds = 2.4,
  dt = 1 / 60,
): { x: number; y: number }[] {
  const pts: { x: number; y: number }[] = [];
  let cx = x;
  let cy = y;
  let cvx = vx;
  let cvy = vy;
  const steps = Math.floor(seconds / dt);
  for (let i = 0; i < steps; i++) {
    pts.push({ x: cx, y: cy });
    let fx = world.gx;
    let fy = world.gy;
    for (const well of world.wells) {
      const dx = well.x - cx;
      const dy = well.y - cy;
      const r2 = dx * dx + dy * dy + 0.12;
      const inv = well.gm / (r2 * Math.sqrt(r2));
      fx += dx * inv;
      fy += dy * inv;
    }
    cvx += fx * dt;
    cvy += fy * dt;
    cx += cvx * dt;
    cy += cvy * dt;
    if (world.groundY !== null && cy < world.groundY) break;
    if (cx < -2 || cx > world.width + 2 || cy < -2 || cy > world.height + 2) break;
  }
  return pts;
}

export function hitBody(world: World, x: number, y: number): Body | null {
  let best: Body | null = null;
  let bestD = Infinity;
  for (const b of world.bodies) {
    if (b.fixed && b.role === "planet") {
      const d = dist2(x, y, b.x, b.y);
      if (d < b.radius * b.radius && d < bestD) {
        best = b;
        bestD = d;
      }
      continue;
    }
    const pad = Math.max(0.28, b.radius * 1.35);
    const d = dist2(x, y, b.x, b.y);
    if (d < pad * pad && d < bestD) {
      best = b;
      bestD = d;
    }
  }
  return best;
}

export { clamp, norm, len };
