import { createFileRoute } from "@tanstack/react-router";
import { HubView } from "@/components/hub-view";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <HubView />;
}
