import { createFileRoute } from "@tanstack/react-router";
import { LabStage } from "@/components/lab-stage";

export const Route = createFileRoute("/lab/$id")({
  component: LabPage,
});

function LabPage() {
  const { id } = Route.useParams();
  return <LabStage id={id} />;
}
